from api import *
from utils import speech_to_text,text_to_speech1, redirecting_to_agent, message_website,call_openai,extract_and_convert_to_json
import re
import sqlite3
from dataclasses import dataclass
from typing import Dict, Any
import requests

# Connect to the SQLite database (replace 'db.sqlite3' with your database file)
db_path = 'db.sqlite3'  # Replace with the path to your SQLite database
conn = sqlite3.connect("../db.sqlite3")
cursor = conn.cursor()

@dataclass
class ClaimSession:
    """Central data storage for claim process"""
    auth_attempts: int = 0
    policy_number: str = None
    mobile_number: str = None
    policy_details: Dict[str, Any] = None
    caller_details: Dict[str, Any] = None
    claim_details: Dict[str, Any] = None
    garage_details: Dict[str, Any] = None
    transfer_reason: str = None


def validate_mobile_number(mobile_number):
    # mobile_number = session.mobile_number
    # Mock validation logic
    valid_policies = ["9876543210","1234567890123456", "123456789012345678","8697745125"]
    return mobile_number in valid_policies


def ask_mobile_or_policy_number(session:ClaimSession):
    while session.auth_attempts < 2:
        text_to_speech1("Can you please share your 16 or 18 digit policy number or 10 digit registered mobile number?")
        user_input = str(speech_to_text()).strip().lower()
        cleaned_number = re.sub(r"[.-]", "", user_input)
        if validate_mobile_number(cleaned_number):
            if len(cleaned_number) == 10:
                session.mobile_number = cleaned_number
            else:
                session.policy_number = cleaned_number
            return True
        else:
            session.auth_attempts += 1
            if session.auth_attempts < 2:
                text_to_speech1("The information does not match our records. Let's try again.")
    session.transfer_reason = "Maximum authentication attempts exceeded"
    text_to_speech1("I'm sorry, we've exceeded the maximum attempts. Goodbye!")
    return False


def get_policy_details(session:ClaimSession):
    mobile_number = session.mobile_number
    session.policy_details = fetch_policy_details_via_phone_number(mobile_number)
    if session.policy_details:
        text_to_speech1("I have identified your policy. I will now direct you to the appropriate team based on your policy type.")
        text_to_speech1("Could you kindly confirm your policy number?")

        confirm_policy_number = str(speech_to_text()).strip().lower()
        confirm_policy_number = remove_fullstop_from_input(confirm_policy_number)
        confirm_policy_number = "160221923730000221"

        if confirm_policy_number == session.policy_details['policyno']:
            text_to_speech1(f"""Please confirm the following policy details. Policy Number: {session.policy_details['policyno']}, Insured Name: {session.policy_details['insured_name']}""")
            return True
        else:
            session.transfer_reason = "Policy number mismatch"
            text_to_speech1("The policy number you provided does not match our records. Let me connect you with an agent.")
            return False
    else:
        session.transfer_reason = "Policy details not found"
        return False


def insured_confirmation(session: ClaimSession):
    session.caller_details = {}
    # if policy_details:
    message = f"Thank you. I've successfully validated your policy. The insured's name is {session.policy_details['insured_name']}. could you please confirm if you are the insured?"
    text_to_speech1(message)

    confirm_insured_or_not = str(speech_to_text()).strip().lower()

    if 'yes' in confirm_insured_or_not :
        session.caller_details["is_insured"] = True
        text_to_speech1(f"Thank you for confirming, {session.policy_details['insured_name']}. Let's proceed with your claim.")
    else:
        session.caller_details["is_insured"] = False
        text_to_speech1("I understand that you're not the insured. I will need to collect some information from you.")

        text_to_speech1("Could you please confirm your relationship with the insured?")
        session.caller_details['relationship'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please help us with your full name.")
        session.caller_details['name'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please provide your mobile number.")
        session.caller_details['mobile'] = str(speech_to_text()).strip().lower()


def claim_type(session:ClaimSession):
    session.claim_details = {}

    text_to_speech1("Please confirm whether this claim is for an accident or theft.")
    claim_type_response = str(speech_to_text()).strip().lower()

    prompt = f"""
    You are a claim type classifier. Your task is to strictly identify whether the given details represent an accident or theft. 

    IMPORTANT RULES:
    - You MUST return ONLY ONE claim type: either "accident" or "theft".
    - If the details do NOT clearly indicate either accident or theft, respond with None.
    - Return the result in strict JSON format.
    - Do NOT provide multiple claim types or any additional explanations.

    Input Details: {claim_type_response}

    Expected Output Format:
    {{
        "claim_type": "accident" OR "claim_type": "theft"
    }}
    """

    claim_type_detail = extract_and_convert_to_json(call_openai(prompt))

    if 'theft' in claim_type_detail.get('claim_type'):
        session.transfer_reason = "Theft claim requires specialist handling"
        text_to_speech1("I understand this is a theft claim. I'll need to transfer you to a specialized agent for further assistance. Please hold.")

        session.claim_details['claim_type'] = 'theft'
        return False
    elif 'accident' in claim_type_detail.get('claim_type'):
        session.claim_details['claim_type'] = 'accident'
        text_to_speech1("I'm sorry to hear about the accident. Have you reported the vehicle to a garage?")
        response = str(speech_to_text()).strip().lower()

        if 'no' in response:
            session.transfer_reason = "Vehicle not reported to garage"
            text_to_speech1("Since the vehicle hasn't been reported to a garage yet, I will transfer you to an agent for further guidance on the next steps. Please hold.")
            return False

        text_to_speech1("Thank you for reporting the vehicle. I will need some details about the accident. Let's go through them one by one.")


        return True


# 110322423110146463
# 8697745125

# 160221923730000221
# 9331580407
def claim_intimation_flow(mobile_number="9876543210"):
    session = ClaimSession()

    # Initial Greetings
    text_to_speech1(text="Namaste! Welcome to our claim helpline.")

    if validate_mobile_number(mobile_number):
        session.mobile_number = mobile_number
        if not get_policy_details(session):
            print(session.__dict__)
            return redirecting_to_agent(session.transfer_reason)
    else:
        if not ask_mobile_or_policy_number(session):
            print(session.__dict__)
            return redirecting_to_agent(session.transfer_reason)
        if session.mobile_number:
            if not get_policy_details(session):
                print(session.__dict__)
                return redirecting_to_agent(session.transfer_reason)

    insured_confirmation(session)

    if not claim_type(session):
        print(session.__dict__)
        return redirecting_to_agent(session.transfer_reason)

    print(session.__dict__)


claim_intimation_flow()
