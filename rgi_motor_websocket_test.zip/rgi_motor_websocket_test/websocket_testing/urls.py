# voiceapp/urls.py

from django.urls import path
from .views import InitialCallView

urlpatterns = [
    path('sampark', InitialCallView.as_view(), name='initial_call'),
]
