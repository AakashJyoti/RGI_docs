import re
import sqlite3
from dataclasses import dataclass
from typing import Dict, Any
from api import *
from utils import speech_to_text,text_to_speech1_english, redirecting_to_agent, message_website,call_openai,extract_and_convert_to_json
from soap_api_number import extract_motor_policy_numbers
from dateutil import parser
import re
import wave
import time
import streamlit as st
from deep_update import play_audio,handle_recording

from utils import speech_to_text_azure_streamlit_hindi, text_to_speech_azure_streamlit_hindi



def convert_to_dd_mm_yyyy(date_str):
    # Regular expression to match month and year formats (e.g., "February 2025")
    if re.match(r"^[A-Za-z]+ \d{4}$", date_str) or re.match(r"^\d{1,2}[a-z]{2} [A-Za-z]+$", date_str):
        return "date format is not correct"
    try:
        # Parse the input date string
        parsed_date = parser.parse(date_str)

        # Convert the parsed date to DD/MM/YYYY format
        formatted_date = parsed_date.strftime('%d/%m/%Y')
        return formatted_date

    except (ValueError, OverflowError):
        return "Invalid date format"


# # audio file time duration calculation
def calculate_length_of_audio():
    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    audio_path = os.path.join(parent_directory, "audio", "Bot", "bot_response.wav")

    with wave.open(audio_path, 'rb') as audio_file:
        frames = audio_file.getnframes()
        rate = audio_file.getframerate()
        duration = frames / float(rate)
        return duration+0.5

def fetch_garage(pincode):
    # Get absolute database path
    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    db_path = os.path.join(parent_directory, "db.sqlite3")

    # db_path = os.path.abspath('D:/reliance/claim_agent/db.sqlite3')

    if not os.path.exists(db_path):
        print("Database file not found!")
        return []

    try:
        # Establishing connection to the database
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Fetch Records
        query = f"SELECT * FROM FinalGarageMaster WHERE PinCode = '{pincode}';"
        cursor.execute(query)
        records = cursor.fetchall()
        return records

    except Exception as e:
        print(f"An error occurred: {e}")
        return []

    finally:
        if conn:
            conn.close()


def write_prompt_for_hindi_to_english(input_text= None, instructions=None):
    #translation prompt
    hindi_to_english_prompt = f"""
        You are an expert Hindi to English Translator.
        Translate the following text from Hindi to English. 
        Please follow this Instructions: 
            - {instructions}
        
        details to be translated: {input_text}
    """
    return hindi_to_english_prompt

def text_to_speech_func(message):
    text_to_speech_azure_streamlit_hindi(input_text=message)
    with st.chat_message("assistant"):
        st.write(message)
    play_audio()
    time.sleep(calculate_length_of_audio())  # handle time dynamically


def get_user_input_with_retries(record_duration: int = 5):
    message = "माफ़ कीजिए, मुझे वो समझ नहीं आया। क्या आप कृपया इसे फिर से कह सकते हैं?"
    max_attempts = 0
    while max_attempts < 2:
        max_attempts += 1
        text_to_speech_func(message)

        # Record user input
        with st.spinner("Recording..."):
            handle_recording(duration=record_duration)
        input_text = speech_to_text_azure_streamlit_hindi()

        # Validate and process input
        if input_text is not None:
            processed_text = str(input_text).strip().lower()
            if processed_text:
                # with st.chat_message("user"):
                #     st.write(processed_text)
                return processed_text

    return False  # All attempts failed


def handle_user_input(duration):
    with st.spinner("Recording..."):
        handle_recording(duration=duration)  # Assuming handle_recording is your recording function
    user_input = speech_to_text_azure_streamlit_hindi()
    if user_input is not None:
        user_input = remove_fullstop_from_input(user_input.strip().lower())
        # with st.chat_message("user"):
        #     st.write(user_input)
    else:
        user_input = get_user_input_with_retries(record_duration=duration)
    return user_input



@dataclass
class ClaimSession:
    """Central data storage for claim process"""
    auth_attempts: int = 0
    policy_number: str = None
    mobile_number: str = None
    policy_details: Dict[str, Any] = None
    caller_details: Dict[str, Any] = None
    claim_details: Dict[str, Any] = None
    garage_details: Dict[str, Any] = None
    transfer_reason: str = None


def validate_mobile_number(mobile_number):
    # Mock validation logic
    validate_number = validate_mobile_number_api_call(mobile_number)

    # Check if the response indicates a valid or invalid mobile number
    if validate_number == "valid mobile number":
        return True
    elif validate_number == "invalid mobile number":
        return False
    else:
        return False

def ask_mobile_or_policy_number(session:ClaimSession):
    try:
        while session.auth_attempts < 2:

            message = "क्या आप कृपया अपना 16 या 18 अंकों का पॉलिसी नंबर या 10 अंकों का रजिस्टर्ड मोबाइल नंबर साझा कर सकते हैं?"
            text_to_speech_func(message)

            # user_input = str(speech_to_text()).strip().lower()
            # with st.spinner("Recording..."):
            #     handle_recording(duration=12)  # Assuming handle_recording is your recording function
            # user_input = remove_fullstop_from_input(speech_to_text_azure_streamlit_hindi().strip().lower())
            user_input = handle_user_input(duration=12)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False


            prompt = """If there are any numbers, return them in their numeric format, not as text.
                Ex.: 'आठ छ 97745125' translated to '8697745125' not this 'eight six 97745125'"""
            user_input = call_openai(write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            cleaned_number = re.sub(r"[^\d]", "", user_input)  # Keep only digits, remove anything else
            with st.chat_message("user"):
                st.write(cleaned_number)


            if len(cleaned_number) == 10 and validate_mobile_number(cleaned_number):
                session.mobile_number = cleaned_number
                return True
            elif len(cleaned_number) in [16, 18]:
                session.policy_number = cleaned_number
                return True
            else:
                session.auth_attempts += 1
                if session.auth_attempts < 2:

                    message = "मुझे खेद है, जो जानकारी आपने साझा की है वह हमारे रिकॉर्ड्स से मेल नहीं खाती। चलिए, फिर से प्रयास करते हैं।"
                    text_to_speech_func(message)

        session.transfer_reason = "Maximum authentication attempts exceeded"

        message = "मुझे खेद है, हम अधिकतम प्रयासों की सीमा पार कर चुके हैं। अलविदा!"
        text_to_speech_func(message)

        return False
    except Exception as e:
        session.transfer_reason = f"Ask for mobile or policy number error: {str(e)}"
        message = "मुझे खेद है, सिस्टम समस्या के कारण मैं आपको एक एजेंट से जोड़ रही हूँ, जो आगे आपकी सहायता कर सकता है। कृपया इंतजार करें।"
        text_to_speech_func(message)
        return False



def get_policy_details(session: ClaimSession):
    try:
        """
        This function obtains policy details based on the inputs stored in the session, with enhanced confirmation and retry logic.
    
        - If a policy number is already provided, it fetches details and confirms with the user.
        - If a mobile number is available, it retrieves linked policies, confirms one, and then confirms the details.
        - Users have two chances to correct their policy number if initial confirmations fail.
        """

        # CASE 1: Direct policy number provided in session
        if getattr(session, 'policy_number', None):
            policy_number = session.policy_number
            session.policy_details = fetch_policy_details_via_phone_number(policy_number)

            if session.policy_details:
                # Confirm policy details with user
                confirm_msg = (
                    f"कृपया इस जानकारी की पुष्टि करें: पॉलिसी नंबर {session.policy_details['policyno']} "
                    f"और बीमित व्यक्ति का नाम {session.policy_details['insured_name']}। क्या यह सही है? कृपया 'हाँ' या 'नहीं' कहें।")

                text_to_speech_func(confirm_msg)

                # user_response = (speech_to_text().strip().lower())
                # with st.spinner("Recording..."):
                #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
                # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
                user_input = handle_user_input(duration=5)
                if user_input is False:
                    session.transfer_reason = "Exceed the input limit"
                    message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                    text_to_speech_func(message)
                    return False

                prompt = """Please reply it in either 'yes' or 'no'"""
                user_response = call_openai(write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
                print(user_response)
                with st.chat_message("user"):
                    st.write(user_input)


                if "yes" in user_response or "confirm" in user_response or 'correct' in user_response:

                    message = "मैं आपकी जानकारी देख रही हूँ, कृपया एक पल इंतजार करें।"
                    text_to_speech_func(message)

                    return True
                else:
                    # Handle retries for direct policy number case
                    return handle_policy_retries(session)
            else:
                session.transfer_reason = "Policy details not found for the provided policy number"

                message = "पॉलिसी विवरण नहीं मिल पाया। मैं आपको एजेंट से जोड़ता हूँ।"
                text_to_speech_func(message)

                return False

        # CASE 2: Mobile number available
        elif getattr(session, 'mobile_number', None):
            mobile_number = session.mobile_number
            policy_numbers = extract_motor_policy_numbers(mobile_number)

            if not policy_numbers:
                session.transfer_reason = "No policy numbers found linked to the provided mobile number"

                message = "हम आपके मोबाइल नंबर से जुड़ी कोई पॉलिसी नहीं ढूंढ पाए। मैं आपको एजेंट से जोड़ता हूँ।"
                text_to_speech_func(message)

                return False

            confirmed_policy = None

            if len(policy_numbers) > 1:
                message = "इस नंबर से कई पॉलिसी जुड़ी हुई हैं। मुझे उन्हें एक-एक करके पुष्टि करने दें।"
                text_to_speech_func(message)

            for policy in policy_numbers:

                message = F"क्या आपकी पॉलिसी नंबर {policy} है? अगर यह सही है, तो कृपया हाँ या नहीं कहें।"
                text_to_speech_func(message)


                # user_reply = remove_fullstop_from_input(speech_to_text().strip().lower())
                # with st.spinner("Recording..."):
                #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
                # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
                user_input = handle_user_input(duration=5)
                if user_input is False:
                    session.transfer_reason = "Exceed the input limit"
                    message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                    text_to_speech_func(message)
                    return False

                prompt = """Please reply it in either 'yes' or 'no', please analyze the input and then respond"""
                user_response = call_openai(write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
                print(user_response)
                with st.chat_message("user"):
                    st.write(user_input)




                if "yes" in user_response.lower() or "confirm" in user_response.lower():
                    confirmed_policy = policy
                    session.policy_number = policy
                    break

            if not confirmed_policy:
                session.transfer_reason = "No policy number confirmed by the user"

                message = "मैं कोई पॉलिसी नंबर पुष्टि नहीं कर सका। मैं आपको एजेंट से जोड़ता हूँ।"
                text_to_speech_func(message)

                return False

            # Fetch and confirm details
            session.policy_details = fetch_policy_details_via_phone_number(confirmed_policy)
            if session.policy_details:
                confirm_msg = (
                    f"कृपया इस जानकारी की पुष्टि करें: पॉलिसी नंबर {session.policy_details['policyno']} "
                    f"और बीमित व्यक्ति का नाम {session.policy_details['insured_name']} है। क्या यह सही है?")

                text_to_speech_func(confirm_msg)


                # user_response = remove_fullstop_from_input(speech_to_text().strip().lower())
                # with st.spinner("Recording..."):
                #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
                # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
                user_input = handle_user_input(duration=5)
                if user_input is False:
                    session.transfer_reason = "Exceed the input limit"
                    message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                    text_to_speech_func(message)
                    return False

                prompt = """Please reply it in either 'yes' or 'no'"""
                user_response = call_openai(write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
                print(user_response)
                with st.chat_message("user"):
                    st.write(user_input)


                if "yes" in user_response.lower() or "confirm" in user_response.lower() :

                    message = "मैं आपकी जानकारी देख रही हूँ, कृपया एक पल इंतजार करें।"
                    text_to_speech_func(message)

                    return True
                else:
                    # Handle retries for mobile-derived policy number
                    return handle_policy_retries(session)
            else:
                session.transfer_reason = "Policy details not found for the confirmed policy number"

                message = "पॉलिसी विवरण नहीं मिल पाया। मैं आपको एजेंट से जोड़ता हूँ।"
                text_to_speech_func(message)

                return False

        # CASE 3: No relevant information
        else:
            session.transfer_reason = "koi polisi ya mobile number pradaan nahi kiyaa gya hai"

            message = "हमारे पास आगे बढ़ने के लिए पॉलिसी नंबर या मोबाइल नंबर होना चाहिए। मैं आपको एजेंट से जोड़ रही हूँ।"
            text_to_speech_func(message)

            return False
    except Exception as e:
        session.transfer_reason = f"Get policy details error: {str(e)}"
        message = "मुझे खेद है, सिस्टम समस्या के कारण मैं आपको एक एजेंट से जोड़ रही हूँ, जो आगे आपकी सहायता कर सकता है। कृपया इंतजार करें।"
        text_to_speech_func(message)
        return False


def handle_policy_retries(session: ClaimSession) -> bool:
    try:
        """Handles up to 2 retries for policy confirmation"""
        for attempt in range(2):

            message = "कृपया अपना पॉलिसी नंबर फिर से प्रदान करें।"
            text_to_speech_func(message)


            # new_policy = remove_fullstop_from_input(speech_to_text().strip().lower())
            # with st.spinner("Recording..."):
            #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=12)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False

            prompt = """Convert all the numbers to numeric format, return them in their numeric format only, not as text.
                Ex.: 'आठ छ 97745125' translated to '8697745125' not this 'eight six 97745125'"""
            new_policy = call_openai(write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(new_policy)
            with st.chat_message("user"):
                st.write(user_input)


            # Fetch fresh details
            policy_details = fetch_policy_details_via_phone_number(new_policy)
            if not policy_details:

                message = "उस नंबर से कोई पॉलिसी नहीं मिली। कृपया फिर से प्रयास करें।"
                text_to_speech_func(message)

                continue

            # Confirm new details
            confirm_msg = (
                f"कृपया इस जानकारी की पुष्टि करें: पॉलिसी नंबर {session.policy_details['policyno']} "
                f"और बीमित व्यक्ति का नाम {session.policy_details['insured_name']} है। क्या यह सही है?")

            text_to_speech_func(confirm_msg)

            # user_response = remove_fullstop_from_input(speech_to_text().strip().lower())
            # with st.spinner("Recording..."):
            #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=5)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False

            prompt = """Please reply it in either 'yes' or 'no'"""
            user_response = call_openai(write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(user_response)
            with st.chat_message("user"):
                st.write(user_input)

            if "yes" in user_response.lower() or "confirm" in user_response.lower():
                session.policy_details = policy_details
                session.policy_number = new_policy

                message = "मैं आपकी जानकारी देख रही हूँ, कृपया एक पल इंतजार करें।"
                text_to_speech_func(message)

                return True

            if attempt < 1:
                message="चलिए, एक और बार कोशिश करते हैं।"
                text_to_speech_func(message)


        # All retries exhausted
        session.transfer_reason = "Failed policy confirmation after 2 attempts"

        message = "हम आपकी पॉलिसी की पुष्टि नहीं कर पाए। मैं आपको एजेंट से जोड़ रही हूँ।"
        text_to_speech_func(message)

        return False
    except Exception as e:
        session.transfer_reason = f"Handle policy retries error: {str(e)}"
        message = "मुझे खेद है, सिस्टम समस्या के कारण मैं आपको एक एजेंट से जोड़ रही हूँ, जो आगे आपकी सहायता कर सकता है। कृपया इंतजार करें।"
        text_to_speech_func(message)
        return False



def insured_confirmation(session: ClaimSession):
    try:
        session.caller_details = {}
        message = "धन्यवाद। कृपया 'हाँ' या 'नहीं' में उत्तर दें, क्या आप ही बीमित व्यक्ति हैं?"
        text_to_speech_func(message)


        # confirm_insured_or_not = str(speech_to_text()).strip().lower()
        # with st.spinner("Recording..."):
        #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
        # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
        user_input = handle_user_input(duration=7)
        if user_input is False:
            session.transfer_reason = "Exceed the input limit"
            message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
            text_to_speech_func(message)
            return False

        prompt = """Please reply it in either 'yes' or 'no' in english from the given information."""
        confirm_insured_or_not = call_openai(write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
        print(confirm_insured_or_not)
        with st.chat_message("user"):
            st.write(user_input)


        if 'yes' in confirm_insured_or_not.lower() :
            session.caller_details["is_insured"] = True
            message = f"पुष्टि करने के लिए धन्यवाद, {session.policy_details['insured_name']}। चलिए, आपकी क्लेम की प्रक्रिया शुरू करते हैं।"
            text_to_speech_func(message)
        else:
            session.caller_details["is_insured"] = False
            message = "मुझे समझ में आ गया है कि आप बीमित व्यक्ति नहीं हैं। मुझे आपसे कुछ जानकारी प्राप्त करनी होगी।"
            text_to_speech_func(message)

            message = "कृपया मुझे बीमित व्यक्ति से अपने संबंध के बारे में बताएं।"
            text_to_speech_func(message)

            # with st.spinner("Recording..."):
            #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=7)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False

            prompt = """Please return the relation of the person with insured. only return the relationship like this : 'father', 'brother', etc."""
            relationship_with_insured = call_openai(
                write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(relationship_with_insured)
            session.caller_details['relationship'] = relationship_with_insured
            with st.chat_message("user"):
                st.write(user_input)



            message = "कृपया हमें अपना पूरा नाम बताएं।"
            text_to_speech_func(message)

            # with st.spinner("Recording..."):
            #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=7)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False

            prompt = """Please return the name in english"""
            name = call_openai(
                write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(name)
            session.caller_details['name'] = remove_fullstop_from_input(name)
            with st.chat_message("user"):
                st.write(user_input)



            message = "कृपया अपना मोबाइल नंबर प्रदान करें।"
            text_to_speech_func(message)

            # with st.spinner("Recording..."):
            #     handle_recording(duration=10)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=10)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False

            prompt = """Please return the mobile number of the person only the number nothing else."""
            mobile_number = call_openai(
                write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(mobile_number)
            with st.chat_message("user"):
                st.write(user_input)


            session.caller_details['mobile'] = remove_fullstop_from_input(mobile_number)
    except Exception as e:
        session.transfer_reason = f"insured confirmation error: {str(e)}"
        message = "मुझे खेद है, सिस्टम समस्या के कारण मैं आपको एक एजेंट से जोड़ रही हूँ, जो आगे आपकी सहायता कर सकता है। कृपया इंतजार करें।"
        text_to_speech_func(message)
        return False


def claim_type(session:ClaimSession):
    try:
        session.claim_details = {}

        message = "कृपया पुष्िट करें कि यह क्लेम दुर्घटना के लिए है या चोरी के लिए।"
        text_to_speech_func(message)

        # claim_type_response = str(speech_to_text()).strip().lower()
        # with st.spinner("Recording..."):
        #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
        # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
        user_input = handle_user_input(duration=5)
        if user_input is False:
            session.transfer_reason = "Exceed the input limit"
            message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
            text_to_speech_func(message)
            return False

        prompt = """Please translate it to english"""
        claim_type_response  = call_openai(
            write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
        print(claim_type_response)
        with st.chat_message("user"):
            st.write(user_input)

        prompt = f"""
        You are a claim type classifier. Your task is to strictly identify whether the given details represent an accident or theft.
    
        IMPORTANT RULES:
        - You MUST return ONLY ONE claim type: either "accident" or "theft".
        - If the details do NOT clearly indicate either accident or theft, respond with None.
        - Return the result in strict JSON format.
        - Do NOT provide multiple claim types or any additional explanations.
    
        Input Details: {claim_type_response}
    
        Expected Output Format:
        {{
            "claim_type": "accident" OR "claim_type": "theft"
        }}
        """

        claim_type_detail = extract_and_convert_to_json(call_openai(prompt))

        if 'theft' in claim_type_detail.get('claim_type'):
            session.transfer_reason = "Theft claim requires specialist handling"

            message = "मुझे समझ में आया कि यह चोरी का क्लेम है। आगे की सहायता के लिए मैं आपको एक विशेषज्ञ एजेंट से जोड़ती हूँ। कृपया इंतजार करें।"
            text_to_speech_func(message)

            session.claim_details['claim_type'] = 'theft'
            return False

        elif 'accident' in claim_type_detail.get('claim_type'):
            session.claim_details['claim_type'] = 'accident'
            message = "दुर्घटना के बारे में सुनकर मुझे खेद है। क्या आपने वाहन को किसी गैरेज में रिपोर्ट किया है?"
            text_to_speech_func(message)

            # response = str(speech_to_text()).strip().lower()
            # with st.spinner("Recording..."):
            #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=5)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False

            prompt = """Please reply in 'yes' or 'no', that the person has reported it to the garage or not"""
            response = call_openai(
                write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(response)
            with st.chat_message("user"):
                st.write(user_input)


            if 'no' in response.lower():
                session.transfer_reason = "Vehicle not reported to garage"
                message = "चूंकि वाहन को अभी तक गैरेज में रिपोर्ट नहीं किया गया है, मैं आपको अगले कदमों पर मार्गदर्शन के लिए एक एजेंट से जोड़ रही हूँ। कृपया इंतजार करें।"
                text_to_speech_func(message)

                return False

            message = "वाहन रिपोर्ट करने के लिए धन्यवाद। मुझे दुर्घटना के बारे में कुछ विवरण चाहिए होंगे। चलिए, इन्हें एक-एक करके देखते हैं।"
            text_to_speech_func(message)


            # Collect Accident Details
            message = "क्या आप दुर्घटना की तिथि इस प्रारूप में साझा कर सकते हैं: तारीख, महीना, और वर्ष?"
            text_to_speech_func(message)

            # accident_date = str(speech_to_text()).strip().lower()
            # with st.spinner("Recording..."):
            #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=7)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False

            prompt = """Please translate the given date into english"""
            accident_date = call_openai(
                write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(accident_date)
            accident_date = convert_to_dd_mm_yyyy(accident_date)
            with st.chat_message("user"):
                st.write(accident_date)


            policy_end_date = session.policy_details.get('policy_end_date')
            policy_start_date = session.policy_details.get('policy_start_date')

            policy_end_date = datetime.strptime(policy_end_date, "%d-%m-%Y")
            policy_start_date = datetime.strptime(policy_start_date, "%d-%m-%Y")

            formatted_accident_date = datetime.strptime(accident_date, "%d/%m/%Y")
            if policy_start_date < formatted_accident_date < policy_end_date:
                session.claim_details['accident_date'] = accident_date
            else:
                message = "कृपया यह सुनिश्चित करें कि हानि की तिथि पॉलिसी अवधि के भीतर हो। चलिए, एक बार फिर कोशिश करते हैं। कृपया तिथि को फिर से साझा करें।"
                text_to_speech_func(message)
                user_input = handle_user_input(duration=7)
                if user_input is False:
                    message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                    text_to_speech_func(message)
                    session.transfer_reason = "Exceed the input limit"
                    return False

                prompt = """Please translate the given date into english"""
                accident_date = call_openai(
                    write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
                print(accident_date)
                accident_date = convert_to_dd_mm_yyyy(accident_date)
                formatted_accident_date = datetime.strptime(accident_date, "%d/%m/%Y")

                with st.chat_message("user"):
                    st.write(accident_date)

                if policy_start_date < formatted_accident_date < policy_end_date:
                    session.claim_details['accident_date'] = accident_date
                else:
                    message = "दुर्घटना की तिथि पॉलिसी अवधि के भीतर होनी चाहिए। मैं आपको और जानकारी के लिए एजेंट से जोड़ रही हूँ। कृपया थोड़ी देर इंतजार करें।"
                    text_to_speech_func(message)
                    session.transfer_reason= "Policy is Expired."
                    return False



            message = "कृपया दुर्घटना का समय प्रदान करें।"
            text_to_speech_func(message)

            # accident_time = str(speech_to_text()).strip().lower()
            # with st.spinner("Recording..."):
            #     handle_recording(duration=5)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=5)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False


            prompt = """Please translate it to english"""
            accident_time = call_openai(
                write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(accident_time)
            with st.chat_message("user"):
                st.write(user_input)

            if accident_time:
                prompt = f"""
                   You are a time modifier. Your task is to modify the time as per below given rules.
    
                   IMPORTANT RULES:
                   - You MUST return ONLY modified time.
                    Ex.:    '02:30 PM' should be converted to "HourOfLoss": "14", "MinOfLoss": "30" 
                            '8 in the morning' should be converted to "HourOfLoss": "08", "MinOfLoss": "00" 
                   - Return the result in strict JSON format.
    
                   Input Details: {accident_time}
    
                   Expected Output Format:
                   {{
                       "HourOfLoss": "Hour",
                       "MinOfLoss": "Minute" 
                   }}
                   """

                hour_and_minute = extract_and_convert_to_json(call_openai(prompt))
                session.claim_details['HourOfLoss'] = hour_and_minute['HourOfLoss']
                session.claim_details['MinOfLoss'] = hour_and_minute['MinOfLoss']

            message = "कृपया दुर्घटना का स्थान प्रदान करें।"
            text_to_speech_func(message)

            # session.claim_details['accident_location'] = str(speech_to_text()).strip().lower()
            # with st.spinner("Recording..."):
            #     handle_recording(duration=7)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=7)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False


            prompt = """Please translate it to english"""
            accident_location = call_openai(
                write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(accident_location)
            with st.chat_message("user"):
                st.write(user_input)

            session.claim_details['accident_location'] = remove_fullstop_from_input(accident_location)


            message ="कृपया ड्राइवर का नाम प्रदान करें।"
            text_to_speech_func(message)

            # session.claim_details['driver_info'] = str(speech_to_text()).strip().lower()
            # with st.spinner("Recording..."):
            #     handle_recording(duration=7)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=7)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False


            prompt = """Please translate it to english"""
            driver_name = call_openai(
                write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(driver_name)
            with st.chat_message("user"):
                st.write(user_input)

            session.claim_details['driver_info'] = remove_fullstop_from_input(driver_name)



            message = "कृपया दुर्घटना के बारे में कुछ जानकारी प्रदान करें।"
            text_to_speech_func(message)

            # session.claim_details['accident_info'] = str(speech_to_text()).strip().lower()
            # with st.spinner("Recording..."):
            #     handle_recording(duration=7)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=7)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False


            prompt = """Please translate it to english"""
            accident_info = call_openai(
                write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(accident_info)
            with st.chat_message("user"):
                st.write(user_input)
            session.claim_details['accident_info'] = remove_fullstop_from_input(accident_info)

            return True
    except Exception as e:
        session.transfer_reason = f"Claim type error: {str(e)}"
        message = "मुझे खेद है, सिस्टम समस्या के कारण मैं आपको एक एजेंट से जोड़ रही हूँ, जो आगे आपकी सहायता कर सकता है। कृपया इंतजार करें।"
        text_to_speech_func(message)
        return False


def garage_validation(session:ClaimSession):
    try:
        session.garage_details = {}

        # Step 1: Ask for pincode
        message = "कृपया गैरेज का पिनकोड प्रदान करें।"
        text_to_speech_func(message)

        # pincode_input = str(speech_to_text()).strip().lower()
        # with st.spinner("Recording..."):
        #     handle_recording(duration=7)  # Assuming handle_recording is your recording function
        # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
        user_input = handle_user_input(duration=7)
        if user_input is False:
            session.transfer_reason = "Exceed the input limit"
            message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
            text_to_speech_func(message)
            return False

        prompt = """Convert all the numbers to numeric format, return them in their numeric format only, not as text.
                Ex.: 'आठ छ 97745125' translated to '8697745125' not this 'eight six 97745125'"""
        pincode_input = call_openai(
            write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
        print(pincode_input)
        with st.chat_message("user"):
            st.write(user_input)

        pincode = re.sub(r"[.-]", "", pincode_input)
        # pincode = "110042"

        message = "पिनकोड प्रदान करने के लिए धन्यवाद। मैं अब उस पिनकोड के लिए हमारे रिकॉर्ड्स जांच रही हूँ।"
        text_to_speech_func(message)

        # Step 2: Query database
        try:
            records = fetch_garage(pincode=pincode)
        except Exception as e:
            session.transfer_reason = e
            message = "मुझे खेद है, सिस्टम समस्या के कारण मैं आपको एक एजेंट से जोड़ रही हूँ, जो आगे आपकी सहायता कर सकता है। कृपया इंतजार करें।"
            text_to_speech_func(message)
            return False

        # Step 3: Handle no garages found
        if len(records) == 0:
            session.transfer_reason = "No garages found in pincode"
            message = "उस पिनकोड में कोई गैरेज नहीं मिला। मैं अब आगे की सहायता के लिए आपको एजेंट से जोड़ रही हूँ। कृपया इंतजार करें।"
            text_to_speech_func(message)

            return False

        # Step 4: Single garage found
        elif len(records) == 1:
            garage = {
                'GarageID': records[0][0],
                'GarageName': records[0][4],
                'Address': records[0][5],
                'Pincode': records[0][6]
            }

            message = f"हमें {garage['GarageName']} गैरेज मिला है, जो {garage['Address']} पर स्थित है। क्या यह सही है?"
            text_to_speech_func(message)

            # confirmation = str(speech_to_text()).strip().lower()
            # with st.spinner("Recording..."):
            #     handle_recording(duration=7)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=5)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False


            prompt = """Please reply in 'yes' or 'no'"""
            confirmation = call_openai(
                write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(confirmation)
            with st.chat_message("user"):
                st.write(user_input)


            if 'yes' in confirmation.lower():
                message = "गैरेज को हमारे सिस्टम में सत्यापित कर लिया गया है। चलिए, क्लेम की प्रक्रिया आगे बढ़ाते हैं।"
                text_to_speech_func(message)

                session.garage_details = garage
                return True
            else:
                session.transfer_reason = "User rejected single garage match"
                message = "कृपया इंतजार करें, मैं आपको आगे की सहायता के लिए एक एजेंट से जोड़ रही हूँ।"
                text_to_speech_func(message)
                return False

        # Step 5: Multiple garages found
        else:
            # Multiple garages found, ask for garage name
            message = "हमें उस पिनकोड में कई गैरेज मिले हैं। कृपया गैरेज का नाम प्रदान करें।"
            text_to_speech_func(message)

            # garage_name_input = str(speech_to_text()).strip().lower()
            # with st.spinner("Recording..."):
            #     handle_recording(duration=7)  # Assuming handle_recording is your recording function
            # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
            user_input = handle_user_input(duration=7)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                text_to_speech_func(message)
                return False


            prompt = """Please translate the given name in english"""
            garage_name_input = call_openai(
                write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
            print(garage_name_input)
            with st.chat_message("user"):
                st.write(user_input)


            garage_name = re.sub(r"[.-]", "", garage_name_input)

            # Filter records by garage name (case-insensitive partial match)
            matching_garages = []
            for record in records:
                if garage_name in record[4].lower():
                    matching_garages.append({
                        'GarageID': record[0],
                        'GarageName': record[4],
                        'Address': record[5],
                        'Pincode': record[6]
                    })
            # No name matches
            if len(matching_garages) == 0:
                message = "कोई सटीक मेल नहीं मिला। पुष्टि के लिए मैं इस पिनकोड में सभी गैरेज की सूची दे रही हूँ:"
                text_to_speech_func(message)

                selected_garage = None

                # List all garages in the pincode for confirmation
                for record in records:
                    garage = {
                        'GarageID': record[0],
                        'GarageName': record[4],
                        'Address': record[5],
                        'Pincode': record[6]
                    }
                    message = f"क्या आपका मतलब {garage['GarageName']} है, जो {garage['Address']} पर स्थित है?"
                    text_to_speech_func(message)

                    # response = str(speech_to_text()).strip().lower()
                    # with st.spinner("Recording..."):
                    #     handle_recording(duration=7)  # Assuming handle_recording is your recording function
                    # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
                    user_input = handle_user_input(duration=5)
                    if user_input is False:
                        session.transfer_reason = "Exceed the input limit"
                        message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                        text_to_speech_func(message)
                        return False

                    prompt = """Please reply in 'yes' or 'no'"""
                    response = call_openai(
                        write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
                    print(response)
                    with st.chat_message("user"):
                        st.write(user_input)


                    if 'yes' in response.lower():
                        selected_garage = garage
                        break

                if selected_garage:
                    message = f"हमने {selected_garage['GarageName']} की पुष्टि की है। गैरेज सत्यापित हो चुका है। अब, चलिए क्लेम की प्रक्रिया आगे बढ़ाते हैं।"
                    text_to_speech_func(message)

                    session.garage_details = selected_garage
                    return True
                else:
                    session.transfer_reason = "No garage selected from multiple options"
                    message = "कोई भी गैरेज आपके अनुरोध से मेल नहीं खाता। कृपया इंतजार करें, मैं आपको आगे की सहायता के लिए एक एजेंट से जोड़ रही हूँ।"
                    text_to_speech_func(message)
                    return False

            # Single name match
            elif len(matching_garages) == 1:
                garage = matching_garages[0]
                message = f"हमें {garage['GarageName']} मिला है, जो {garage['Address']} पर स्थित है। क्या यह सही है?"
                text_to_speech_func(message)

                # confirmation = str(speech_to_text()).strip().lower()
                # with st.spinner("Recording..."):
                #     handle_recording(duration=7)  # Assuming handle_recording is your recording function
                # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
                user_input = handle_user_input(duration=5)
                if user_input is False:
                    session.transfer_reason = "Exceed the input limit"
                    message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                    text_to_speech_func(message)
                    return False

                prompt = """Please reply in 'yes' or 'no'"""
                confirmation = call_openai(
                    write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
                print(confirmation)
                with st.chat_message("user"):
                    st.write(user_input)


                if 'yes' in confirmation.lower():
                    message = "गैरेज को हमारे सिस्टम में सत्यापित कर लिया गया है। चलिए, क्लेम की प्रक्रिया आगे बढ़ाते हैं।"
                    text_to_speech_func(message)

                    session.garage_details = garage
                    return True
                else:
                    session.transfer_reason = "User rejected single name-matched garage"
                    message = "कृपया इंतजार करें, मैं आपको आगे की सहायता के लिए एक एजेंट से जोड़ रही हूँ।"
                    text_to_speech_func(message)
                    return False

            # Multiple name matches
            else:
                message = "उस नाम के कई गैरेज हैं। मैं प्रत्येक को चेक करता हूँ:"
                text_to_speech_func(message)
                selected_garage = None

                for garage in matching_garages:
                    message = f"क्या यह {garage['GarageName']} है, जो {garage['Address']} पर स्थित है?"
                    text_to_speech_func(message)

                    # response = str(speech_to_text()).strip().lower()
                    # with st.spinner("Recording..."):
                    #     handle_recording(duration=7)  # Assuming handle_recording is your recording function
                    # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
                    user_input = handle_user_input(duration=5)
                    if user_input is False:
                        session.transfer_reason = "Exceed the input limit"
                        message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
                        text_to_speech_func(message)
                        return False

                    prompt = """Please reply in 'yes' or 'no'"""
                    response = call_openai(
                        write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
                    print(response)
                    with st.chat_message("user"):
                        st.write(user_input)


                    if 'yes' in response.lower():
                        selected_garage = garage
                        break

                if selected_garage:
                    message = f"आपने {selected_garage['GarageName']} की पुष्टि की है, जो {selected_garage['Address']} पर स्थित है। गैरेज सत्यापित हो चुका है। चलिए, क्लेम की प्रक्रिया आगे बढ़ाते हैं।"
                    text_to_speech_func(message)

                    session.garage_details = selected_garage
                    return True
                else:
                    session.transfer_reason = "No garage selected from multiple name matches"

                    message = "कोई भी गैरेज चयनित नहीं किया गया है। अब मैं आपको एजेंट से जोड़ रही हूँ। कृपया इंतजार करें।"
                    text_to_speech_func(message)
                    return False
    except Exception as e:
        session.transfer_reason = f"garage validation error: {str(e)}"
        message = "मुझे खेद है, सिस्टम समस्या के कारण मैं आपको एक एजेंट से जोड़ रही हूँ, जो आगे आपकी सहायता कर सकता है। कृपया इंतजार करें।"
        text_to_speech_func(message)
        return False


def proceed_with_claim(session):
    try:
        # Prepare API payload
        payload = {
            "PolicyNo": '160221923730000221',
            "IntimaterName": session.caller_details.get('name', session.policy_details.get('insured_name')),
            "MinOfLoss": session.claim_details.get('MinOfLoss', "57"),
            "CreatedBy": "3539",
            "IntimaterMobileNo": session.caller_details.get('mobile', session.mobile_number),
            "InsuredName": session.policy_details.get('insured_name', 'JALPAN R SHAH'),
            "LOSSDATE": session.claim_details.get('accident_date', 'N/A'),
            "DescriptionOfLoss": session.claim_details.get("accident_info", 'N/A'),
            "DriverName": session.claim_details.get('driver_info', 'Unknown'),
            "HourOfLoss": session.claim_details.get('HourOfLoss', "12"),
            "RequestSource": "4708",
            "InsuredMobileNumber": session.policy_details.get('CONTACTNO_MOBILE', '9876543210'),
            "ReasonForDelayInIntimation": "1",
            "InsuredWhatsappNumber": session.policy_details.get('CONTACTNO_MOBILE', '9876543210'),
            "InsuredEmailId": session.policy_details.get('EmailID', "a@b.com"),
            "InsuredWhatsappConsent": "True",
            "EstimatedLoss": "1",
            "GarageID": session.garage_details.get('GarageID', '0000')
        }
        print(payload)

        # Confirm details with user
        message = (
            "कृपया पुष्टि करें कि सभी विवरण सही हैं: "
            f"पॉलिसी नंबर: {session.policy_details.get('policyno')}, " 
            f"बीमित व्यक्ति का नाम: {payload['InsuredName']}, " 
            f"दुर्घटना की तिथि: {payload['LOSSDATE']}, " 
            f"स्थान: {session.claim_details.get('accident_location', 'N/A')}, " 
            f"ड्राइवर: {payload['DriverName']}, " 
            "क्या यह सही है?"
                   )
        text_to_speech_func(message)

        # confirmation = speech_to_text().strip().lower()
        # with st.spinner("Recording..."):
        #     handle_recording(duration=7)  # Assuming handle_recording is your recording function
        # user_input = speech_to_text_azure_streamlit_hindi().strip().lower()
        user_input = handle_user_input(duration=5)
        if user_input is False:
            session.transfer_reason = "Exceed the input limit"
            message = "माफ़ कीजिए, मुझे आपकी तरफ से कोई जानकारी नहीं मिली है, इसलिए अब मैं कॉल डिस्कनेक्ट कर रही हूँ।"
            text_to_speech_func(message)
            return False

        prompt = """Please reply in 'yes' or 'no'"""
        confirmation = call_openai(
            write_prompt_for_hindi_to_english(input_text=user_input, instructions=prompt))
        print(confirmation)
        with st.chat_message("user"):
            st.write(user_input)


        if 'yes' in confirmation.lower():
            message = "अब मैं आपका क्लेम intimation ID जनरेट कर रही हूँ। कृपया एक क्षण इंतजार करें, मैं इसे प्रोसेस कर रही हूँ।"
            text_to_speech_func(message)

            #API call
            response = requests.post("http://mplusuat.reliancegeneral.co.in:9443/VAPTMobile/claims.svc/GETCLAIMNO_GARAGEAPP", json=payload)

            # Handle API failure
            if not response or response.status_code != 200:
                session.transfer_reason = "Claim API failure"
                message = "मुझे खेद है, सिस्टम समस्या के कारण मैं आपका क्लेम intimation ID जनरेट करने में परेशानी का सामना कर रही हूँ। मैं आपको एक एजेंट से जोड़ रही हूँ, जो आगे आपकी सहायता कर सकता है। कृपया इंतजार करें।"
                text_to_speech_func(message)

                return False

            # Parse the JSON response
            response_data = response.json()
            print(response_data)

            # if response_data.get("Result") and len(response_data["Result"]) > 0:
            #     session.claim_details['claim_no'] = response_data['Result'][0].get('ClaimNo', 'Unknown')
            if response_data.get("Result") and len(response_data["Result"]) > 0:
                first_result = response_data["Result"][0]
                status = first_result.get("Status")

                if status == "Success":
                    # Success case: Store ClaimNo in claim_details
                    session.claim_details['claim_no'] = first_result.get('ClaimNo', 'Unknown')
                elif status == "Failure":
                    # Failure case: Store error in transfer_reason and return False
                    error_response = first_result.get("Errorresponse", "")
                    session.transfer_reason = error_response

                    message = "कुछ तकनीकी समस्या है, मैं आपको आगे की जानकारी के लिए एक एजेंट से जोड़ रही हूँ। कृपया इंतजार करें।"
                    text_to_speech_func(message)
                    return False
                else:
                    # Handle unexpected status
                    session.transfer_reason = f"Unexpected status: {status}"

                    message = "सिस्टम में त्रुटि हुई है। एजेंट से जोड़ रही हूँ। कृपया इंतजार करें।"
                    text_to_speech_func(message)
                    return False
            else:
                # Handle missing or empty Result
                session.transfer_reason = "No result data found in the response."

                message = "उत्तर में कोई परिणाम नहीं मिला। मैं आपको आगे की सहायता के लिए एजेंट से जोड़ रही हूँ। कृपया इंतजार करें।"
                text_to_speech_func(message)
                return False


            # Final confirmation
            message = (
                    "क्लेम सफलतापूर्वक पंजीकृत हो गया है! आपका क्लेम intimation नंबर है: " +
                    " ".join(session.claim_details['claim_no']) +
                    " हम जल्द ही SMS के माध्यम से पुष्टि भेजेंगे।"
            )
            text_to_speech_func(message)
            return True

        else:
            session.transfer_reason = "User requested details correction"
            message = "मैं आपको विवरण सुधारने के लिए एक एजेंट से जोड़ रही हूँ। कृपया इंतजार करें।"
            text_to_speech_func(message)
            return False

    except Exception as e:
        session.transfer_reason = f"Claim processing error: {str(e)}"
        message = "मुझे खेद है, सिस्टम समस्या के कारण मैं आपको एक एजेंट से जोड़ रही हूँ, जो आगे आपकी सहायता कर सकता है। कृपया इंतजार करें।"
        text_to_speech_func(message)
        return False

def conclusion_step(session):
    try:
        message = "हमारी क्लेम हेल्पलाइन से संपर्क करने के लिए धन्यवाद। यदि आपको और सहायता की आवश्यकता हो, तो कृपया हमें फिर से संपर्क करें या हमारी वेबसाइट पर जाएं। आपका दिन शुभ हो!"
        text_to_speech_func(message)
    except Exception as e:
        session.transfer_reason = f"Conclusion step error: {str(e)}"
        message = "मुझे खेद है, सिस्टम समस्या के कारण मैं आपको एक एजेंट से जोड़ रही हूँ, जो आगे आपकी सहायता कर सकता है। कृपया इंतजार करें।"
        text_to_speech_func(message)


def hindi_claim_intimation_flow(session: ClaimSession, mobile_number=None):
    # session = ClaimSession()
    # Initial Greetings
    # text_to_speech1_english(text="Namaste! Welcome to our claim helpline.")

    if validate_mobile_number(mobile_number):
        session.mobile_number = mobile_number
        if not get_policy_details(session):
            print(session.__dict__)
            return redirecting_to_agent(session.transfer_reason)
    else:
        if not ask_mobile_or_policy_number(session):
            print(session.__dict__)
            return redirecting_to_agent(session.transfer_reason)
        if session.mobile_number or session.policy_number:
            if not get_policy_details(session):
                print(session.__dict__)
                return redirecting_to_agent(session.transfer_reason)

    insured_confirmation(session)

    if not claim_type(session):
        print(session.__dict__)
        return redirecting_to_agent(session.transfer_reason)

    if not garage_validation(session):
        print(session.__dict__)
        return redirecting_to_agent(session.transfer_reason)

    if not proceed_with_claim(session):
        print(session.__dict__)
        return redirecting_to_agent(session.transfer_reason)

    conclusion_step(session)

    print(session.__dict__)