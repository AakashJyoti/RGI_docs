import asyncio
import websockets
import json
import base64
import wave

async def test_websocket():
    uri = "ws://127.0.0.1:8001/ws/audio/594528/"  # Update with your WebSocket URL
    # uri = "wss://ivrspeechbotuat.brobotinsurance.com/ws/audio/594528/"
    # uri = "wss://ivrspeechbotuat.brobotinsurance.com/ws/audio/594529/"
    async with websockets.connect(uri) as websocket:
        # Send start event with correct media_format parameters
        start_event = {
            "event": "start",
            "sequence_number": 1,
            "stream_sid": "594528",
            "start": {
                "stream_sid": "594528",
                "call_sid": "594528",
                "account_sid": "594528",
                "from": "XXXXXXXXXX",
                "to": "XXXXXXXXXX",
                "custom_parameters": {},
                # Update bit_rate to "16" if your file is 16-bit
                "media_format": {
                    "encoding": "PCM",
                    "sample_rate": "16000",   # in Hz
                    "bit_rate": "16"         # update this if needed
                }
            }
        }
        await websocket.send(json.dumps(start_event))
        print(f"Sent start event: {start_event}")

        # Open WAV file and extract raw PCM data (skip header)
        audio_file = "bot_response.wav"  # Update this path
        with wave.open(audio_file, 'rb') as wf:
            n_channels = wf.getnchannels()      # Expected: 1 (mono)
            sampwidth = wf.getsampwidth()         # 1 for 8-bit, 2 for 16-bit, etc.
            framerate = wf.getframerate()         # Expected: 8000 Hz
            raw_data = wf.readframes(wf.getnframes())
            n_frames = wf.getnframes()
            duration = n_frames / framerate
            print(f"Channels: {n_channels}, Sample Width: {sampwidth} bytes, "
          f"Frame Rate: {framerate} Hz, Duration: {duration:.2f} sec")

        # Calculate chunk size in bytes: samples per chunk * sample width
        chunk_duration = 0.02  # 20 ms
        chunk_size = int(framerate * chunk_duration * sampwidth)
        print(f"Chunk size: {chunk_size} bytes (sampwidth: {sampwidth})")

        chunk_number = 1
        timestamp = 0  # in milliseconds
        for i in range(0, len(raw_data), chunk_size):
            chunk = raw_data[i:i+chunk_size]
            if not chunk:
                break

            payload = base64.b64encode(chunk).decode('utf-8')
            media_event = {
                "event": "media",
                "sequence_number": chunk_number,
                "stream_sid": "594528",
                "media": {
                    "chunk": chunk_number,
                    "timestamp": str(timestamp),
                    "payload": payload
                }
            }
            await websocket.send(json.dumps(media_event))
            print(f"Sent media event: chunk {chunk_number}, timestamp {timestamp}")
            await asyncio.sleep(chunk_duration)
            chunk_number += 1
            timestamp += int(chunk_duration * 1000)

        # Send stop event
        stop_event = {
            "event": "stop",
            "sequence_number": chunk_number,
            "stream_sid": "594528",
            "stop": {
                "call_sid": "594528",
                "account_sid": "594528",
                "reason": "stopped"
            }
        }
        await websocket.send(json.dumps(stop_event))
        print(f"Sent stop event: {stop_event}")

        # Optionally, receive final response
        response = await websocket.recv()
        print(f"Received: {response}")

asyncio.get_event_loop().run_until_complete(test_websocket())