import requests
import re
import xml.etree.ElementTree as ET

def call_soap_api(phone_number):
    url = "https://leadservices.brobotinsurance.com/rgiChatbot/ChatbotIntegrationWrapper.asmx"  # The API URL
    headers = {
        "Content-Type": "text/xml;charset=UTF-8",
        "SOAPAction": "http://tempuri.org/ChatbotGetPolDataOnMobileNoWrap"
    }

    soap_request = f"""
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
       <soapenv:Header/>
       <soapenv:Body>
          <tem:ChatbotGetPolDataOnMobileNoWrap>
             <tem:XML><![CDATA[<CHATBOT><UserID>CHATBOT</UserID><Password>CHATBOT@123</Password><CallerAppID>16</CallerAppID><MobileNo>{phone_number}</MobileNo></CHATBOT>]]></tem:XML>
          </tem:ChatbotGetPolDataOnMobileNoWrap>
       </soapenv:Body>
    </soapenv:Envelope>
    """

    try:
        response = requests.post(url, data=soap_request, headers=headers)
        if response.status_code == 200:
            raw_xml = response.text
            return raw_xml
        else:
            print(f"Error: Received status code {response.status_code}")
            return None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None



def extract_motor_policy_numbers(ph_nu):

    xml_response = call_soap_api(ph_nu)

    if isinstance(xml_response, list):
        xml_response = "".join(xml_response)  # Ensure it is a string
    # Parse the SOAP envelope
    root = ET.fromstring(xml_response)

    # Find the response content inside the SOAP response
    namespaces = {'soap': 'http://schemas.xmlsoap.org/soap/envelope/'}
    result_element = root.find(".//soap:Body", namespaces)

    if result_element is None:
        return "Invalid response format."

    # Extract the CDATA content manually
    cdata_content = "".join(result_element.itertext()).strip()
    if not cdata_content:
        return "Invalid CDATA format."

    # Remove CDATA wrapping if present
    cdata_content = re.sub(r'<!\[CDATA\[(.*?)\]\]>', r'\1', cdata_content, flags=re.DOTALL).strip()

    # Parse the extracted CDATA XML
    try:
        rgic_root = ET.fromstring(cdata_content)
    except ET.ParseError:
        return "Failed to parse extracted XML."

    response_code = rgic_root.find("ResponseCode").text if rgic_root.find("ResponseCode") is not None else ""
    response_message = rgic_root.find("ResponseMessage").text if rgic_root.find("ResponseMessage") is not None else ""
    if response_code == "1" and "No Record Found" in response_message:
        # return "Please provide a different number."
        return "No information found for the provided number. Please try a different one." # call to agent instead of another try

    policy_numbers = []

    # Extract all PolicyDetails elements correctly
    policy_details = rgic_root.findall(".//PolicyDetails")
    for policy in policy_details:
        lob_name_element = policy.find("LOBName")
        policy_no_element = policy.find("PolicyNo")

        if lob_name_element is not None and policy_no_element is not None:
            lob_name = lob_name_element.text.strip().lower()
            policy_no = policy_no_element.text.strip()

            if lob_name == "motor":
                policy_numbers.append(policy_no)

    # return policy_numbers if policy_numbers else "We didn't find a motor policy."
    return policy_numbers if policy_numbers else "No information found for the provided number." # call to agent instead of another try