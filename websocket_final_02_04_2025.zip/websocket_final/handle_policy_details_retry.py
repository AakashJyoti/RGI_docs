import time

from .utils import speech_to_text_azure_streamlit_chunks, text_to_speech_azure_streamlit
from .handle_user_input_retries import handle_user_input
from .policy_details_api import fetch_policy_details_via_policy_number

async def handle_policy_retries(session, websocket_class) -> bool:
    sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()
    try:
        """Handles up to 2 retries for policy confirmation"""
        max_attempts = 0
        # for attempt in range(2):
        while max_attempts < 2:
            max_attempts += 1
            # text_to_speech1_english("Please provide your policy number again.")
            # streamlit UI
            message = "Please provide your policy number again."
            # text_to_speech_func_english(message)
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            # new_policy = handle_user_input(duration=10)
            # if new_policy is False:
            #     session.transfer_reason = "Exceed the input limit"
            #     message = "Sorry, I haven’t received any input from you, so I’ll be disconnecting the call now."
            #     text_to_speech_func_english(message)
            #     return False
            new_policy = await handle_user_input(websocket_class)

            if new_policy is False:
                session.transfer_reason = "Exceed the input limit"
                return False

            # Fetch fresh details
            policy_details = fetch_policy_details_via_policy_number(new_policy)
            if not policy_details:
                message = "No policy found with that number. Please try again."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                continue

            # Confirm new details
            message = (
                f"Please confirm: Policy Number {policy_details['policyno']}, "
                f"Insured Name {policy_details['insured_name']}. Is this correct?"
            )
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            # user_input = handle_user_input(duration=5)
            # if user_input is False:
            #     session.transfer_reason = "Exceed the input limit"
            #     message = "Sorry, I haven’t received any input from you, so I’ll be disconnecting the call now."
            #     text_to_speech_func_english(message)
            #     return False
            user_input = await handle_user_input(websocket_class)

            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                return False

            if "yes" in user_input or "confirm" in user_input:
                session.policy_details = policy_details
                session.policy_number = new_policy

                message = "Just a moment, let me pull up your policy details."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                return True

            if max_attempts < 1:
                message = "Let's try one more time."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

        # All retries exhausted
        session.transfer_reason = "Failed policy confirmation after 2 attempts"
        message = "We couldn't verify your policy. Transferring you to an agent."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        await websocket_class.transfer_to_agent(reason=session.transfer_reason)
        time.sleep(2)
        return False

    except Exception as e:
        session.transfer_reason = f"Handle policy retries error: {str(e)}"
        # streamlit UI
        message = "I'm sorry, due to a system issue, I'm connecting you to an agent who can assist you further. Please wait."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        await websocket_class.transfer_to_agent(reason=session.transfer_reason)
        time.sleep(2)
        return False
