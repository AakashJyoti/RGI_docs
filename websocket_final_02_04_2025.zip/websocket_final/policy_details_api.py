

def fetch_policy_details_via_policy_number(policy_number):
    print("calling fetch_policy_details_via_phone_number API.......")
    policy_details = {
        "policyno": policy_number,
        "covernote_number": "R16102457625",
        "insured_name": "Suman Jena",
        "policy_start_date": "21-10-2024",
        "policy_end_date": "20-01-2025",
        "EngineNo": "L15A72239611",
        "ChassisNo": "MAKGM252JBN213414",
        "VehiclNo": "MH-43-AJ-4484",
        "Endt_Type": "Fresh Policy",
        "SYSTEM_Posting_Date": "2024-10-16T14:16:00",
        "CONTACTNO_MOBILE": "9876543210",
        "EmailID": "suman.jena@gmail.com",
        "FirstName": "Suman",
        "LastName": "Jena",
        "Address": "PLOT NO 88 BHUBANESWAR GAUTAM NAGARPS BARAGADA BJB NAGAR S OKHORDHA KHORDHA ORISSA INDIA 751014",
        "CityName": "BHUBANESWAR",
        "DistrictName": "KHORDHA",
        "StateName": "ODISHA",
        "Pinno": "751014",
        "DOB": None,
        "Gender": None,
        "StateID": 25,
        "DistrictID": 383,
        "CityID": 261273,
        "Endt_no": "0",
        "PRODUCT_CODE": "2311",
    }
    return policy_details
