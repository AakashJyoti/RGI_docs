import os
import time
from.policy_details_api import fetch_policy_details_via_policy_number
from .utils import speech_to_text_azure_streamlit_chunks, text_to_speech_azure_streamlit
from .handle_user_input_retries import handle_user_input
from .handle_policy_details_retry import handle_policy_retries
from .extract_linked_policy_numbers import extract_motor_policy_numbers

async def get_policy_details(session, websocket_class):
    """
    This function obtains policy details based on the inputs stored in the session, with enhanced confirmation and retry logic.

    - If a policy number is already provided, it fetches details and confirms with the user.
    - If a mobile number is available, it retrieves linked policies, confirms one, and then confirms the details.
    - Users have two chances to correct their policy number if initial confirmations fail.
    """
    # base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    # parent_directory = os.path.dirname(base_path)  # Go up one directory
    # output_file = os.path.join(parent_directory, "audio", "Bot", "bot_response.wav")
    sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()


    try:
        # CASE 1: Direct policy number provided in session
        if getattr(session, 'policy_number', None):
            policy_number = session.policy_number
            session.policy_details = fetch_policy_details_via_policy_number(policy_number)

            if session.policy_details:
                # Confirm policy details with user
                message = (
                    f"Please confirm your policy number {session.policy_details['policyno']} "
                    f"and insured name is {session.policy_details['insured_name']}. "
                    "Is this correct? Please say 'yes' or 'no'."
                )
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

                # user_input = handle_user_input(duration=5)
                # Wait for the stop event
                # await websocket_class.stop_event.wait()  # Wait until the stop event is set
                # combined_audio = websocket_class.combined_audio_chunks
                # user_input = speech_to_text_azure_streamlit_chunks(combined_audio)
                # print(user_input)
                user_input = await handle_user_input(websocket_class)

                if user_input is False:
                    session.transfer_reason = "Exceed the input limit"
                    return False


                if "yes" in user_input or "confirm" in user_input:
                    # if user_response in ['yes', 'confirm']:
                    # text_to_speech1_english("Just a moment, let me pull up your policy details.")
                    # streamlit UI
                    message = "Just a moment, let me pull up your policy details."
                    # text_to_speech_func_english(message)
                    text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    return True
                else:
                    # Handle retries for direct policy number case
                    return handle_policy_retries(session,websocket_class)
            else:
                session.transfer_reason = "Policy details not found for the provided policy number"
                message = "The policy details could not be found. Let me connect you with an agent."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                time.sleep(2)
                return False


        elif getattr(session, 'mobile_number', None):
            mobile_number = session.mobile_number
            policy_numbers = extract_motor_policy_numbers(mobile_number)

            if not policy_numbers:
                session.transfer_reason = "No policy numbers found linked to the provided mobile number"
                message = "We could not locate any policies linked with your mobile number. Let me connect you with an agent."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                time.sleep(2)
                return False

            policy_count = len(policy_numbers)
            confirmed_policy = None

            if policy_count == 1:
                confirmed_policy = policy_numbers[0]
                session.policy_number = confirmed_policy
                message = "Proceeding with your policy intimation."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            elif 1 < policy_count < 4:
                message = "There are multiple policies linked to your number. Please select one to proceed."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

                for policy in policy_numbers:
                    last_seven_digits = policy[-7:]
                    message = f"If your policy ends with {last_seven_digits}, say 'yes' to proceed."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

                    user_input = await handle_user_input(websocket_class)

                    if user_input is False:
                        session.transfer_reason = "Exceed the input limit"
                        return False

                    if "yes" in user_input or "confirm" in user_input:
                        confirmed_policy = policy
                        session.policy_number = policy
                        break

            elif policy_count >= 4:
                message = "There are multiple policies linked to your number. Please say the last seven digits of the policy you want to proceed with."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

                user_input = await handle_user_input(websocket_class)

                if user_input is False:
                    session.transfer_reason = "Exceed the input limit"
                    return False

                matched_policies = [policy for policy in policy_numbers if policy.endswith(user_input)]
                if len(matched_policies) == 1:
                    confirmed_policy = matched_policies[0]
                    session.policy_number = confirmed_policy
                else:
                    session.transfer_reason = "Policy number could not be identified"
                    message = "I couldn't confirm the policy number. Let me connect you with an agent."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                    time.sleep(2)
                    return False

            if not confirmed_policy:
                session.transfer_reason = "No policy number confirmed by the user"
                message = "I couldn't confirm any policy number. Let me connect you with an agent."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                time.sleep(2)
                return False

            # Fetch and confirm details
            session.policy_details = fetch_policy_details_via_policy_number(confirmed_policy)
            if session.policy_details:
                message = (
                    f"Please confirm: Policy Number {session.policy_details['policyno']}, "
                    f"Insured Name {session.policy_details['insured_name']}. Is this correct?"
                )
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

                user_input = await handle_user_input(websocket_class)

                if user_input is False:
                    session.transfer_reason = "Exceed the input limit"
                    return False

                if "yes" in user_input or "confirm" in user_input:
                    message = "Just a moment, let me pull up your policy details."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    return True
                else:
                    return handle_policy_retries(session,websocket_class)
            else:
                session.transfer_reason = "Policy details not found for the confirmed policy number"
                message = "The policy details could not be found. Let me connect you with an agent."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                return False

        # CASE 3: No relevant information
        else:
            session.transfer_reason = "No policy or mobile number provided"
            message = "We need either a policy number or mobile number to proceed. Transferring you to an agent."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
            await websocket_class.transfer_to_agent(reason=session.transfer_reason)
            time.sleep(2)
            return False

    except Exception as e:
        session.transfer_reason = f"get policy details error: {str(e)}"
        message = "I'm sorry, due to a system issue, I'm connecting you to an agent who can assist you further. Please wait."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        await websocket_class.transfer_to_agent(reason=session.transfer_reason)
        time.sleep(2)
        return False