import os
from dataclasses import dataclass
from typing import Dict, Any


from .utils import text_to_speech_azure_streamlit, speech_to_text_azure_streamlit, speech_to_text_azure_streamlit_chunks
from .mobile_number_validation import validate_mobile_number
from .policy_details_func import get_policy_details
from .handle_user_input_retries import handle_user_input

@dataclass
class ClaimSession:
    """Central data storage for claim process"""
    selected_language: str = None
    auth_attempts: int = 0
    date_attempts: int = 0
    policy_number: str = 160221923730000221
    mobile_number: str = None
    policy_details: Dict[str, Any] = None
    caller_details: Dict[str, Any] = None
    claim_details: Dict[str, Any] = None
    garage_details: Dict[str, Any] = None
    transfer_reason: str = None



async def claim_intimation_flow(mobile_number, websocket_class):
    session = ClaimSession()

    print(mobile_number)
    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    output_file = os.path.join(parent_directory, "audio", "Bot", "bot_response.wav")
    sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()

    # Language Selection
    welcome_message = "Namaste! Welcome to our claim helpline. Would you prefer to continue in Hindi or English?"
    print(welcome_message)
    text_to_speech_azure_streamlit(welcome_message)
    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)


    # Wait for the stop event
    user_input = await handle_user_input(websocket_class)
    # await websocket_class.stop_event.wait()  # Wait until the stop event is set
    # combined_audio = websocket_class.combined_audio_chunks
    # user_input = speech_to_text_azure_streamlit_chunks(combined_audio)
    # print(user_input)

    if user_input is False:
        # message = "Sorry, I haven’t received any input from you, so I’ll be disconnecting the call now."
        # text_to_speech_azure_streamlit(message)
        # await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        session.transfer_reason = "Exceed the input limit"
        websocket_class.close()

    elif 'english' in user_input:
        session.selected_language = 'english'
        if validate_mobile_number(mobile_number):
            session.mobile_number = mobile_number
            print(mobile_number)
            if not await get_policy_details(session, websocket_class):
                print(session.__dict__)
                websocket_class.close()
        else:
            print("hello")
    #
    #
    # # Wait for the stop event
    # await websocket_class.stop_event.wait()  # Wait until the stop event is set
    #
    # # # Process the received audio packets
    # # user_audio_file = f"{websocket_class.call_sid}.wav"  # The file saved in handle_stop_event
    # # user_text = speech_to_text_azure_streamlit(user_audio_file)
    # # print(f"User said: {user_text}")
    #
    # combined_audio = websocket_class.combined_audio_chunks
    #
    #





# async def claim_intimation_flow_demo(mobile_number, websocket_class):
#     base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
#     parent_directory = os.path.dirname(base_path)  # Go up one directory
#     output_file = os.path.join(parent_directory, "audio", "Bot", "bot_response.wav")
#     sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()
#
#     # Language Selection
#     welcome_message = "Namaste! Welcome to our claim helpline. Would you prefer to continue in Hindi or English?"
#     text_to_speech_azure_streamlit(welcome_message)
#
#     print("sample",sample_rate, sampwidth, n_channels)
#     print(f"before stream audio back: {output_file}")
#     await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
#
#
#     # Wait for the stop event
#     await websocket_class.stop_event.wait()  # Wait until the stop event is set
#
#     # # Process the received audio packets
#     # user_audio_file = f"{websocket_class.call_sid}.wav"  # The file saved in handle_stop_event
#     # user_text = speech_to_text_azure_streamlit(user_audio_file)
#     # print(f"User said: {user_text}")
#
#
#     combined_audio = websocket_class.combined_audio_chunks
#     print(f"audio chunks result: {speech_to_text_azure_streamlit_chunks(combined_audio)}")
#
#
#
#
#     welcome_message = "thank you for selecting the language"
#     text_to_speech_azure_streamlit(welcome_message)
#
#     await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
#
#
#     # Wait for the stop event
#     await websocket_class.stop_event.wait()  # Wait until the stop event is set
#
#     # # Process the received audio packets
#     # user_audio_file = f"{websocket_class.call_sid}.wav"  # The file saved in handle_stop_event
#     # user_text = speech_to_text_azure_streamlit(user_audio_file)
#     # print(f"User said: {user_text}")
#
#     combined_audio = websocket_class.combined_audio_chunks
#     print(f"audio chunks result 2 : {speech_to_text_azure_streamlit_chunks(combined_audio)}")
#
#     print("after")
#
