import os

import azure.cognitiveservices.speech as speechsdk
from dotenv import load_dotenv
from datetime import datetime
from openai import AzureOpenAI
import re
import json
from azure.cognitiveservices.speech import SpeechConfig, AudioConfig, SpeechRecognizer, ResultReason, AudioDataStream

load_dotenv()

subscription_key = os.getenv("SPEECH_KEY")
region = os.getenv("SPEECH_REGION")



def text_to_speech_azure_streamlit(input_text, output_file=None):

    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    output_file = os.path.join(parent_directory, "audio", "Bot", "bot_response.wav")

    speech_config = speechsdk.SpeechConfig(subscription=subscription_key, region=region)
    audio_config = speechsdk.audio.AudioOutputConfig(filename=output_file)

    # The language of the voice that speaks.
    speech_config.speech_synthesis_voice_name = 'en-IN-AartiNeural'

    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)

    # Synthesize the input text to the specified output file.
    speech_synthesizer.speak_text(input_text)

    return output_file

text_to_speech_azure_streamlit("hello good morning ")
from azure.cognitiveservices.speech import SpeechConfig, AudioConfig, SpeechRecognizer, ResultReason, AudioDataStream

def speech_to_text_azure_streamlit(filename="D:/reliance/claim_agent/audio/User/example.wav"):

    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    filename = os.path.join(parent_directory, "audio", "User", "example.wav")

    # time.sleep(1)
    # Set up Azure Speech Config
    speech_config = SpeechConfig(subscription=subscription_key, region=region)
    # Create an audio configuration
    audio_config = AudioConfig(filename=filename)  # Use the default audio input device
    # Create a speech recognizer
    recognizer = SpeechRecognizer(speech_config=speech_config, audio_config=audio_config, language="en-IN")
    # time.sleep(2)
    # st.text("listening... Say something")
    # print("Say something...")
    # Recognize audio
    result = recognizer.recognize_once()
    if result.reason == ResultReason.RecognizedSpeech:
        # print("Result",result.text)
        return result.text
    elif result.reason == ResultReason.NoMatch:
        return None
    elif result.reason == ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        return f"Speech Recognition canceled: {cancellation_details.reason}"

def speech_to_text_azure_streamlit_chunks(combined_audio):
    """
    Converts in-memory audio chunks to text using Azure Speech-to-Text.

    Parameters:
    - audio_chunks (list of bytes): List containing audio data in bytes.

    Returns:
    - str: Recognized text from the audio.
    """
    # Combine all audio chunks into a single byte stream

    # Set up Azure Speech Config
    speech_config = speechsdk.SpeechConfig(subscription=subscription_key, region=region)

    # Create a PushAudioInputStream and write the combined audio data
    stream_format = speechsdk.audio.AudioStreamFormat(
        samples_per_second=16000, bits_per_sample=16, channels=1
    )
    push_stream = speechsdk.audio.PushAudioInputStream(stream_format)
    push_stream.write(combined_audio)
    push_stream.close()

    # Create an AudioConfig object using the push stream
    audio_config = speechsdk.audio.AudioConfig(stream=push_stream)

    # Create a speech recognizer
    recognizer = speechsdk.SpeechRecognizer(
        speech_config=speech_config, audio_config=audio_config, language="en-IN"
    )
    # Recognize audio
    result = recognizer.recognize_once()
    if result.reason == speechsdk.ResultReason.RecognizedSpeech:
        return result.text
    elif result.reason == speechsdk.ResultReason.NoMatch:
        return None
    elif result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        return f"Speech Recognition canceled: {cancellation_details.reason}"



def remove_fullstops_from_input(input):
    if input.endswith('.'):
        input = input[:-1]

    return input
