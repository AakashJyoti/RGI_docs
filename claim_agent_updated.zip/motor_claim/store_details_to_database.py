import json
import os
from datetime import datetime

dummy_data ={'selected_language': 'English', 'auth_attempts': 0, 'date_attempts': 0, 'policy_number': '160221923730000221', 'mobile_number': None, 'policy_details': {'policyno': '160221923730000221', 'covernote_number': 'R16102457625',
            'insured_name': 'Suman Jena', 'policy_start_date': '21-10-2024', 'policy_end_date': '20-01-2025', 'EngineNo': 'L15A72239611', 'ChassisNo': 'MAKGM252JBN213414', 'VehiclNo': 'MH-43-AJ-4484', 'Endt_Type': 'Fresh Policy',
            'SYSTEM_Posting_Date': '2024-10-16T14:16:00', 'CONTACTNO_MOBILE': '9876543210', 'EmailID': 'suman.jena@gmail.com', 'FirstName': 'Suman', 'LastName': 'Jena',
            'Address': 'PLOT NO 88 BHUBANESWAR GAUTAM NAGARPS BARAGADA BJB NAGAR S OKHORDHA KHORDHA ORISSA INDIA 751014', 'CityName': 'BHUBANESWAR', 'DistrictName': 'KHORDHA', 'StateName': 'ODISHA', 'Pinno': '751014', 'DOB': None,
            'Gender': None, 'StateID': 25, 'DistrictID': 383, 'CityID': 261273, 'Endt_no': '0', 'PRODUCT_CODE': '2311'}, 'caller_details': {'is_insured': True}, 'claim_details': {'claim_type': 'accident', 'accident_date': '12/01/2025',
            'HourOfLoss': '12', 'MinOfLoss': '30', 'accident_location': 'ahmedabad', 'driver_info': 'ronak patel', 'accident_info': 'someone hit my vehicle and then ran away'}}
             # 'garage_details': {'GarageID': '100343614', 'GarageName': 'Tractor', 'Address': 'Ludhiana ', 'Pincode': '141001'}, 'transfer_reason': 'Intimator name or mobile number is missing<br>'}


# with open("D:/reliance/claim_agent/data/claim_intimation_data.json","a+",encoding='utf-8') as res_file:
#     res_file.write(str(dummy_data))
#     res_file.close()

# def append_to_json_dict(file_path, new_data_dict):
#     try:
#         # Load existing data from the JSON file
#         with open(file_path, 'r') as file:
#             data = json.load(file)
#
#         # Ensure the existing data is a dictionary
#         if not isinstance(data, dict):
#             raise ValueError("The JSON root should be a dictionary to append items.")
#     except (json.JSONDecodeError, FileNotFoundError):
#         # If file is empty or not found, start with an empty dictionary
#         data = {}
#
#     # Merge the new data into the existing dictionary
#     data.update(new_data_dict)
#
#     # Write the updated data back to the file
#     with open(file_path, 'w') as file:
#         json.dump(data, file, indent=4)
#     print("Data appended successfully!")

def append_to_single_json_file(new_data, file_path="D:/reliance/claim_agent/data/claim_intimation_data.json"):
    try:
        # Check if the file exists and load existing data
        if os.path.exists(file_path):
            with open(file_path, 'r') as file:
                data = json.load(file)

            # Ensure it's a list
            if not isinstance(data, list):
                raise ValueError("The JSON root should be a list to append items.")
        else:
            data = []  # Start with an empty list if file doesn't exist

    except (json.JSONDecodeError, FileNotFoundError):
        # If file is empty or has invalid JSON, start with an empty list
        data = []

    # Add a timestamp to the new data for identification
    new_data_with_timestamp = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data": new_data
    }

    # Append the new data
    data.append(new_data_with_timestamp)

    # Write the updated data back to the file
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

    print("Data appended successfully!")


append_to_single_json_file( dummy_data)

# append_to_json_dict("D:/reliance/claim_agent/data/claim_intimation_data.json", dummy_data)