import os

import azure.cognitiveservices.speech as speechsdk
from dotenv import load_dotenv
from datetime import datetime
from openai import AzureOpenAI
import re
import json
from azure.cognitiveservices.speech import SpeechConfig, AudioConfig, SpeechRecognizer, ResultReason, AudioDataStream

load_dotenv()

subscription_key = os.getenv("SPEECH_KEY")
region = os.getenv("SPEECH_REGION")

def speech_to_text():
    # This example requires environment variables named "SPEECH_KEY" and "SPEECH_REGION"
    speech_config = speechsdk.SpeechConfig(subscription=subscription_key, region=region)
    speech_config.speech_recognition_language="en-US"

    audio_config = speechsdk.audio.AudioConfig(use_default_microphone=True)
    speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)

    print("Speak into your microphone.")
    speech_recognition_result = speech_recognizer.recognize_once_async().get()

    if speech_recognition_result.reason == speechsdk.ResultReason.RecognizedSpeech:
        print("Recognized: {}".format(speech_recognition_result))
        return speech_recognition_result.text
    elif speech_recognition_result.reason == speechsdk.ResultReason.NoMatch:
        print("No speech could be recognized: {}".format(speech_recognition_result.no_match_details))
    elif speech_recognition_result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = speech_recognition_result.cancellation_details
        print("Speech Recognition canceled: {}".format(cancellation_details.reason))
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            print("Error details: {}".format(cancellation_details.error_details))
            print("Did you set the speech resource key and region values?")


def text_to_speech(text):
    # This example requires environment variables named "SPEECH_KEY" and "SPEECH_REGION"
    speech_config = speechsdk.SpeechConfig(subscription=subscription_key, region=region)
    audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)

    speech_config.speech_synthesis_voice_name = 'hi-IN-ArjunNeural'

    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)

    speech_synthesis_result = speech_synthesizer.speak_text_async(text).get()
    stream = speechsdk.AudioDataStream(speech_synthesis_result)
    stream.save_to_wav_file(f"D:\\reliance\\rgi\\recordings\\{speech_config.speech_synthesis_voice_name}.wav")
    # stream.save_to_wav_file(f"C:\\Users\\abhik\\PycharmProjects\\RGItest\\Hindi_samples\\{speech_config.speech_synthesis_voice_name}.wav")

    if speech_synthesis_result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        print("Speech synthesized for text [{}]".format(text))
    elif speech_synthesis_result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = speech_synthesis_result.cancellation_details
        print("Speech synthesis canceled: {}".format(cancellation_details.reason))
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            if cancellation_details.error_details:
                print("Error details: {}".format(cancellation_details.error_details))
                # print("Did you set the speech resource key and region values?")


# Connect with an Agent
def redirecting_to_agent(session_details):
    print(f"{session_details}")


 # Give the Website Link for Claim Intimation
def message_website():
    print("""I'm sorry, the garage you mentioned is not found in our records. I've sent a link to our 
        website for claim intimation to your registered mobile number. Would you like me to transfer you 
        to an agent for further assistance?""")


def call_openai(prompt):
    client = AzureOpenAI(
        azure_endpoint="https://brobotchatgpt.openai.azure.com/",
        api_key="d696ac8bd83a4679b9580b86ef104809",
        api_version="2024-02-01"
    )

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": f"{prompt}"},
        ]
    )
    answer = response.choices[0].message.content
    return answer


def extract_and_convert_to_json(text):
    # Regular expression to find the text between triple backticks if present
    # The regex now handles both lowercase and uppercase 'json'
    pattern = r'```(?:json\s*|JSON\s*)?(.*?)```'
    match = re.search(pattern, text, re.DOTALL)
    if match:
        json_str = match.group(1).strip()  # Extract and strip the text within the backticks
    else:
        json_str = text.strip()  # Use the entire text if no backticks are found
    if not json_str:  # Check if json_str is empty
        print("No JSON content found")
        return None
    try:
        # Convert the extracted or full text to a dictionary
        json_data = json.loads(json_str)
        return json_data
    except json.JSONDecodeError as e:
        print(f"Failed to decode JSON: {e}")
        return None


def remove_fullstop_from_input(input):
    if input.endswith('.'):
        input = input[:-1]

    return input



def text_to_speech1_english(text, output_directory="../audio"):
    """
    Converts text to speech and saves the generated audio to a specified directory.

    Args:
        text (str): The input text to be converted to speech.
        output_directory (str): The directory where the audio file will be saved.
        output_filename (str): The name of the audio file (with .wav extension).

    Returns:
        str: Full path to the saved audio file.
    """
    try:
        # Ensure the output directory exists
        os.makedirs(output_directory, exist_ok=True)

        # Configure speech settings
        speech_config = speechsdk.SpeechConfig(subscription=subscription_key, region=region)
        audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)
        # audio_config = speechsdk.audio.AudioConfig(filename="YourAudioFile.wav")

        # Set the voice
        speech_config.speech_synthesis_voice_name = 'en-IN-AartiNeural'
        # Create a synthesizer
        speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
        # Generate speech
        speech_synthesis_result = speech_synthesizer.speak_text_async(text).get()

        # Check if synthesis was successful
        if speech_synthesis_result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            # Save the audio to the specified file
            output_path = os.path.join(output_directory, "Current_stream.wav")
            stream = speechsdk.AudioDataStream(speech_synthesis_result)
            stream.save_to_wav_file(output_path)
            print(f"Speech synthesized for text: {text}")
            # print(f"Audio saved to: {output_path}")
            return output_path
        elif speech_synthesis_result.reason == speechsdk.ResultReason.Canceled:
            cancellation_details = speech_synthesis_result.cancellation_details
            print("Speech synthesis canceled: {}".format(cancellation_details.reason))
            if cancellation_details.reason == speechsdk.CancellationReason.Error and cancellation_details.error_details:
                print("Error details: {}".format(cancellation_details.error_details))
    except Exception as e:
        print(f"An error occurred: {e}")
        return None


def text_to_speech_hindi(text, output_directory="../audio"):
    """
    Converts text to speech and saves the generated audio to a specified directory.

    Args:
        text (str): The input text to be converted to speech.
        output_directory (str): The directory where the audio file will be saved.
        output_filename (str): The name of the audio file (with .wav extension).

    Returns:
        str: Full path to the saved audio file.
    """
    try:
        # Ensure the output directory exists
        os.makedirs(output_directory, exist_ok=True)

        # Configure speech settings
        speech_config = speechsdk.SpeechConfig(subscription=subscription_key, region=region)
        audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)
        # Set the voice
        speech_config.speech_synthesis_voice_name = 'hi-IN-ArjunNeural'
        # Create a synthesizer
        speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
        # Generate speech
        speech_synthesis_result = speech_synthesizer.speak_text_async(text).get()

        # Check if synthesis was successful
        if speech_synthesis_result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            # Save the audio to the specified file
            output_path = os.path.join(output_directory, "Current_stream.wav")
            stream = speechsdk.AudioDataStream(speech_synthesis_result)
            stream.save_to_wav_file(output_path)
            print(f"Speech synthesized for text: {text}")
            # print(f"Audio saved to: {output_path}")
            return output_path
        elif speech_synthesis_result.reason == speechsdk.ResultReason.Canceled:
            cancellation_details = speech_synthesis_result.cancellation_details
            print("Speech synthesis canceled: {}".format(cancellation_details.reason))
            if cancellation_details.reason == speechsdk.CancellationReason.Error and cancellation_details.error_details:
                print("Error details: {}".format(cancellation_details.error_details))
    except Exception as e:
        print(f"An error occurred: {e}")
        return None



def text_to_speech_azure_streamlit(input_text, output_file="D:/reliance/claim_agent/audio/Bot/bot_response.wav"):

    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    output_file = os.path.join(parent_directory, "audio", "Bot", "bot_response.wav")

    speech_config = speechsdk.SpeechConfig(subscription=subscription_key, region=region)
    audio_config = speechsdk.audio.AudioOutputConfig(filename=output_file)

    # The language of the voice that speaks.
    speech_config.speech_synthesis_voice_name = 'en-IN-AartiNeural'

    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)

    # Synthesize the input text to the specified output file.
    speech_synthesizer.speak_text(input_text)

    return output_file


from azure.cognitiveservices.speech import SpeechConfig, AudioConfig, SpeechRecognizer, ResultReason, AudioDataStream

def speech_to_text_azure_streamlit(filename="D:/reliance/claim_agent/audio/User/example.wav"):

    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    filename = os.path.join(parent_directory, "audio", "User", "example.wav")

    # time.sleep(1)
    # Set up Azure Speech Config
    speech_config = SpeechConfig(subscription=subscription_key, region=region)
    # Create an audio configuration
    audio_config = AudioConfig(filename=filename)  # Use the default audio input device
    # Create a speech recognizer
    recognizer = SpeechRecognizer(speech_config=speech_config, audio_config=audio_config, language="en-IN")
    # time.sleep(2)
    # st.text("listening... Say something")
    # print("Say something...")
    # Recognize audio
    result = recognizer.recognize_once()
    if result.reason == ResultReason.RecognizedSpeech:
        # print("Result",result.text)
        return result.text
    elif result.reason == ResultReason.NoMatch:
        return None
    elif result.reason == ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        return f"Speech Recognition canceled: {cancellation_details.reason}"


def text_to_speech_azure_streamlit_hindi(input_text, output_file="D:/reliance/claim_agent/audio/Bot/bot_response.wav"):

    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    output_file = os.path.join(parent_directory, "audio", "Bot", "bot_response.wav")

    speech_config = speechsdk.SpeechConfig(subscription=subscription_key, region=region)
    audio_config = speechsdk.audio.AudioOutputConfig(filename=output_file)

    # The language of the voice that speaks.
    speech_config.speech_synthesis_voice_name = 'hi-IN-AartiNeural'

    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)

    # Synthesize the input text to the specified output file.
    speech_synthesizer.speak_text(input_text)

    return output_file



def speech_to_text_azure_streamlit_hindi(filename="D:/reliance/claim_agent/audio/User/example.wav"):

    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    filename = os.path.join(parent_directory, "audio", "User", "example.wav")

    # time.sleep(1)
    # Set up Azure Speech Config
    speech_config = SpeechConfig(subscription=subscription_key, region=region)
    # Create an audio configuration
    audio_config = AudioConfig(filename=filename)  # Use the default audio input device
    # Create a speech recognizer
    recognizer = SpeechRecognizer(speech_config=speech_config, audio_config=audio_config, language="hi-IN")
    # time.sleep(2)
    # st.text("listening... Say something")
    # print("Say something...")
    # Recognize audio
    result = recognizer.recognize_once()
    if result.reason == ResultReason.RecognizedSpeech:
        # print("Result",result.text)
        return result.text
    elif result.reason == ResultReason.NoMatch:
        return None
    elif result.reason == ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        return f"Speech Recognition canceled: {cancellation_details.reason}"

