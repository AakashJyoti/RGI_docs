from django.db import models

class GarageMaster(models.Model):
    GarageID = models.IntegerField()
    City_or_Village_ID_PK = models.IntegerField(null=True, blank=True)
    DIstrictID = models.IntegerField(null=True, blank=True)
    State_ID_PK = models.IntegerField(null=True, blank=True)
    GarageName = models.CharField(max_length=100)
    Address = models.CharField(max_length=250)
    PinCode = models.CharField(max_length=10, null=True, blank=True)

    def __str__(self):
        return self.GarageName
