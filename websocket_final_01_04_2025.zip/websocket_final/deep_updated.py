import sounddevice as sd
from scipy.io.wavfile import write
import os

def handle_recording(duration):
    # filepath = "D:/reliance/claim_agent/audio/User/example.wav"

    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    filepath = os.path.join(parent_directory, "audio", "User", "example.wav")

    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    sample_rate = 16000
    input_channel = 1

    recording = sd.rec(
        int(duration * sample_rate),
        samplerate=sample_rate,
        channels=input_channel,
        dtype="int16",
    )
    sd.wait()
    write(filepath, sample_rate, recording)