import { NavLink, useNavigate } from "react-router";
import { useAuth } from "../store/useAuth";
import { removeAuthFromLocalStorage } from "../utils";

const Sidebar = () => {
  const navigate = useNavigate();
  const { resetAuth } = useAuth();

  const handleLogout = () => {
    removeAuthFromLocalStorage();
    resetAuth();
    navigate("/login");
  };

  return (
    <div className="w-48 bg-blue-500 text-white h-screen py-8 pl-4 flex flex-col justify-between">
      <nav className="flex flex-col gap-2">
        <NavLink
          to="/"
          className={({ isActive }) =>
            `block px-4 py-2 text-lg font-medium rounded-l-lg ${
              isActive ? "bg-white text-black" : "bg-blue-500 text-white"
            }`
          }
        >
          Home
        </NavLink>
        <NavLink
          to="/details"
          className={({ isActive }) =>
            `block px-4 py-2 text-lg font-medium rounded-l-lg ${
              isActive ? "bg-white text-black" : "bg-blue-500 text-white"
            }`
          }
        >
          Details
        </NavLink>
      </nav>
      <div className="flex justify-center items-center mr-4">
        <button
          className="bg-white font-bold text-black hover:text-blue-500 hover:bg-blue-50 px-12 py-2 rounded-xl shadow shadow-gray-500"
          onClick={handleLogout}
        >
          Logout
        </button>
      </div>
    </div>
  );
};
export default Sidebar;
