import { CloseIcon } from "../assets/svg";

type Props = {
  sessionId: string;
  toggleTransModal: () => void;
};

const TranscriptModal = ({ sessionId, toggleTransModal }: Props) => {
  return (
    <div className="absolute top-0 right-0 z-10 bg-black/50 w-screen h-screen flex justify-center items-center">
      <div className="bg-white h-[600px] w-[800px] rounded-xl p-4">
        <div className="flex mb-4 pl-4 justify-between">
          <p className="text-2xl border-b-2 border-gray-400">Transcriptions:</p>
          <div>
            <button onClick={toggleTransModal}>
              <CloseIcon />
            </button>
          </div>
        </div>
        <div>
          <p>Transcript for {sessionId}</p>
        </div>
      </div>
    </div>
  );
};
export default TranscriptModal;
