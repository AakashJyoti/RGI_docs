import type { RangePickerProps } from "antd/es/date-picker";
import dayjs, { Dayjs } from "dayjs";
import { DatePicker } from "antd";
import { useState } from "react";
import axios from "axios";
import { API_URL } from "../constant";
import { CloseIcon } from "../assets/svg";

const { RangePicker } = DatePicker;

const ReportDownload = () => {
  const [dates, setDates] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);

  const [value, setValue] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [realDates, setRealDates] = useState({ form: "", to: "" });
  const [showModal, setShowModal] = useState(false);

  const disabledDate: RangePickerProps["disabledDate"] = (current) => {
    return current && current > dayjs().endOf("day");
  };

  const onOpenChange = () => {
    if (value[0] && value[1]) {
      setRealDates({
        form: value[0].format("YYYY-MM-DD"),
        to: value[1].format("YYYY-MM-DD"),
      });
    }
  };

  const handleDownloadExcel = async () => {
    try {
      const response = await axios.get(
        `${API_URL}/downloadRecords?from=${realDates.form}&to=${realDates.to}`,
        {
          responseType: "blob",
        }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute(
        "download",
        `records_${realDates.form}-${realDates.to}.xlsx`
      );
      document.body.appendChild(link);
      link.click();

      // Clean up
      link.parentNode?.removeChild(link);
      window.URL.revokeObjectURL(url);

      setDates([null, null]);
      setValue([null, null]);
      setRealDates({ form: "", to: "" });
      setShowModal(false);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="relative">
      <button
        className="bg-blue-500 text-white h-10 w-32 rounded"
        onClick={() => setShowModal(true)}
      >
        Download
      </button>
      {showModal && (
        <div className="absolute top-0 right-0 bg-white w-[500px] shadow-lg rounded py-8 px-6 z-10 border-gray-200 border">
          <button className="absolute top-4 right-4 cursor-pointer">
            <CloseIcon />
          </button>
          <p className="text-xl font-semibold mb-2">Select Date:</p>
          <div className=" px-4 py-2 flex gap-2 items-center border border-gray-400 rounded">
            <p>Date:</p>
            <RangePicker
              value={dates}
              disabledDate={disabledDate}
              onCalendarChange={(val) => setDates(val as [Dayjs, Dayjs])}
              onChange={(val) => {
                setValue(val as [Dayjs, Dayjs]);
                if (val && val[0] && val[1]) {
                  setRealDates({
                    form: val[0].format("YYYY-MM-DD"),
                    to: val[1].format("YYYY-MM-DD"),
                  });
                }
              }}
              onOpenChange={onOpenChange}
              style={{ width: "100%", maxWidth: "400px" }}
            />
          </div>
          <div className="flex justify-end">
            <button
              className="text-white bg-blue-500 px-4 py-2 rounded mt-4"
              onClick={handleDownloadExcel}
            >
              Download Excel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReportDownload;
