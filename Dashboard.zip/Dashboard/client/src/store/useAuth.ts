import { create } from "zustand";

type AuthState = {
  isAuth: boolean;
  authCred: TAuthCred;
  setAuth: (cred: TAuthCred) => void;
  resetAuth: () => void;
};

export const useAuth = create<AuthState>((set) => ({
  isAuth: false,
  authCred: { name: "", password: "" },
  // isAuth: true,
  // authCred: { name: "Admin", password: "Admin@123" },
  setAuth: (cred: TAuthCred) => set({ authCred: cred, isAuth: true }),
  resetAuth: () => set({ authCred: { name: "", password: "" }, isAuth: false }),
}));
