import { useEffect, useState } from "react";
import TranscriptModal from "../components/TranscriptModal";
import { TranscriptIcon } from "../assets/svg";
import axios from "axios";
import { API_URL } from "../constant";
import { calculateDuration, formatDate } from "../utils";
import ReportDownload from "../components/ReportDownload";

type TDetails = {
  callerNo: string;
  conId: string;
  date: string;
  CIVRcallStartTime: string;
  CIVRcallEndTime: string;
  CIVRcallDuration: string;
  CallTransferStartTime: string;
  CallTransferEndTime: string;
  CallTransferDuration: string;
  callStatus: string;
  sessionId: string;
  transferVdn: string;
  language: string;
  nodeCategory: string;
  nodeNo: number;
};

type Tp = TDetails & {
  sno: number;
};

const DashboardDetails = () => {
  const [showModal, setShowModal] = useState(false);
  const [dashboardDetials, setDashboardDetials] = useState<Tp[]>([]);
  const [selecedCall, setSelecedCall] = useState<Tp>();
  const [pageDetails, setPageDetails] = useState<Pagination>({
    currentPage: 1,
    limit: 20,
    total: 0,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
  });

  const [searchFeild] = useState("");
  const [sortFor] = useState("");

  useEffect(() => {
    const getData = async () => {
      try {
        const { data } = await axios.get<PageinationApiResponse>(
          `${API_URL}/getRecords?page=${pageDetails.currentPage}&limit=${pageDetails.limit}&status=${sortFor}&search=${searchFeild}`
        );
        setPageDetails(data.pagination);
        const formattedData: Tp[] = data.data.map((item, index) => ({
          sno: index + 1,
          callerNo: item.caller_mobile,
          conId: item.call_sid,
          date: formatDate(item.created_at),
          CIVRcallStartTime: item.call_start_time.split("T")[1].split(".")[0],
          CIVRcallEndTime: item.call_end_time.split("T")[1].split(".")[0],
          CIVRcallDuration: calculateDuration({
            startTime: item.call_start_time,
            endTime: item.call_end_time,
          }),
          CallTransferStartTime: "",
          CallTransferEndTime: "",
          CallTransferDuration: "",
          callStatus: item.status,
          language: item.selected_language,
          sessionId: `${item.session_id}`,

          transferVdn: "",
          nodeCategory: "",
          nodeNo: 0,
        }));
        setDashboardDetials(formattedData);
      } catch (error) {
        console.log(error);
      }
    };

    getData();
  }, [pageDetails.currentPage, pageDetails.limit, searchFeild, sortFor]);

  const toggleTransModal = () => {
    setShowModal((prev) => !prev);
  };

  const handleTranscript = (val: Tp) => {
    setSelecedCall(val);
    toggleTransModal();
  };

  return (
    <>
      <div className="mx-auto py-9 h-screen overflow-auto">
        <div className="flex gap-4 justify-between mb-4">
          <div className="flex gap-4 justify-center items-center">
            <p className="text-xl font-semibold mb-1">Filters:</p>
            <div className="px-4 py-2 flex gap-2 items-center border border-gray-400 rounded min-w-64">
              <p>Status</p>
              <select
                name=""
                id=""
                className="flex-1 border border-gray-300 rounded px-4 py-1"
              >
                <option value="">Select</option>
              </select>
            </div>
          </div>
          <ReportDownload />
        </div>
        <table className="max-w-[1200px] bg-white border border-gray-300 text-sm">
          <thead>
            <tr className="border-b border-white text-white bg-blue-500">
              <th className="py-2 px-4 border-r">S.No.</th>
              <th className="py-2 px-2 border-r">Caller No.</th>
              <th className="py-2 px-2 border-r">Con Id</th>
              <th className="py-2 px-2 border-r w-28">
                Date <br />
                <span className="text-xs">(DD-MM-YYYY)</span>
              </th>
              <th className="py-2 px-2 border-r">Language</th>
              <th className="py-2 px-2 border-r">Node Category</th>
              <th className="py-2 px-2 border-r">Node no</th>
              <th className="py-2 px-4 border-r" colSpan={3}>
                CIVR Call Time
              </th>
              <th className="py-2 px-4 border-r" colSpan={3}>
                Call Transfer
              </th>
              <th className="py-2 px-4 border-r">Call Status</th>
              <th className="py-2 px-4 border-r">Transfer_vdn</th>
              <th className="py-2 px-4 border-r">Session Id</th>
              <th className="py-2 px-4">Call Transcription</th>
            </tr>
            <tr className="text-white bg-blue-500">
              <th className="py-2 px-4"></th>
              <th className="py-2 px-4"></th>
              <th className="py-2 px-4"></th>
              <th className="py-2 px-4"></th>
              <th className="py-2 px-4"></th>
              <th className="py-2 px-4"></th>
              <th className="py-2 px-4"></th>
              <th className="py-2 px-4 border-x">Start Time</th>
              <th className="py-2 px-4 border-r">End Time</th>
              <th className="py-2 px-4 border-r">Duration</th>
              <th className="py-2 px-4 border-r">Start Time</th>
              <th className="py-2 px-4 border-r">End Time</th>
              <th className="py-2 px-4 border-r">Duration</th>
              <th className="py-2 px-4"></th>
              <th className="py-2 px-4"></th>
              <th className="py-2 px-4"></th>
              <th className="py-2 px-4"></th>
            </tr>
          </thead>
          <tbody>
            {dashboardDetials.map((ele) => (
              <tr className="border-b" key={ele.sessionId}>
                <td className="py-2 px-4 text-center">{ele.sno}</td>
                <td className="py-2 px-4 text-center">{ele.callerNo}</td>
                <td className="py-2 px-4 text-center">{ele.conId}</td>
                <td className="py-2 px-4 text-center">{ele.date}</td>
                <td className="py-2 px-4 text-center">{ele.language}</td>
                <td className="py-2 px-4 text-center">{ele.nodeCategory}</td>
                <td className="py-2 px-4 text-center">{ele.nodeNo}</td>
                <td className="py-2 px-4 text-center">
                  {ele.CIVRcallStartTime}
                </td>
                <td className="py-2 px-4 text-center">{ele.CIVRcallEndTime}</td>
                <td className="py-2 px-4 text-center">
                  {ele.CIVRcallDuration}
                </td>
                <td className="py-2 px-4 text-center">
                  {ele.CallTransferStartTime}
                </td>
                <td className="py-2 px-4 text-center">
                  {ele.CallTransferEndTime}
                </td>
                <td className="py-2 px-4 text-center">
                  {ele.CallTransferDuration}
                </td>
                <td className="py-2 px-4 text-center">{ele.callStatus}</td>
                <td className="py-2 px-4 text-center">{ele.transferVdn}</td>
                <td className="py-2 px-4 text-center">{ele.sessionId}</td>
                <td className="py-2 px-4 text-center">
                  <div className="flex justify-center items-center">
                    <button type="button" onClick={() => handleTranscript(ele)}>
                      <TranscriptIcon />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="flex justify-between mt-4 items-center">
          <div className="flex gap-4 items-center">
            <label htmlFor="limit">Page size:</label>
            <select
              name="limit"
              id="limit"
              className="border border-gray-300 rounded px-4 py-1"
              value={pageDetails.limit}
              onChange={(e) =>
                setPageDetails((prev) => ({
                  ...prev,
                  limit: Number(e.target.value),
                }))
              }
            >
              <option value="20">20</option>
              <option value="30">30</option>
              <option value="40">40</option>
              <option value="50">50</option>
            </select>
          </div>

          <span>
            {pageDetails.currentPage} of{" "}
            {Math.ceil(pageDetails.total / pageDetails.limit)}
          </span>

          <div className="flex gap-2">
            <button
              className="px-4 py-2 w-24 bg-blue-500 text-white rounded disabled:bg-gray-300"
              disabled={!pageDetails.hasPreviousPage}
            >
              Previous
            </button>
            <button
              className="px-4 py-2 w-24 bg-blue-500 text-white rounded disabled:bg-gray-300"
              disabled={!pageDetails.hasNextPage}
            >
              Next
            </button>
          </div>
        </div>
      </div>
      {showModal && selecedCall?.sessionId && (
        <TranscriptModal
          sessionId={selecedCall?.sessionId}
          toggleTransModal={toggleTransModal}
        />
      )}
    </>
  );
};
export default DashboardDetails;
