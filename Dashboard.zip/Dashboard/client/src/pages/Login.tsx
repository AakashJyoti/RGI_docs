import { useForm, SubmitHandler } from "react-hook-form";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "../store/useAuth";
import { LoginPageBackgroundUrl } from "../constant";
import { saveAuthToLocalStorage } from "../utils";
import { HideIcon, ShowIcon } from "../assets/svg";

type Inputs = {
  userName: string;
  password: string;
};

const Login = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setError,
  } = useForm<Inputs>();

  const { setAuth, isAuth } = useAuth();

  useEffect(() => {
    if (isAuth) {
      navigate("/");
    }
  }, [isAuth, navigate]);

  const onSubmit: SubmitHandler<Inputs> = (data) => {
    if (
      data.userName !== import.meta.env.VITE_USERNAME ||
      data.password !== import.meta.env.VITE_PASSWORD
    ) {
      setError("root", {
        type: "manual",
        message: "Invalid username or password",
      });
      return;
    }
    const val = { name: data.userName, password: data.password };
    setAuth(val);
    saveAuthToLocalStorage(val);
    reset();
    navigate("/");
  };

  const handleShowPassword = () => {
    if (showPassword) {
      setShowPassword(false);
    } else {
      setShowPassword(true);
    }
  };

  return (
    <div
      className="h-screen w-screen flex justify-center items-center"
      style={{
        backgroundImage: `url(${LoginPageBackgroundUrl})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="absolute inset-0 bg-black/20"></div>

      <div className="rounded-2xl bg-white bg-opacity-90 backdrop-blur-sm shadow-2xl w-96 p-8">
        <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">
          Login
        </h1>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div>
            <label
              htmlFor="userName"
              className="block text-sm font-medium text-gray-700"
            >
              User Name
            </label>
            <input
              id="userName"
              type="text"
              className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              {...register("userName", {
                required: "User Name is required",
                minLength: {
                  value: 4,
                  message: "User Name must be at least 4 characters",
                },
                maxLength: {
                  value: 8,
                  message: "User Name must be maximum 8 characters",
                },
              })}
            />
            {errors.userName && (
              <span className="text-red-500 text-sm">
                {errors.userName.message}
              </span>
            )}
          </div>
          <div>
            <label
              htmlFor="password"
              className="block text-sm font-medium text-gray-700"
            >
              Password
            </label>
            <div className="relative">
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                {...register("password", {
                  required: "Password is required",
                  minLength: {
                    value: 6,
                    message: "Password must be at least 6 characters",
                  },
                  maxLength: {
                    value: 10,
                    message: "Password must be maximum 10 characters",
                  },
                })}
              />
              <div className="absolute top-0 right-2 h-full flex justify-center items-center z-10">
                <button onClick={handleShowPassword} type="button">
                  {showPassword ? <ShowIcon /> : <HideIcon />}
                </button>
              </div>
            </div>
            {errors.password && (
              <span className="text-red-500 text-sm">
                {errors.password.message}
              </span>
            )}
          </div>
          {errors.root && (
            <span className="text-red-500 text-sm block text-center">
              {errors.root.message}
            </span>
          )}
          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
