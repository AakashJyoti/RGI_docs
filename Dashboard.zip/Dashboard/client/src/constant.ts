export const API_URL = "/api/v1/records/";
// export const API_URL = "http://localhost:4200/api/v1/records/";

export const LoginPageBackgroundUrl =
  "https://images.unsplash.com/photo-1496167117681-944f702be1f4?q=80&w=1932&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D";

export const data1 = [
  {
    callerNo: "9900990099",
    conId: "Con123",
    date: "01-10-2023",
    CIVRcallStartTime: "10:00 AM",
    CIVRcallEndTime: "10:00 AM",
    CIVRcallDuration: "5 min",
    CallTransferStartTime: "10:00 AM",
    CallTransferEndTime: "10:00 AM",
    CallTransferDuration: "5 min",
    callStatus: "Completed",
    language: "English",
    sessionId: "12345670",
  },
  {
    callerNo: "9988779988",
    conId: "Con124",
    date: "01-11-2024",
    CIVRcallStartTime: "10:00 AM",
    CIVRcallEndTime: "10:00 AM",
    CIVRcallDuration: "5 min",
    CallTransferStartTime: "10:00 AM",
    CallTransferEndTime: "10:00 AM",
    CallTransferDuration: "5 min",
    callStatus: "Completed",
    language: "Hindi",
    sessionId: "12345671",
  },
];

export const data2 = [
  {
    callerNo: "9900990099",
    conId: "Con123",
    date: "01-10-2023",
    CIVRcallStartTime: "10:00 AM",
    CIVRcallEndTime: "10:00 AM",
    CIVRcallDuration: "5 min",
    CallTransferStartTime: "10:00 AM",
    CallTransferEndTime: "10:00 AM",
    CallTransferDuration: "5 min",
    callStatus: "Completed",
    sessionId: "12345670",
    transferVdn: "_",
    language: "Emglish",
    nodeNo: 14,
    nodeCategory: "Motor",
  },
  {
    callerNo: "9988779988",
    conId: "Con123",
    date: "01-11-2024",
    CIVRcallStartTime: "10:00 AM",
    CIVRcallEndTime: "10:00 AM",
    CIVRcallDuration: "5 min",
    CallTransferStartTime: "10:00 AM",
    CallTransferEndTime: "10:00 AM",
    CallTransferDuration: "5 min",
    callStatus: "Completed",
    sessionId: "12345671",
    transferVdn: "_",
    language: "Hindi",
    nodeNo: 18,
    nodeCategory: "Health",
  },
];
