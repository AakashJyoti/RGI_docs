import express from "express";
import cookieParser from "cookie-parser";
import cors from "cors";
import morgan from "morgan";
import bodyParser from "body-parser";
import path, { dirname } from "path";
import { fileURLToPath } from "url";
import allowControlAccess from "./middlewares/allowControlAccess.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();

app.use(cors());
app.use(express.static(path.join(__dirname, "../client/dist")));
app.use(express.json({ limit: "16kb" }));
app.use(express.urlencoded({ extended: true, limit: "16kb" }));
app.use(express.static("public"));
app.use(cookieParser());
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: false,
  })
);

app.use(allowControlAccess);

app.use(morgan("dev"));

app.on("error", (error) => {
  console.error("App ERROR: ", error);
  throw error;
});

// Routes import
import healthRouter from "./routes/healthCheck.routes.js";
import recordRouter from "./routes/records.routes.js";
import { ApiError } from "./utils/ApiError.js";

// Routes declaration
app.use("/api/v1/health", healthRouter);
app.use("/api/v1/records", recordRouter);

// Rendering UI
const routes = ["/", "/login", "/details"];

routes.forEach((route) => {
  app.get(route, (req, res) => {
    res.sendFile(path.join(__dirname, "../client/dist", "index.html"));
  });
});

app.get("*", (req, res, next) => {
  const error = new ApiError(404, "Path does not exist");
  res.status(error.statusCode).json({
    statusCode: error.statusCode,
    data: error.data,
    message: error.message,
    success: error.success,
    errors: error.errors,
  });
});

export { app };
