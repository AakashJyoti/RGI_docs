import { dbPool } from "../db/index.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { asyncHandler } from "../utils/AsyncHandler.js";
import ExcelJS from "exceljs";
import sql from "mssql";

const tableName = "MotorCallDetails";

const getAllRecords = asyncHandler(async (req, res) => {
  const result = await dbPool.request().query(`SELECT * FROM ${tableName}`);
  res.status(200).json(new ApiResponse(200, { data: result.recordset }));
});

const getRecords = asyncHandler(async (req, res) => {
  try {
    console.log("Received query params:", req.query); // Debug log

    // Pagination parameters
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    // Clean parameters
    const searchTerm = (req.query.search || "").trim();
    const statusFilter = (req.query.status || "").trim();

    console.log(
      `Processing request - page: ${page}, limit: ${limit}, search: '${searchTerm}', status: '${statusFilter}'`
    );

    // Base query
    let dataQuery = `SELECT * FROM ${tableName}`;
    let countQuery = `SELECT COUNT(*) as count FROM ${tableName}`;
    const conditions = [];
    const params = {};

    // Only add search condition if searchTerm is not empty
    if (searchTerm && searchTerm !== '""') {
      conditions.push(`(
        caller_mobile LIKE @searchTerm OR 
        call_sid LIKE @searchTerm OR 
        session_id LIKE @searchTerm
      )`);
      params.searchTerm = `%${searchTerm.replace(/"/g, "")}%`; // Remove quotes if present
    }

    // Only add status condition if statusFilter is not empty
    if (statusFilter && statusFilter !== '""') {
      conditions.push("status = @statusFilter");
      params.statusFilter = statusFilter.replace(/"/g, "");
    }

    // Add conditions if any exist
    if (conditions.length > 0) {
      const whereClause = " WHERE " + conditions.join(" AND ");
      dataQuery += whereClause;
      countQuery += whereClause;
    }

    // Add pagination
    dataQuery += ` ORDER BY id OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY`;
    params.offset = offset;
    params.limit = limit;

    console.log("Final data query:", dataQuery); // Debug log
    console.log("Final count query:", countQuery); // Debug log
    console.log("Query parameters:", params); // Debug log

    // Create request
    const request = dbPool.request();

    // Add parameters
    Object.keys(params).forEach((key) => {
      request.input(key, params[key]);
    });

    // Execute queries
    const dataResult = await request.query(dataQuery);
    const countResult = await request.query(countQuery);

    const rows = dataResult.recordset;
    const total = countResult.recordset[0].count;
    const totalPages = Math.ceil(total / limit);

    console.log(`Found ${rows.length} records out of ${total}`); // Debug log

    res.status(200).json({
      success: true,
      data: rows,
      pagination: {
        total,
        totalPages,
        currentPage: page,
        limit,
        hasNextPage: page < totalPages,
        hasPreviousPage: page > 1,
      },
      filters: {
        search: searchTerm,
        status: statusFilter || "all",
      },
    });
  } catch (error) {
    console.error("Database error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: process.env.NODE_ENV === "development" ? error.message : undefined,
    });
  }
});

const downloadRecords = asyncHandler(async (req, res) => {
  try {
    const { from, to } = req.query;

    if (!from || !to) {
      return res.status(400).json({
        success: false,
        message: "Both fromDate and toDate parameters are required",
      });
    }

    // Get filtered data by time range
    const result = await dbPool
      .request()
      .input("fromDate", sql.DateTime, new Date(from))
      .input("toDate", sql.DateTime, new Date(to)).query(`
        SELECT *
        FROM MotorCallDetails
        WHERE created_at BETWEEN @fromDate AND @toDate
      `);

    const rows = result.recordset.map((row) => {
      // Calculate duration in minutes
      const start = row.call_start_time ? new Date(row.call_start_time) : null;
      const end = row.call_end_time ? new Date(row.call_end_time) : null;
      const duration = start && end ? (end - start) / (1000 * 60) : null;

      return {
        ...row,
        call_duration_minutes: duration,
      };
    });

    // Create Excel workbook
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Records Data");

    // Define columns
    worksheet.columns = [
      { header: "ID", key: "id", width: 10 },
      { header: "Caller Number", key: "mobile_number", width: 20 },
      { header: "Con Id", key: "call_sid", width: 20 },
      {
        header: "Date",
        key: "created_at",
        width: 15,
        style: { numFmt: "dd-mm-yyyy" },
      },
      { header: "Language", key: "selected_language", width: 15 },
      {
        header: "Call Start",
        key: "call_start_time",
        width: 15,
        style: { numFmt: "hh:mm:ss AM/PM" },
      },
      {
        header: "Call End",
        key: "call_end_time",
        width: 15,
        style: { numFmt: "hh:mm:ss AM/PM" },
      },
      {
        header: "Duration (min)",
        key: "call_duration_minutes",
        width: 15,
        style: { numFmt: "0.00" },
      },

      { header: "Call status", key: "status", width: 15 },
      { header: "Session Id", key: "session_id", width: 10 },
    ];

    // Add formatted data
    rows.forEach((row) => {
      worksheet.addRow({
        ...row,
        call_start_time: row.call_start_time
          ? new Date(row.call_start_time)
          : null,
        call_end_time: row.call_end_time ? new Date(row.call_end_time) : null,
        created_at: row.created_at ? new Date(row.created_at) : null,
      });
    });

    // Style the header row
    worksheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: true };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FFD3D3D3" },
      };
    });

    // Set response headers for Excel download
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.setHeader(
      "Content-Disposition",
      `attachment; filename=Records_${from}_to_${to}.xlsx`
    );

    // Send the Excel file
    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    console.error("Error generating Excel report:", error);
    res.status(500).json({
      success: false,
      message: "Error generating Excel report",
      error: error.message,
    });
  }
});

export { getAllRecords, getRecords, downloadRecords };
