import { Router } from "express";
import {
  // getAllRecords,
  getRecords,
  downloadRecords,
} from "../controller/records.controller.js";

const router = Router();

// router.route("/getAllRecords").get(getAllRecords);
router.route("/getRecords").get(getRecords);
router.route("/downloadRecords").get(downloadRecords);

export default router;
