import { Router } from "express";
import { healthCheck } from "../controller/health.controller.js";

const router = Router();

router.route("/health_check").get(healthCheck);

export default router;
