import sql from "mssql";
import dotenv from "dotenv";
dotenv.config();

const config = {
  user: process.env.SQL_SERVER_USER,
  password: process.env.SQL_SERVER_PASSWORD,
  server: process.env.SQL_SERVER_HOST,
  database: process.env.SQL_SERVER_DB,
  port: parseInt(process.env.SQL_SERVER_PORT),
  options: {
    encrypt: false,
    trustServerCertificate: true,
  },
};

let dbPool;

async function connectDB() {
  try {
    dbPool = await sql.connect(config);
    console.log("Connected to SQL Server");
    return sql;
  } catch (err) {
    console.error("Database connection failed:", err);
    throw err;
  }
}

export { connectDB, dbPool };
