import dotenv from "dotenv";
import { connectDB } from "./db";
import { app } from "./app";

dotenv.config();

const PORT = process.env.PORT as string;

connectDB()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server is Running at ${PORT}`);
    });
  })
  .catch((err) => console.error("Database connection failed", err));
