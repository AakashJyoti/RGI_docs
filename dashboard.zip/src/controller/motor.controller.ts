import { Request, Response } from "express";
import sql from "mssql";
import { dbPool } from "../db/index";
import { tables } from "../constant";
import { asyncHandler } from "../utills/asyncHandler";
import { ApiResponse } from "../utills/ApiResponse";
import { ApiError } from "../utills/ApiError";
import { formatDate } from "../helper";
import { exportToExcel, getMotorExcelColumns } from "../utills/excelExport";

export const getAllMotorRecords = asyncHandler(
  async (req: Request, res: Response) => {
    if (!dbPool) {
      throw new ApiError(500, "Missing DB Connection.");
    }

    const result = await dbPool
      .request()
      .query(`SELECT * FROM ${tables.motor}`);
    res.status(200).json(new ApiResponse(200, { data: result.recordset }));
  }
);

export const getMotorRecords = asyncHandler(
  async (req: Request, res: Response) => {
    // Pagination parameters
    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = Math.min(
      100,
      Math.max(1, parseInt(req.query.limit as string) || 10)
    );
    const offset = (page - 1) * limit;

    // Clean parameters
    const searchTerm = ((req.query.search as string) || "").trim();
    const statusFilter = ((req.query.status as string) || "").trim();

    // Base query - modified to include recording data
    let dataQuery = `
    SELECT 
      r.*,
      rec.sas_url as sas_url,
      rec.uploaded_at as uploaded_at,
      rec.call_end_time as agent_call_end_time
    FROM ${tables.motor} r
    LEFT JOIN ${tables.recording} rec ON r.call_sid = rec.call_sid_id
  `;

    let countQuery = `SELECT COUNT(*) as count FROM ${tables.motor} r`;
    const conditions: string[] = [];
    const params: Record<string, any> = {};

    // Only add search condition if searchTerm is not empty
    if (searchTerm && searchTerm !== '""') {
      conditions.push(`(
        r.caller_mobile LIKE @searchTerm OR 
        r.call_sid LIKE @searchTerm OR 
        r.session_id LIKE @searchTerm
      )`);
      params.searchTerm = `%${searchTerm.replace(/"/g, "")}%`;
    }

    // Only add status condition if statusFilter is not empty
    if (statusFilter && statusFilter !== '""') {
      conditions.push("r.call_status = @statusFilter");
      params.statusFilter = statusFilter.replace(/"/g, "");
    }

    // Add conditions if any exist
    if (conditions.length > 0) {
      const whereClause = " WHERE " + conditions.join(" AND ");
      dataQuery += whereClause;
      countQuery += whereClause;
    }

    // Add pagination
    dataQuery += ` ORDER BY r.call_start_time DESC OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY`;
    params.offset = offset;
    params.limit = limit;

    // Create request
    if (!dbPool) {
      throw new ApiError(500, "Missing DB Connection.");
    }

    const request = dbPool.request();

    // Add parameters
    Object.keys(params).forEach((key) => {
      request.input(key, params[key]);
    });

    // Execute queries
    const dataResult = await request.query(dataQuery);
    const countResult = await request.query(countQuery);
    const statusResult = await request.query(
      `SELECT DISTINCT call_status FROM ${tables.motor} WHERE call_status IS NOT NULL`
    );

    const rows = dataResult.recordset;
    const total = countResult.recordset[0].count;
    const totalPages = Math.ceil(total / limit);
    const statuses = statusResult.recordset.map((el) => el.call_status);

    const result = {
      data: rows,
      pagination: {
        total,
        totalPages,
        currentPage: page,
        limit,
        hasNextPage: page < totalPages,
        hasPreviousPage: page > 1,
        statuses,
      },
      filters: {
        search: searchTerm,
        status: statusFilter || "all",
      },
    };
    res.status(200).json(new ApiResponse(200, result));
  }
);

export const downloadMotorRecords = asyncHandler(
  async (req: Request, res: Response) => {
    const { from, to } = req.query;

    if (!from || !to) {
      throw new ApiError(
        500,
        "Both fromDate and toDate parameters are required"
      );
    }

    const fromDate = formatDate(from as string, true);
    const toDate = formatDate(to as string, false);

    fromDate.setHours(0, 0, 0, 0);
    toDate.setHours(23, 59, 59, 999);

    // Get filtered data by time range
    if (!dbPool) {
      throw new ApiError(500, "Missing DB Connection.");
    }

    const result = await dbPool
      .request()
      .input("fromDate", sql.DateTimeOffset, fromDate)
      .input("toDate", sql.DateTimeOffset, toDate).query(`
        SELECT 
          r.*, 
          rec.sas_url as sas_url,
          rec.uploaded_at as uploaded_at,
          rec.call_end_time as agent_call_end_time
        FROM ${tables.motor} r
        LEFT JOIN ${tables.recording} rec ON r.call_sid = rec.call_sid_id
        WHERE call_start_time BETWEEN @fromDate AND @toDate
      `);

    console.log(result);

    const rows = result.recordset.map((row) => {
      const start = row.call_start_time ? new Date(row.call_start_time) : null;
      const end = row.call_end_time ? new Date(row.call_end_time) : null;

      let call_duration_formatted = null;

      if (start && end) {
        const totalMs = end.getTime() - start.getTime();
        const totalSeconds = Math.floor(totalMs / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;

        // Format as hh:mm:ss
        call_duration_formatted = `${String(hours).padStart(2, "0")}:${String(
          minutes
        ).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
      }

      let agent_call_start_time = null;

      if (row.agent_call_end_time) {
        agent_call_start_time = row.call_end_time;
      }

      return {
        ...row,
        call_duration_minutes: call_duration_formatted,
        agent_call_start_time: agent_call_start_time,
      };
    });

    // Add formatted data
    const formattedRows = rows.map((row, idx) => ({
      ...row,
      call_start_time: row.call_start_time
        ? new Date(row.call_start_time)
        : null,
      call_end_time: row.call_end_time ? new Date(row.call_end_time) : null,
      created_at: row.created_at ? new Date(row.created_at) : null,
    }));

    const columns = getMotorExcelColumns();
    await exportToExcel(
      res,
      formattedRows,
      columns,
      `Records_${from}_to_${to}.xlsx`
    );
  }
);

export const getSelectedDownload = asyncHandler(
  async (req: Request, res: Response) => {
    const { sessionIds } = req.body;

    if (!sessionIds || !Array.isArray(sessionIds) || sessionIds.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Session Ids array is required in the request body",
      });
    }

    if (!dbPool) {
      throw new ApiError(500, "Missing DB Connection.");
    }

    const result = await dbPool.request().query(`
      DECLARE @SessionIds TABLE (session_id NVARCHAR(255))
      
      INSERT INTO @SesisonIds (session_id)
      VALUES ${sessionIds.map((id) => `(${id.replace(/'/g, "''")})`).join(", ")}
      SELECT
      r.*,
      rec.sas_url as sas_url,
      rec.uploaded_at as uploaded_at,
      rec.call_end_time as agent_call_end_time
      FROM ${tables.motor} r
      LEFT JOIN ${tables.recording} rec ON r.call_sid = rec.call_sid_id
      WHERE r.session_id IN (SELECT session_id FROM @SessionIds)`);

    const rows = result.recordset.map((row) => {
      const start = row.call_start_time ? new Date(row.call_start_time) : null;
      const end = row.call_end_time ? new Date(row.call_end_time) : null;

      let call_duration_formatted = null;

      if (start && end) {
        const totalMs = end.getTime() - start.getTime();
        const totalSeconds = Math.floor(totalMs / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;

        // Format as hh:mm:ss
        call_duration_formatted = `${String(hours).padStart(2, "0")}:${String(
          minutes
        ).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
      }

      let agent_call_start_time = null;

      if (row.agent_call_end_time) {
        agent_call_start_time = row.call_end_time;
      }

      return {
        ...row,
        call_duration_minutes: call_duration_formatted,
        agent_call_start_time: agent_call_start_time,
      };
    });

    const formattedRows = rows.map((row, idx) => ({
      ...row,
      call_start_time: row.call_start_time
        ? new Date(row.call_start_time)
        : null,
      call_end_time: row.call_end_time ? new Date(row.call_end_time) : null,
      created_at: row.created_at ? new Date(row.created_at) : null,
    }));

    const columns = getMotorExcelColumns();
    await exportToExcel(res, formattedRows, columns, `Records.xlsx`);
  }
);
