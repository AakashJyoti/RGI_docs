import { Request, Response } from "express";
import { dbPool } from "../db/index";
import { tables } from "../constant";
import { asyncHandler } from "../utills/asyncHandler";
import { ApiResponse } from "../utills/ApiResponse";
import { ApiError } from "../utills/ApiError";

export const getTranscript = asyncHandler(
  async (req: Request, res: Response) => {
    const sid = req.query.sid;

    if (!dbPool) {
      throw new ApiError(500, "Missing DB Connection.");
    }
    const request = await dbPool
      .request()
      .input("sid", sid)
      .query(`SELECT * FROM ${tables.motor} WHERE call_sid = @sid`);

    const rec = request.recordset[0];

    const result = {
      contact_no: rec.contactno_mobile,
      policy_no: rec.policy_number,
      calling_no: rec.call_received_from,
      is_registered:
        rec.contactno_mobile === rec.call_received_from ? true : false,
      transcript: rec.transcript,
    };
    res.status(200).json(new ApiResponse(200, result));
  }
);
