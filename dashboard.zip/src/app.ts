import express, { Request, Response, NextFunction } from "express";
import cookieParser from "cookie-parser";
import cors from "cors";
import morgan from "morgan";
import bodyParser from "body-parser";
import path from "path";
import allowControlAccess from "./middleware/allowControlAccess";
import motorRouter from "./routes/motor.routes";
import transcriptRouter from "./routes/transcript.routes";
import healthRouter from "./routes/health.routes";
import { ApiError } from "./utills/ApiError";

const app = express();

app.use(cors());
app.use(express.json({ limit: "16kb" }));
app.use(express.urlencoded({ extended: true, limit: "16kb" }));
app.use(express.static("public"));
app.use(cookieParser());
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: false,
  })
);
app.use(allowControlAccess);
app.use(morgan("dev"));

app.on("error", (error) => {
  console.error("App ERROR: ", error);
  throw error;
});

// Routes declaration
app.use("/dashboard", express.static(path.join(__dirname, "../client/dist")));
app.use("/dashboard/api/v1/health", healthRouter);
app.use("/dashboard/api/v1/motor", motorRouter);
app.use("/dashboard/api/v1/transcript", transcriptRouter);

app.get("/dashboard/api/v1/*", (req: Request, res: Response) => {
  res.status(404).json({
    message: "Path does not exist",
  });
});

app.get("/dashboard/*", (req: Request, res: Response) => {
  res.sendFile(path.join(__dirname, "../client/dist", "index.html"));
});

app.get("*", (req: Request, res: Response) => {
  res.status(404).json({
    message: "Path does not exists",
  });
});

// Centralized error handler
app.use((err: ApiError, req: Request, res: Response) => {
  res.status(err.statusCode || 500).json({
    statusCode: err.statusCode || 500,
    data: err.data || null,
    message: err.message || "Internal Server Error",
    success: err.success || false,
    errors: err.errors || [],
  });
});

export { app };
