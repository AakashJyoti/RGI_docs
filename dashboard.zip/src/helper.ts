// Helper function to format dates
export const formatDate = (date: string | Date, startOfDay: boolean): Date => {
  const formattedDate = new Date(date);
  if (startOfDay) {
    formattedDate.setHours(0, 0, 0, 0);
  } else {
    formattedDate.setHours(23, 59, 59, 999);
  }
  return formattedDate;
};
