import ExcelJS from "exceljs";
import { Response } from "express";

interface ExcelColumn {
  header: string;
  key: string;
  width?: number;
  style?: any;
}

export async function exportToExcel(
  res: Response,
  rows: any[],
  columns: ExcelColumn[],
  filename: string = "Records.xlsx"
) {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet("Records Data");
  worksheet.columns = columns;

  let id = 1;
  rows.forEach((row) => {
    worksheet.addRow({ ...row, id: id++ });
  });

  worksheet.getRow(1).eachCell((cell) => {
    cell.font = { bold: true };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFD3D3D3" },
    };
  });

  res.setHeader(
    "Content-Type",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  );
  res.setHeader("Content-Disposition", `attachment; filename=${filename}`);

  await workbook.xlsx.write(res);
  res.end();
}

export function getMotorExcelColumns() {
  return [
    { header: "ID", key: "id", width: 10 },
    { header: "Caller Number", key: "call_received_from", width: 20 },
    { header: "Con Id", key: "call_sid", width: 20 },
    {
      header: "Date",
      key: "call_start_time",
      width: 15,
      style: { numFmt: "dd-mm-yyyy" },
    },
    { header: "Language", key: "selected_language", width: 15 },
    {
      header: "Call Start",
      key: "call_start_time",
      width: 15,
      style: { numFmt: "hh:mm:ss AM/PM" },
    },
    {
      header: "Call End",
      key: "call_end_time",
      width: 15,
      style: { numFmt: "hh:mm:ss AM/PM" },
    },
    {
      header: "Duration (min)",
      key: "call_duration_minutes",
      width: 15,
      style: { numFmt: "0.00" },
    },
    { header: "Call status", key: "call_status", width: 15 },
    { header: "Session Id", key: "session_id", width: 20 },
    { header: "Policy Number", key: "policy_number", width: 15 },
    { header: "Claim Number", key: "claim_no", width: 15 },
    {
      header: "Agent Start time",
      key: "agent_call_start_time",
      width: 15,
      style: { numFmt: "hh:mm:ss AM/PM" },
    },
    {
      header: "Agent end time",
      key: "agent_call_end_time",
      width: 15,
      style: { numFmt: "hh:mm:ss AM/PM" },
    },
    { header: "Recording url", key: "sas_url", width: 15 },
  ];
}
