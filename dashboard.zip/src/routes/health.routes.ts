import { Router } from "express";
import {
  downloadHealthRecords,
  getAllHealthRecords,
  getHealthRecords,
  getSelectedDownload,
} from "../controller/health.controller";

const router = Router();

router.route("/getAll").get(getAllHealthRecords);
router.route("/").get(getHealthRecords);
router.route("/downloadRecords").get(downloadHealthRecords);
router.route("/selectedDownload").post(getSelectedDownload);

export default router;
