import { Router } from "express";
import {
  getAllMotorRecords,
  getMotorRecords,
  downloadMotorRecords,
  getSelectedDownload,
} from "../controller/motor.controller";

const router = Router();

router.route("/getAll").get(getAllMotorRecords);
router.route("/").get(getMotorRecords);
router.route("/downloadRecords").get(downloadMotorRecords);
router.route("/selectedDownload").post(getSelectedDownload);

export default router;
