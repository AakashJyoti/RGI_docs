import { Router } from "express";
import { getTranscript } from "../controller/transcript.controller";

const router = Router();

router.route("/getTranscript").get(getTranscript);

export default router;
