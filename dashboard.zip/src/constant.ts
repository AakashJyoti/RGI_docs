export const tables = {
  motor: "websocket_final_motorclaimdetails",
  health: "",
  recording: "websocket_final_audioupload",
};
