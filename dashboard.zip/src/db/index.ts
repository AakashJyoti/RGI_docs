import sql, { ConnectionPool, config as SqlConfig } from "mssql";
import dotenv from "dotenv";
import { ApiError } from "../utills/ApiError";
dotenv.config();

// Validate environment variables
if (
  !process.env.SQL_SERVER_USER ||
  !process.env.SQL_SERVER_PASSWORD ||
  !process.env.SQL_SERVER_HOST ||
  !process.env.SQL_SERVER_DB ||
  !process.env.SQL_SERVER_PORT
) {
  throw new ApiError(
    500,
    "Missing required environment variables for SQL Server configuration."
  );
}

const config: SqlConfig = {
  user: process.env.SQL_SERVER_USER as string,
  password: process.env.SQL_SERVER_PASSWORD as string,
  server: process.env.SQL_SERVER_HOST as string,
  database: process.env.SQL_SERVER_DB as string,
  port: parseInt(process.env.SQL_SERVER_PORT as string),
  options: {
    encrypt: false,
    trustServerCertificate: true,
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
};

let dbPool: ConnectionPool | null = null;

async function connectDB(): Promise<typeof sql> {
  try {
    dbPool = await sql.connect(config);
    console.log("Connected to SQL Server");
    return sql;
  } catch (err) {
    console.error("Database connection failed:", err);
    throw err;
  }
}

export { connectDB, dbPool };
