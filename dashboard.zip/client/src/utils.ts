const key = "auth_rgi";

export const saveAuthToLocalStorage = (value: TAuthCred) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error("Error saving to localStorage:", error);
  }
};

export const removeAuthFromLocalStorage = () => {
  try {
    localStorage.removeItem(key);
  } catch (error) {
    console.error("Error removing from localStorage:", error);
  }
};

export const getAuthFromLocalStorage = () => {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : null;
  } catch (error) {
    console.error("Error reading from localStorage:", error);
    return null;
  }
};

export const calculateDuration = ({
  startTime,
  endTime,
}: {
  startTime: string;
  endTime: string;
}) => {
  if (!startTime || !endTime) {
    return "0 min";
  }
  const startDate = new Date(startTime);
  const endDate = new Date(endTime);

  const durationMs = endDate.getTime() - startDate.getTime();
  const diffInMinutes =
    durationMs > 0 ? Math.round(durationMs / (1000 * 60)) : 0;
  return `${diffInMinutes} min`;
};

export const formatDate = (isoDate: string): string => {
  const utcDate = new Date(isoDate);
  const istTimeString = utcDate.toLocaleString("en-US", {
    timeZone: "Asia/Kolkata",
  });
  const istDate = new Date(istTimeString);
  const day = String(istDate.getDate()).padStart(2, "0");
  const month = String(istDate.getMonth() + 1).padStart(2, "0");
  const year = istDate.getFullYear();
  return `${day}-${month}-${year}`;
};

export const formatTime = (isoDate: string): string => {
  const utcDate = new Date(isoDate);
  const istTimeString = utcDate.toLocaleString("en-US", {
    timeZone: "Asia/Kolkata",
  });
  const istDate = new Date(istTimeString);
  const hours = String(istDate.getHours()).padStart(2, "0");
  const minutes = String(istDate.getMinutes()).padStart(2, "0");
  const seconds = String(istDate.getSeconds()).padStart(2, "0");
  return `${hours}:${minutes}:${seconds}`;
};
