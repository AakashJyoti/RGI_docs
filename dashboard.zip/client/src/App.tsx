import { createBrowserRouter, RouterProvider, Navigate } from "react-router";
import Layout from "./Layout";
import { useAuth } from "./store/useAuth";
import Dashboard from "./pages/Dashboard";
import NotFoundPage from "./pages/NotFoundPage";
import Login from "./pages/Login";
import { ReactNode, useEffect, useState } from "react";
import DashboardDetails from "./pages/DashboardDetails";
import { getAuthFromLocalStorage } from "./utils";
import TranscriptPage from "./pages/TranscriptPage";

function App() {
  const { isAuth, setAuth } = useAuth();
  const [isLogged, setIsLogged] = useState(false);

  useEffect(() => {
    if (isAuth) {
      setIsLogged(true);
    } else {
      const cred = getAuthFromLocalStorage();
      if (cred) {
        setAuth(cred);
      } else {
        setIsLogged(false);
      }
    }
  }, [setAuth, isAuth]);

  const ProtectedRoute = ({ children }: { children: ReactNode }) => {
    if (!isLogged) {
      return <Navigate to="/login" replace />;
    }

    return children;
  };

  const routes = createBrowserRouter(
    [
      { path: "login", element: <Login /> },
      {
        path: "/",
        element: <Layout />,
        children: [
          {
            path: "",
            element: (
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            ),
          },
          {
            path: "details",
            element: (
              <ProtectedRoute>
                <DashboardDetails />
              </ProtectedRoute>
            ),
          },
        ],
      },
      {
        path: "transcript/:sid",
        element: <TranscriptPage />,
      },
      { path: "*", element: <NotFoundPage /> },
    ],
    {
      basename: "/dashboard",
    }
  );

  return <RouterProvider router={routes} />;
}

export default App;
