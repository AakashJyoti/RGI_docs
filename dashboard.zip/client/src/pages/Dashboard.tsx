import { useEffect, useState } from "react";
import { LoadingIcon, SearchIcon, TranscriptIcon } from "../assets/svg";
import axios from "axios";
import { API_ENGPOINTS } from "../constant";
import { calculateDuration, formatDate, formatTime } from "../utils";
import TranscriptModal from "../components/TranscriptModal";
import ReportDownload from "../components/ReportDownload";

type TDetails = {
  callerNo: string;
  conId: string;
  date: string;
  CIVRcallStartTime: string;
  CIVRcallEndTime: string;
  CIVRcallDuration: string;
  CallTransferStartTime: string;
  CallTransferEndTime: string;
  CallTransferDuration: string;
  callStatus: string;
  language: string;
  sessionId: string;
  recording_url: string;
  transcript: string;
  claimNo: string;
};

type Tp = TDetails & {
  sno: number;
};

const Dashboard = () => {
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [selecedCall, setSelecedCall] = useState<Tp>();
  const [dashboardDetials, setDashboardDetials] = useState<Tp[]>([]);
  const [pageDetails, setPageDetails] = useState<Pagination>({
    currentPage: 0,
    limit: 20,
    total: 0,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
    statuses: [],
  });
  const [debounceTerm, setDebounceTerm] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortFor, setSortFor] = useState("");
  const [availableStatus, setAvailableStatus] = useState<string[]>();
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const handleCheckboxChange = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((itemId) => itemId !== id) : [...prev, id]
    );
  };

  const handleClearSelected = () => {
    setSelectedIds([]);
  };

  useEffect(() => {
    const handler = setTimeout(() => {
      setPageDetails((prev) => ({ ...prev, currentPage: 1 }));
      setSearchTerm(debounceTerm);
    }, 200);

    // Cleanup if user types again before 200ms
    return () => {
      clearTimeout(handler);
    };
  }, [debounceTerm]);

  useEffect(() => {
    const getData = async () => {
      if (!dashboardDetials.length) {
        setLoading(true);
      }
      try {
        const { data } = await axios.get<PageinationApiResponse>(
          `${API_ENGPOINTS.motor.pages}?page=${pageDetails.currentPage}&limit=${pageDetails.limit}&status=${sortFor}&search=${searchTerm}`
        );

        const formattedData: Tp[] = data.data.data.map((item, index) => ({
          sno: (pageDetails.currentPage - 1) * pageDetails.limit + index + 1,
          callerNo: item.call_received_from,
          conId: item.call_sid,
          date: item.call_start_time ? formatDate(item.call_start_time) : "",
          CIVRcallStartTime: item.call_start_time
            ? formatTime(item.call_start_time)
            : "",
          CIVRcallEndTime:
            item.call_status === "Transfered to Agent"
              ? item.agent_call_end_time
                ? formatTime(item.agent_call_end_time)
                : ""
              : item.call_end_time
              ? formatTime(item.call_end_time)
              : "",
          CIVRcallDuration: calculateDuration({
            startTime: item.call_start_time,
            endTime:
              item.call_status === "Transfered to Agent"
                ? item.agent_call_end_time
                : item.call_end_time,
          }),
          CallTransferStartTime:
            item.call_status === "Transfered to Agent"
              ? item.call_end_time
                ? formatTime(item.call_end_time)
                : ""
              : "",
          CallTransferEndTime:
            item.call_status === "Transfered to Agent"
              ? item.agent_call_end_time
                ? formatTime(item.agent_call_end_time)
                : ""
              : "",
          CallTransferDuration:
            item.call_status === "Transfered to Agent"
              ? calculateDuration({
                  startTime: item.call_end_time,
                  endTime: item.agent_call_end_time,
                })
              : "0 min",
          callStatus: item.call_status ? item.call_status : "Disconnected",
          language: item.selected_language,
          sessionId: `${item.session_id}`,
          recording_url: item.sas_url,
          transcript: item.transcript,
          claimNo: item.claim_no ? item.claim_no : "",
        }));
        setPageDetails(data.data.pagination);
        setDashboardDetials(formattedData);
        setAvailableStatus(data.data.pagination.statuses);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };

    getData();

    const intervalid = setInterval(getData, 12000);
    return () => clearInterval(intervalid);
  }, [
    pageDetails.currentPage,
    pageDetails.limit,
    searchTerm,
    sortFor,
    dashboardDetials.length,
  ]);

  const toggleTransModal = () => {
    setShowModal((prev) => !prev);
  };

  const handleTranscript = (val: Tp) => {
    setSelecedCall(val);
    toggleTransModal();
  };

  return (
    <>
      <div className="mx-auto p-9 h-screen overflow-hidden flex flex-col">
        <div className="grid grid-cols-3 gap-4 justify-between mb-4">
          <div className="flex gap-4 items-center">
            <p className="text-balance font-semibold mb-1">Filters:</p>
            <div className="pl-2 pr-1 py-1 flex gap-2 items-center border border-gray-400 rounded min-w-64 text-sm">
              <p>Status</p>
              <select
                name=""
                id=""
                className="flex-1 border border-gray-300 rounded px-4 py-1"
                value={sortFor}
                onChange={(e) => {
                  setPageDetails((prev) => ({ ...prev, currentPage: 1 }));
                  setSortFor(e.target.value);
                }}
              >
                <option value="">Select</option>
                {availableStatus?.map((val) => (
                  <option value={val} key={val}>
                    {val}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="border border-gray-300 flex items-center px-4 gap-2 rounded-full">
            <SearchIcon />
            <input
              type="text"
              placeholder="Search"
              className="grow text-sm"
              value={debounceTerm}
              onChange={(e) => setDebounceTerm(e.target.value)}
            />
          </div>

          <div className="flex justify-end gap-4 text-sm">
            {selectedIds.length ? (
              <button
                className="bg-red-500 text-white h-10 w-32 rounded flex justify-center items-center gap-2"
                onClick={handleClearSelected}
              >
                Clear
              </button>
            ) : null}
            <ReportDownload
              selectedIds={selectedIds}
              handleClearSelected={handleClearSelected}
            />
          </div>
        </div>

        <div className="flex-1 h-full flex flex-col border border-gray-300 overflow-hidden">
          <div className="overflow-auto relative">
            <table className="min-w-[1200px] bg-white text-xs">
              <thead>
                <tr className="border-b border-white text-white bg-blue-500 sticky top-0 z-10">
                  <th className="py-2 px-4 border-r w-[50px]" colSpan={1}></th>
                  <th className="py-2 px-4 border-r w-[50px]" colSpan={1}>
                    S.No.
                  </th>
                  <th className="py-2 px-2 border-r w-[100px]" colSpan={1}>
                    Caller No.
                  </th>
                  <th className="py-2 px-2 border-r" colSpan={1}>
                    Con Id
                  </th>
                  <th className="py-2 px-2 border-r" colSpan={1}>
                    Claim No.
                  </th>
                  <th className="py-2 px-2 border-r" colSpan={1}>
                    Date
                    <br />
                    <span className="text-xs">(DD-MM-YYYY)</span>
                  </th>
                  <th className="border-r" colSpan={3}>
                    <div className="flex flex-col">
                      <p className="py-2 px-2 text-center">CIVR Call Time</p>
                      <div className="grid grid-cols-3 border-white border-t py-2">
                        <p className="border-r px-1">Start Time</p>
                        <p className="border-r px-1">End Time</p>
                        <p className="px-1">Duration</p>
                      </div>
                    </div>
                  </th>
                  <th className="border-r" colSpan={3}>
                    <div className="flex flex-col">
                      <p className="py-2 px-2 text-center">Call Transfer</p>
                      <div className="grid grid-cols-3 border-white border-t py-2">
                        <p className="border-r px-1">Start Time</p>
                        <p className="border-r px-1">End Time</p>
                        <p className="px-1">Duration</p>
                      </div>
                    </div>
                  </th>
                  <th className="py-2 px-2 border-r" colSpan={1}>
                    Language
                  </th>
                  <th className="py-2 px-4 border-r">Call Status</th>
                  <th className="py-2 px-4">Call Transcription</th>
                </tr>
              </thead>

              <tbody className="h-full overflow-auto relative">
                {loading ? (
                  <tr>
                    <td colSpan={13} className="h-64">
                      <div className="absolute inset-0 flex justify-center items-center h-full w-full">
                        <LoadingIcon />
                      </div>
                    </td>
                  </tr>
                ) : (
                  dashboardDetials.map((ele) => (
                    <tr className="border-b-gray-300 border-b" key={ele.sno}>
                      <td
                        className="py-2 px-4 text-center w-[50px]"
                        colSpan={1}
                      >
                        <input
                          type="checkbox"
                          name=""
                          id=""
                          checked={selectedIds.includes(ele.sessionId)}
                          onChange={() => handleCheckboxChange(ele.sessionId)}
                        />
                      </td>
                      <td
                        className="py-2 px-4 text-center w-[50px]"
                        colSpan={1}
                      >
                        {ele.sno}
                      </td>
                      <td
                        className="py-2 px-4 text-center w-[100px]"
                        colSpan={1}
                      >
                        {ele.callerNo}
                      </td>
                      <td className="py-2 px-4 text-center" colSpan={1}>
                        {ele.conId}
                      </td>
                      <td className="py-2 px-4 text-center" colSpan={1}>
                        {ele.claimNo}
                      </td>
                      <td className="py-2 px-4 text-center" colSpan={1}>
                        {ele.date}
                      </td>
                      <td className="py-2 px-4 text-center" colSpan={3}>
                        <div className="grid grid-cols-3 border-white border-t py-2 content-center">
                          <p className="border-r px-1">
                            {ele.CIVRcallStartTime}
                          </p>
                          <p className="border-r px-1">{ele.CIVRcallEndTime}</p>
                          <p className="px-1">{ele.CIVRcallDuration}</p>
                        </div>
                      </td>
                      <td className="py-2 px-4 text-center" colSpan={3}>
                        <div className="grid grid-cols-3 border-white border-t py-2 content-center">
                          <p className="border-r px-1">
                            {ele.CallTransferStartTime}
                          </p>
                          <p className="border-r px-1">
                            {ele.CallTransferEndTime}
                          </p>
                          <p className="px-1">{ele.CallTransferDuration}</p>
                        </div>
                      </td>
                      <td className="py-2 px-4 text-center" colSpan={1}>
                        {ele.language}
                      </td>
                      <td className="py-2 px-4 text-center" colSpan={1}>
                        {ele.callStatus}
                      </td>
                      <td className="py-2 px-4 text-center" colSpan={1}>
                        <div className="flex justify-center items-center">
                          <button
                            type="button"
                            onClick={() => handleTranscript(ele)}
                          >
                            <TranscriptIcon />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex justify-between mt-4 items-center text-sm">
          <div className="flex gap-4 items-center">
            <label htmlFor="limit">Page size:</label>
            <select
              name="limit"
              id="limit"
              className="border border-gray-300 rounded px-4 py-1"
              value={pageDetails.limit}
              onChange={(e) =>
                setPageDetails((prev) => ({
                  ...prev,
                  currentPage: 1,
                  limit: Number(e.target.value),
                }))
              }
            >
              <option value="20">20</option>
              <option value="30">30</option>
              <option value="40">40</option>
              <option value="50">50</option>
            </select>
          </div>

          <span>
            Page {pageDetails.currentPage} of{" "}
            {Math.ceil(pageDetails.total / pageDetails.limit)}
          </span>

          <div className="flex gap-2">
            <button
              className="px-4 py-2 w-24 bg-blue-500 text-white rounded disabled:bg-gray-300"
              disabled={!pageDetails.hasPreviousPage}
              onClick={() => {
                setPageDetails((prev) => ({
                  ...prev,
                  currentPage: prev.currentPage - 1,
                }));
              }}
            >
              Previous
            </button>
            <button
              className="px-4 py-2 w-24 bg-blue-500 text-white rounded disabled:bg-gray-300"
              disabled={!pageDetails.hasNextPage}
              onClick={() => {
                setPageDetails((prev) => ({
                  ...prev,
                  currentPage: prev.currentPage + 1,
                }));
              }}
            >
              Next
            </button>
          </div>
        </div>
      </div>
      {showModal && selecedCall?.transcript && (
        <TranscriptModal
          trans={selecedCall?.transcript}
          convid={selecedCall?.conId}
          callerNo={selecedCall?.callerNo}
          toggleTransModal={toggleTransModal}
          recordingUrl={selecedCall.recording_url}
        />
      )}
    </>
  );
};
export default Dashboard;
