import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router";
import { API_ENGPOINTS } from "../constant";
import { CopyIcon, CopyTrueIcon } from "../assets/svg";

const elements = [
  { id: "calling_no", name: "Calling no" },
  { id: "contact_no", name: "Calling no" },
  { id: "policy_no", name: "Policy no" },
];

const TranscriptPage = () => {
  const { sid } = useParams();

  const [transData, setTransData] = useState<TransData>();
  const [copied, setCopied] = useState<null | string>();

  const handleCopy = async (text: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(text);
    setTimeout(() => {
      setCopied(null);
    }, 2000);
  };

  useEffect(() => {
    const getTranscript = async () => {
      const { data } = await axios.get<GetTranscriptApiResponse>(
        `${API_ENGPOINTS.transcript.getTranscript}?sid=${sid}`
      );
      setTransData(data.data);
    };

    if (sid) {
      getTranscript();
    }
  }, [sid]);

  return (
    <div className="flex h-screen overflow-hidden">
      <div className="w-72 h-full p-4 border-r bg-blue-500 text-white overflow-hidden">
        <p className="font-semibold text-lg ml-2">Details:</p>
        <div className="bg-white h-0.5 mb-3" />
        <div className="text-sm pl-1">
          {transData !== undefined &&
            elements.map((el) => {
              const zik = transData[el.id as keyof TransData] as string;
              return (
                <p
                  className="border-b p-1 flex justify-between items-center"
                  key={el.id}
                >
                  <span>
                    {el.name} : {zik}
                  </span>

                  {transData && zik ? (
                    <button onClick={() => handleCopy(zik)}>
                      {copied === zik ? <CopyTrueIcon /> : <CopyIcon />}
                    </button>
                  ) : null}
                </p>
              );
            })}
          <p>
            Registered:{" "}
            <span>{transData?.is_registered ? "True" : "False"}</span>
          </p>
        </div>
      </div>
      <div className="py-4 px-6 flex-1 overflow-hidden h-screen flex flex-col">
        <p className="font-semibold text-lg">Transcript:</p>
        <div className="flex flex-col border rounded-sm w-full max-h-full overflow-auto py-1">
          {transData && transData.transcript ? (
            transData.transcript.split("\n").map((ele, index) => {
              return (
                <p key={index} className="py-0.5 px-4">
                  {ele}
                </p>
              );
            })
          ) : (
            <p>No data available!..</p>
          )}
        </div>
      </div>
    </div>
  );
};
export default TranscriptPage;
