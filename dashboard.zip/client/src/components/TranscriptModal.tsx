import { useEffect, useState } from "react";
import { CloseIcon, DownloadIcon } from "../assets/svg";

type Props = {
  trans: string;
  convid: string;
  callerNo: string;
  toggleTransModal: () => void;
  recordingUrl: string;
};

const TranscriptModal = ({
  trans,
  convid,
  callerNo,
  recordingUrl,
  toggleTransModal,
}: Props) => {
  const [chats, setChats] = useState<string[]>();

  const handleDownload = () => {
    const blob = new Blob([trans], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `transcript_${convid}_${callerNo}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  useEffect(() => {
    if (trans) {
      setChats(trans.split("\n"));
    }
  }, [trans]);

  return (
    <div className="absolute top-0 right-0 z-10 bg-black/50 w-screen h-screen flex justify-center items-center">
      <div className="bg-white h-[600px] w-[800px] rounded-xl p-4">
        <div className="flex mb-4 pl-4 justify-between">
          <p className="text-2xl border-b-2 border-gray-400">Transcriptions:</p>
          <div>
            <button onClick={toggleTransModal}>
              <CloseIcon />
            </button>
          </div>
        </div>
        {recordingUrl && (
          <div>
            <audio controls>
              <source src={recordingUrl} type="audio/wav" />
            </audio>
          </div>
        )}

        <div className="max-h-[500px] overflow-auto flex flex-col gap-1 border border-gray-200 rounded px-4 py-2">
          {chats?.map((msg, index) => (
            <p key={index}>{msg}</p>
          ))}
        </div>
        <div className="flex w-full items-center justify-center mt-2">
          <button
            className="bg-blue-500 text-white h-10 w-32 rounded flex justify-center items-center gap-2"
            onClick={handleDownload}
          >
            Download
            <DownloadIcon />
          </button>
        </div>
      </div>
    </div>
  );
};
export default TranscriptModal;
