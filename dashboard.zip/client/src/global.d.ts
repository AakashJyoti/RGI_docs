type TAuthCred = { name: string; password: string };

interface ClaimData {
  session_id: string;
  call_sid: string;
  selected_language: string;
  policy_number: string;
  mobile_number: string;
  policy_start_date: string;
  policy_end_date: string;
  contactno_mobile: string;
  email_id: string;
  first_name: string;
  last_name: string;
  address: string;
  pin_no: string;
  product_code: string;
  is_insured: boolean;
  insured_name: string;
  relationship: string;
  caller_name: string;
  caller_mobile: string;
  claim_type: string;
  accidient_date: string;
  hour_of_loss: string;
  min_of_loss: string;
  accident_location: string;
  claim_no: string;
  garage_id: string;
  garage_name: string;
  garage_address: string;
  garage_pincode: string;
  transfer_reason: string;
  transcript: string;
  call_start_time: string;
  call_end_time: string;
  recording_url: string;
  call_status: string;
  call_received_from: string;
  sas_url: string;
  upload_at: string;
  agent_call_end_time: string;
}

interface Pagination {
  total: number;
  totalPages: number;
  currentPage: number;
  limit: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
  statuses: string[];
}

interface Filters {
  search: string;
  status: string;
}

interface PageinationApiResponse {
  success: boolean;
  data: { data: ClaimData[]; pagination: Pagination; filters: Filters };
  message: string;
  statusCode: number;
}

interface TransData {
  contact_no: string;
  policy_no: string;
  calling_no: string;
  is_registered: boolean;
  transcript: string;
}

interface GetTranscriptApiResponse {
  success: boolean;
  data: TransData;
}
