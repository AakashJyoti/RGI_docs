export const API_URL = "/dashboard/api/v1";
// const API_URL = "http://localhost:8081/dashboard/api/v1";

export const API_ENGPOINTS = {
  motor: {
    getAll: `${API_URL}/motor/getAll`,
    pages: `${API_URL}/motor`,
    download: `${API_URL}/motor/downloadRecords`,
    selectDownload: `${API_URL}/motor/selectedDownload`,
  },
  heath: {
    getAll: `${API_URL}/health/getAll`,
    pages: `${API_URL}/health`,
    download: `${API_URL}/health/downloadRecords`,
    selectDownload: `${API_URL}/health/selectedDownload`,
  },
  transcript: {
    getTranscript: `${API_URL}/transcript/getTranscript`,
  },
};
