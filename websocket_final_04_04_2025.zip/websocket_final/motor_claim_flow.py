import os
from dataclasses import dataclass
from typing import Dict, Any


from .utils import text_to_speech_azure_streamlit, speech_to_text_azure_streamlit, speech_to_text_azure_streamlit_chunks
from .mobile_number_validation import validate_mobile_number
from .policy_details_func import get_policy_details
from .handle_user_input_retries import handle_user_input
from .ask_user_for_mobile_policy_number import ask_mobile_or_policy_number
from .caller_insured_confirmation import insured_confirmation
from .claim_type_information import get_claim_type
from .garage_validation import get_garage_details
from .claim_intimation_api import intimate_motor_claim
from .final_conclusion_call import conclusion_step

@dataclass
class ClaimSession:
    """Central data storage for claim process"""
    selected_language: str = None
    auth_attempts: int = 0
    date_attempts: int = 0
    policy_number: str = 0
    mobile_number: str = None
    policy_details: Dict[str, Any] = None
    caller_details: Dict[str, Any] = None
    claim_details: Dict[str, Any] = None
    garage_details: Dict[str, Any] = None
    transfer_reason: str = None



async def claim_intimation_flow(mobile_number, websocket_class):
    session = ClaimSession()

    print(mobile_number)
    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    output_file = os.path.join(parent_directory, "audio", "Bot", "bot_response.wav")
    sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()

    # Language Selection
    welcome_message = "Namaste! Welcome to our claim helpline. Would you prefer to continue in Hindi or English?"
    print(welcome_message)
    text_to_speech_azure_streamlit(welcome_message)
    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)


    # Wait for the stop event
    user_input = await handle_user_input(websocket_class)
    if user_input is False:
        session.transfer_reason = "Exceed the input limit"
        websocket_class.close()

    elif 'english' in user_input:
        session.selected_language = 'english'
        if validate_mobile_number(mobile_number):
            session.mobile_number = mobile_number
            print(mobile_number)
            if not await get_policy_details(session, websocket_class):
                print(session.__dict__)
                websocket_class.close()
        else:
            if not await ask_mobile_or_policy_number(session, websocket_class):
                print(session.__dict__)
                websocket_class.close()
            if session.mobile_number or session.policy_number:
                if not await get_policy_details(session, websocket_class):
                    print(session.__dict__)
                    websocket_class.close()

        if not await insured_confirmation(session, websocket_class):
            print(session.__dict__)
            websocket_class.close()

        if not await get_claim_type(session, websocket_class):
            print(session.__dict__)
            websocket_class.close()

        if not await get_garage_details(session, websocket_class):
            print(session.__dict__)
            websocket_class.close()
        if not await intimate_motor_claim(session, websocket_class):
            print(session.__dict__)
            websocket_class.close()

        if not await conclusion_step(session, websocket_class):
            print(session.__dict__)
            websocket_class.close()

    print(session.__dict__)
    websocket_class.close()


# async def claim_intimation_flow_demo(mobile_number, websocket_class):
#     base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
#     parent_directory = os.path.dirname(base_path)  # Go up one directory
#     output_file = os.path.join(parent_directory, "audio", "Bot", "bot_response.wav")
#     sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()
#
#     # Language Selection
#     welcome_message = "Namaste! Welcome to our claim helpline. Would you prefer to continue in Hindi or English?"
#     text_to_speech_azure_streamlit(welcome_message)
#
#     print("sample",sample_rate, sampwidth, n_channels)
#     print(f"before stream audio back: {output_file}")
#     await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
#
#
#     # Wait for the stop event
#     await websocket_class.stop_event.wait()  # Wait until the stop event is set
#
#     # # Process the received audio packets
#     # user_audio_file = f"{websocket_class.call_sid}.wav"  # The file saved in handle_stop_event
#     # user_text = speech_to_text_azure_streamlit(user_audio_file)
#     # print(f"User said: {user_text}")
#
#
#     combined_audio = websocket_class.combined_audio_chunks
#     print(f"audio chunks result: {speech_to_text_azure_streamlit_chunks(combined_audio)}")
#
#
#
#
#     welcome_message = "thank you for selecting the language"
#     text_to_speech_azure_streamlit(welcome_message)
#
#     await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
#
#
#     # Wait for the stop event
#     await websocket_class.stop_event.wait()  # Wait until the stop event is set
#
#     # # Process the received audio packets
#     # user_audio_file = f"{websocket_class.call_sid}.wav"  # The file saved in handle_stop_event
#     # user_text = speech_to_text_azure_streamlit(user_audio_file)
#     # print(f"User said: {user_text}")
#
#     combined_audio = websocket_class.combined_audio_chunks
#     print(f"audio chunks result 2 : {speech_to_text_azure_streamlit_chunks(combined_audio)}")
#
#     print("after")
#
