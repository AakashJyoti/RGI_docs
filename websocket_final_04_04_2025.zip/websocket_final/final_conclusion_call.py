from .utils import text_to_speech_azure_streamlit
import time

async def conclusion_step(session, websocket_class):
    sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()

    try:
        # streamlit UI
        message = "Thank you for contacting our claim intimation helpline. If you have any further questions or concerns, feel free to call us back or visit our website. Have a great day!"
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        return True
    except Exception as e:
        session.transfer_reason = f"Conclusion step error: {str(e)}"
        message = "I'm sorry, due to a system issue, I'm connecting you to an agent who can assist you further. Please wait."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        await websocket_class.transfer_to_agent(reason=session.transfer_reason)
        time.sleep(2)
        return False
