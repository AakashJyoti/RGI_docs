import time
from datetime import datetime

from .utils import (text_to_speech_azure_streamlit,
                    speech_to_text_azure_streamlit_chunks,
                    call_openai,
                    extract_and_convert_to_json,
                    convert_to_dd_mm_yyyy)
from .handle_user_input_retries import handle_user_input

async def get_claim_type(session, websocket_class):
    sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()
    try:
        session.claim_details = {}

        message = "Please confirm whether this claim is for an accident or theft."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

        claim_type_response = await handle_user_input(websocket_class)
        if claim_type_response is False:
            session.transfer_reason = "Exceed the input limit"
            # websocket_class.close()
            return False


        prompt = f"""
        You are a claim type classifier. Your task is to strictly identify whether the given details represent an accident or theft.

        IMPORTANT RULES:
        - You MUST return ONLY ONE claim type: either "accident" or "theft".
        - If the details do NOT clearly indicate either accident or theft, respond with None.
        - Return the result in strict JSON format.
        - Do NOT provide multiple claim types or any additional explanations.

        Input Details: {claim_type_response}

        Expected Output Format:
        {{
            "claim_type": "accident" OR "claim_type": "theft"
        }}
        """

        claim_type_detail = extract_and_convert_to_json(call_openai(prompt))

        if 'theft' in claim_type_detail.get('claim_type'):
            session.transfer_reason = "Theft claim requires specialist handling"
            session.claim_details['claim_type'] = 'theft'

            message = "I understand this is a theft claim. I'll need to transfer you to a specialized agent for further assistance. Please hold."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
            await websocket_class.transfer_to_agent(reason=session.transfer_reason)
            time.sleep(2)
            return False

        elif 'accident' in claim_type_detail.get('claim_type'):
            session.claim_details['claim_type'] = 'accident'
            # text_to_speech1_english("I'm sorry to hear about the accident. Have you reported the vehicle to a garage?")
            # streamlit UI
            message = "I'm sorry to hear about the accident. Have you reported the vehicle to a garage?"
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            user_input = await handle_user_input(websocket_class)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                # websocket_class.close()
                return False

            if 'no' in user_input or 'not' in user_input or "haven't" in user_input:
                session.transfer_reason = "Vehicle not reported to garage"
                message = "Since the vehicle hasn't been reported to a garage yet, I will transfer you to an agent for further guidance on the next steps. Please hold."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                time.sleep(2)
                return False

            message = "Thank you for reporting the vehicle. I will need some details about the accident. Let's go through them one by one."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            message = "Please provide the date of the accident, using the format: date, month, and year."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            accident_date = await handle_user_input(websocket_class)
            if accident_date is False:
                session.transfer_reason = "Exceed the input limit"
                # websocket_class.close()
                return False

            accident_date = convert_to_dd_mm_yyyy(accident_date)
            formatted_accident_date = datetime.strptime(accident_date, "%d/%m/%Y")

            policy_end_date = session.policy_details.get('policy_end_date')
            policy_end_date = datetime.strptime(policy_end_date, "%d-%m-%Y")

            policy_start_date = session.policy_details.get('policy_start_date')
            policy_start_date = datetime.strptime(policy_start_date, "%d-%m-%Y")

            if policy_start_date < formatted_accident_date < policy_end_date:
                session.claim_details['accident_date'] = accident_date
            else:
                # message = "Date of loss should be within policy period. Let's"
                message = "Please ensure the date of loss falls within the policy period. Let’s give it another try. Kindly share the date again."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

                accident_date = await handle_user_input(websocket_class)
                if accident_date is False:
                    session.transfer_reason = "Exceed the input limit"
                    # websocket_class.close()
                    return False

                accident_date = convert_to_dd_mm_yyyy(accident_date)
                formatted_accident_date = datetime.strptime(accident_date, "%d/%m/%Y")

                if policy_start_date < formatted_accident_date < policy_end_date:
                    session.claim_details['accident_date'] = accident_date
                else:
                    session.transfer_reason = "Policy is Expired."
                    message = "Date of loss should be within policy period. I'll transfer you to an agent for further details. Please hold."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                    time.sleep(2)
                    return False

            message = "Please provide the time of the accident."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            accident_time = await handle_user_input(websocket_class)
            if accident_time is False:
                session.transfer_reason = "Exceed the input limit"
                # websocket_class.close()
                return False

            if accident_time:
                prompt = f"""
                   You are a time modifier. Your task is to modify the time as per below given rules.

                   IMPORTANT RULES:
                   - You MUST return ONLY modified time.
                    Ex.:    '02:30 PM' should be converted to "HourOfLoss": "14", "MinOfLoss": "30"
                            '8 in the morning' should be converted to "HourOfLoss": "08", "MinOfLoss": "00"
                   - Return the result in strict JSON format.

                   Input Details: {accident_time}

                   Expected Output Format:
                   {{
                       "HourOfLoss": "Hour",
                       "MinOfLoss": "Minute"
                   }}
                   """

                hour_and_minute = extract_and_convert_to_json(call_openai(prompt))
                session.claim_details['HourOfLoss'] = hour_and_minute['HourOfLoss']
                session.claim_details['MinOfLoss'] = hour_and_minute['MinOfLoss']


            message = "Please provide the location of the accident."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            accident_location = await handle_user_input(websocket_class)
            if accident_location is False:
                session.transfer_reason = "Exceed the input limit"
                # websocket_class.close()
                return False

            session.claim_details['accident_location'] = accident_location

            message = "Please provide the driver Name."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            driver_info = await handle_user_input(websocket_class)
            if driver_info is False:
                session.transfer_reason = "Exceed the input limit"
                # websocket_class.close()
                return False

            session.claim_details['driver_info'] = driver_info


            message = "Please provide some information about the accident."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            accident_info = await handle_user_input(websocket_class)
            if accident_info is False:
                session.transfer_reason = "Exceed the input limit"
                # websocket_class.close()
                return False

            session.claim_details['accident_info'] = accident_info

            return True

    except Exception as e:
        session.transfer_reason = f"Claim type error: {str(e)}"
        message = "I'm sorry, due to a system issue, I'm connecting you to an agent who can assist you further. Please wait."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        await websocket_class.transfer_to_agent(reason=session.transfer_reason)
        time.sleep(2)
        return False

