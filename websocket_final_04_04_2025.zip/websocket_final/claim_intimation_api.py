import requests
import time

from .utils import text_to_speech_azure_streamlit
from .handle_user_input_retries import handle_user_input

async def intimate_motor_claim(session, websocket_class):
    sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()

    try:
        # Prepare API payload
        payload = {
            "PolicyNo": '160221923730000221',
            "IntimaterName": session.caller_details.get('name', session.policy_details.get('insured_name')),
            "MinOfLoss": session.claim_details.get('MinOfLoss', "00"),
            "CreatedBy": "3539",
            "IntimaterMobileNo": session.caller_details.get('mobile', session.mobile_number),
            "InsuredName": session.policy_details.get('insured_name', 'JALPAN R SHAH'),
            "LOSSDATE": session.claim_details.get('accident_date', 'N/A'),
            "DescriptionOfLoss": session.claim_details.get("accident_info", 'N/A'),
            "DriverName": session.claim_details.get('driver_info', 'Unknown'),
            "HourOfLoss": session.claim_details.get('HourOfLoss', "00"),
            "RequestSource": "4708",
            "InsuredMobileNumber": session.policy_details.get('CONTACTNO_MOBILE', '9876543210'),
            "ReasonForDelayInIntimation": "1",
            "InsuredWhatsappNumber": session.policy_details.get('CONTACTNO_MOBILE', '9876543210'),
            "InsuredEmailId": session.policy_details.get('EmailID', "a@b.com"),
            "InsuredWhatsappConsent": "True",
            "EstimatedLoss": "1",
            "GarageID": session.garage_details.get('GarageID', '0000')
        }

        # Confirm details with user
        message = (
            "Please confirm if all details are correct: "
            f"Policy Number: {session.policy_details.get('policyno')},"
            f"Insured Name: {payload['InsuredName']}, "
            f"Accident Date: {payload['LOSSDATE']}, "
            f"Location: {session.claim_details.get('accident_location', 'N/A')}, "
            f"Driver: {payload['DriverName']}, "
            "Is this correct?"
        )
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

        confirmation = await handle_user_input(websocket_class)
        if confirmation is False:
            session.transfer_reason = "Exceed the input limit"
            # websocket_class.close()
            return False

        if 'yes' in confirmation or 'correct' in confirmation:
            message = "I'll now generate your claim intimation ID. Please wait a moment while I process this."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            # API call
            response = requests.post(
                "http://mplusuat.reliancegeneral.co.in:9443/VAPTMobile/claims.svc/GETCLAIMNO_GARAGEAPP", json=payload)

            # Handle API failure
            if not response or response.status_code != 200:
                session.transfer_reason = "Claim API failure"
                message = "I'm sorry, I'm having trouble generating your claim intimation ID due to a system issue. I will transfer you to an agent who can help you further. Please hold."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                time.sleep(2)
                return False

            # Parse the JSON response
            response_data = response.json()

            if response_data.get("Result") and len(response_data["Result"]) > 0:
                first_result = response_data["Result"][0]
                status = first_result.get("Status")

                if status == "Success":
                    # Success case: Store ClaimNo in claim_details
                    session.claim_details['claim_no'] = first_result.get('ClaimNo', 'Unknown')
                elif status == "Failure":
                    # Failure case: Store error in transfer_reason and return False
                    error_response = first_result.get("Errorresponse", "")
                    session.transfer_reason = error_response
                    message = f"There is some technical issues, I'll transfer you to an agent for further details. Please hold."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                    time.sleep(2)
                    return False
                else:
                    # Handle unexpected status
                    session.transfer_reason = f"Unexpected status: {status}"
                    message = "System error occurred. Transferring to agent. Please hold."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                    time.sleep(2)
                    return False
            else:
                # Handle missing or empty Result
                session.transfer_reason = "No result data found in the response."
                message = "No result data found in the response.. Transferring to agent. Please hold."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                time.sleep(2)
                return False

            message = ("Claim successfully registered! Your claim intimation number is " +
                       " ".join(session.claim_details['claim_no']) +
                       ". We'll send SMS confirmation shortly.")
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
            return True

        else:
            session.transfer_reason = "User requested details correction"
            message = "I'll transfer you to an agent to correct the details. Please hold."
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
            await websocket_class.transfer_to_agent(reason=session.transfer_reason)
            time.sleep(2)
            return False

    except Exception as e:
        session.transfer_reason = f"Claim processing error: {str(e)}"
        message = "I'm sorry, due to a system issue, I'm connecting you to an agent who can assist you further. Please wait."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        await websocket_class.transfer_to_agent(reason=session.transfer_reason)
        time.sleep(2)
        return False
