import time
from .utils import text_to_speech_azure_streamlit, speech_to_text_azure_streamlit_chunks
from .handle_user_input_retries import handle_user_input

async def insured_confirmation(session, websocket_class):
    sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()
    try:
        session.caller_details = {}
        # if policy_details:
        message = "Thank you. could you please confirm if you are the insured?"
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

        confirm_insured_or_not = await handle_user_input(websocket_class)
        if confirm_insured_or_not is False:
            session.transfer_reason = "Exceed the input limit"
            # websocket_class.close()
            return False

        if 'yes' in confirm_insured_or_not:
            session.caller_details["is_insured"] = True
            message = f"Thank you for confirming, {session.policy_details['insured_name']}. Let's proceed with your claim."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
            return True
        else:
            session.caller_details["is_insured"] = False
            message = "I understand that you're not the insured. I will need to collect some information from you."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            message = "Could you please confirm your relationship with the insured?"
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            relationship_with_insured = await handle_user_input(websocket_class)
            if relationship_with_insured is False:
                session.transfer_reason = "Exceed the input limit"
                # websocket_class.close()
                return False

            session.caller_details['relationship'] = relationship_with_insured


            message = "Please help us with your full name."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            name_of_caller = await handle_user_input(websocket_class)
            if name_of_caller is False:
                session.transfer_reason = "Exceed the input limit"
                # websocket_class.close()
                return False
            session.caller_details['name'] = name_of_caller


            message = "Please provide your mobile number."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            caller_number = await handle_user_input(websocket_class)
            if name_of_caller is False:
                session.transfer_reason = "Exceed the input limit"
                # websocket_class.close()
                return False
            session.caller_details['mobile'] = caller_number


    except Exception as e:
        session.transfer_reason = f"Insured confirmation error: {str(e)}"
        message = "I'm sorry, due to a system issue, I'm connecting you to an agent who can assist you further. Please wait."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        await websocket_class.transfer_to_agent(reason=session.transfer_reason)
        time.sleep(2)
        return False
