import re
import time

from .utils import text_to_speech_azure_streamlit, remove_special_characters_except_comma
from .handle_user_input_retries import handle_user_input

async def get_garage_details(session, websocket_class):
    sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()
    try:
        session.garage_details = {}

        # Step 1: Ask for pincode
        message = "Please provide the pincode of the garage."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

        garage_pincode = await handle_user_input(websocket_class)
        if garage_pincode is False:
            session.transfer_reason = "Exceed the input limit"
            # websocket_class.close()
            return False

        pincode = re.sub(r"\D", "", garage_pincode)

        message = "Thank you for providing the pincode. I'm now checking our records for that pincode."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

        # # Step 2: Query database
        records = fetch_garage(pincode=pincode)

        # Step 3: Handle no garages found
        if len(records) == 0:
            session.transfer_reason = "No garages found in pincode"
            message = "No garages were found in that pincode. I will now transfer you to an agent for further assistance. Please hold."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
            await websocket_class.transfer_to_agent(reason=session.transfer_reason)
            time.sleep(2)
            return False

        # Step 4: Single garage found
        elif len(records) == 1:
            garage = {
                'GarageID': records[0][0],
                'GarageName': records[0][4],
                'Address': records[0][5],
                'Pincode': records[0][6]
            }

            message = f"We found the garage {garage['GarageName']} located at {remove_special_characters_except_comma(garage['Address'])}. Is this correct?"
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            user_input = await handle_user_input(websocket_class)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                # websocket_class.close()
                return False

            if 'yes' in user_input or 'correct' in user_input:
                message = "The garage has been verified in our system. Let's proceed with the claim."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                session.garage_details = garage
                return True

            else:
                session.transfer_reason = "User rejected single garage match"
                message = "Please hold while I transfer you to an agent for further assistance."
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                time.sleep(2)
                return False

        # Step 5: Multiple garages found
        else:
            # Multiple garages found, ask for garage name
            message = "We found multiple garages in that pincode. Please provide the name of the garage."
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            garage_name_input = await handle_user_input(websocket_class)
            if garage_name_input is False:
                session.transfer_reason = "Exceed the input limit"
                # websocket_class.close()
                return False


            garage_name = re.sub(r"[.-]", "", garage_name_input)

            # Filter records by garage name (case-insensitive partial match)
            matching_garages = []
            for record in records:
                if garage_name in record[4].lower():
                    matching_garages.append({
                        'GarageID': record[0],
                        'GarageName': record[4],
                        'Address': record[5],
                        'Pincode': record[6]
                    })
            # No name matches
            if len(matching_garages) == 0:
                message = "No exact matches found. Let me list all garages in this pincode for confirmation:"
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

                selected_garage = None

                # List all garages in the pincode for confirmation
                for record in records:
                    garage = {
                        'GarageID': record[0],
                        'GarageName': record[4],
                        'Address': record[5],
                        'Pincode': record[6]
                    }
                    message = f"Did you mean {garage['GarageName']} located at {remove_special_characters_except_comma(garage['Address'])}?"
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

                    garage_confirmation = await handle_user_input(websocket_class)
                    if garage_confirmation is False:
                        session.transfer_reason = "Exceed the input limit"
                        # websocket_class.close()
                        return False

                    if 'yes' in garage_confirmation or 'correct' in garage_confirmation:
                        selected_garage = garage
                        break

                if selected_garage:
                    message = f"Confirmed {selected_garage['GarageName']}. The garage has been verified. Let's proceed with the claim."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    session.garage_details = selected_garage
                    return True
                else:
                    session.transfer_reason = "No garage selected from multiple options"
                    message = "None of the garages matched your request. Please hold while I transfer you to an agent for further assistance."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                    time.sleep(2)
                    return False

            # Single name match
            elif len(matching_garages) == 1:
                garage = matching_garages[0]
                message = f"We found {garage['GarageName']} located at {remove_special_characters_except_comma(garage['Address'])}. Is this correct?"
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

                garage_confirmation = await handle_user_input(websocket_class)
                if garage_confirmation is False:
                    session.transfer_reason = "Exceed the input limit"
                    # websocket_class.close()
                    return False

                if 'yes' in garage_confirmation or 'correct' in garage_confirmation:
                    message = "The garage has been verified in our system. Let's proceed with the claim."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    session.garage_details = garage
                    return True
                else:
                    session.transfer_reason = "User rejected single name-matched garage"
                    message = "Please hold while I transfer you to an agent for further assistance."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                    time.sleep(2)
                    return False

            # Multiple name matches
            else:
                message = "There are multiple garages with that name. Let me confirm each one:"
                output_file = text_to_speech_azure_streamlit(message)
                await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                selected_garage = None

                for garage in matching_garages:
                    message = f"Is it {garage['GarageName']} located at {remove_special_characters_except_comma(garage['Address'])}?"
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

                    garage_confirmation = await handle_user_input(websocket_class)
                    if garage_confirmation is False:
                        session.transfer_reason = "Exceed the input limit"
                        # websocket_class.close()
                        return False

                    if 'yes' in garage_confirmation or 'correct' in garage_confirmation:
                        selected_garage = garage
                        break

                if selected_garage:
                    message = f"You have confirmed {selected_garage['GarageName']} located at {remove_special_characters_except_comma(selected_garage['Address'])}. The garage has been verified. Let's proceed with the claim."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    session.garage_details = selected_garage
                    return True
                else:
                    session.transfer_reason = "No garage selected from multiple name matches"
                    message = "None of the garages were selected. I will now transfer you to an agent. Please hold."
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
                    await websocket_class.transfer_to_agent(reason=session.transfer_reason)
                    time.sleep(2)
                    return False

    except Exception as e:
        session.transfer_reason = f"Garage Validation error: {str(e)}"
        message = "I'm sorry, due to a system issue, I'm connecting you to an agent who can assist you further. Please wait."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        await websocket_class.transfer_to_agent(reason=session.transfer_reason)
        time.sleep(2)
        return False