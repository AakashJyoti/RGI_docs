import os
from .utils import text_to_speech_azure_streamlit, speech_to_text_azure_streamlit_chunks, remove_fullstops_from_input



async def get_user_input_with_retries(websocket_class):
    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    output_file = os.path.join(parent_directory, "audio", "Bot", "bot_response.wav")
    sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()


    message = "Sorry, I didn't catch that. Please say it again."
    max_attempts = 0
    # for attempt in range(max_attempts):
    while max_attempts < 2:
        max_attempts += 1
        # text_to_speech_func_english(message=message)
        text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

        await websocket_class.stop_event.wait()  # Wait until the stop event is set
        combined_audio = websocket_class.combined_audio_chunks
        user_input = speech_to_text_azure_streamlit_chunks(combined_audio)
        print(user_input)

        # Validate and process input
        if user_input is not None:
            processed_text = remove_fullstops_from_input(user_input.strip().lower())
            if processed_text:
                return processed_text

    message = "Sorry, I haven’t received any input from you, so I’ll be disconnecting the call now."
    text_to_speech_azure_streamlit(message)
    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
    return False  # All attempts failed




async def handle_user_input(websocket_class):
    # with st.spinner("Recording..."):
    #     handle_recording(duration=duration)  # Assuming handle_recording is your recording function
    # user_input = speech_to_text_azure_streamlit()
    await websocket_class.stop_event.wait()  # Wait until the stop event is set
    combined_audio = websocket_class.combined_audio_chunks
    user_input = speech_to_text_azure_streamlit_chunks(combined_audio)
    print(user_input)


    if user_input is not None:
        user_input = remove_fullstops_from_input(user_input.strip().lower())
    else:
        user_input = await get_user_input_with_retries(websocket_class)

    return user_input
