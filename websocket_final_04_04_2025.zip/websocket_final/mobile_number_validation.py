import requests
import re


def validate_mobile_number_api_call(mobile_no):
    # Define the URL of the SOAP service
    url = "https://leadservices.brobotinsurance.com/rgiChatbot/ChatbotIntegrationWrapper.asmx"

    # Craft the XML request body with the passed mobile number
    soap_body = f'''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
       <soapenv:Header/>
       <soapenv:Body>
          <tem:ChatbotGetPolDataOnMobileNoWrap>
             <tem:XML><![CDATA[<CHATBOT><UserID>CHATBOT</UserID><Password>CHATBOT@123</Password><CallerAppID>16</CallerAppID><MobileNo>{mobile_no}</MobileNo></CHATBOT>]]></tem:XML>
          </tem:ChatbotGetPolDataOnMobileNoWrap>
       </soapenv:Body>
    </soapenv:Envelope>'''

    # Set the necessary headers
    headers = {
        "Content-Type": "text/xml; charset=utf-8",
        "SOAPAction": "http://tempuri.org/ChatbotGetPolDataOnMobileNoWrap"  # Action header from the API specification
    }

    # Make the POST request
    response = requests.post(url, data=soap_body, headers=headers)

    # Parse the response text
    raw_xml = response.text

    # Check if the mobile number is valid or not
    match_code = re.findall(r'ResponseCode&gt;([01])&lt;/ResponseCode&gt;', raw_xml)
    matches = re.findall(r'&lt;ResponseMessage&gt;(.*?)&lt;/ResponseMessage&gt;', raw_xml)



    if matches[0] == "No Record Found" or match_code[0] == '1':
        return "invalid mobile number"
    elif match_code[0] == '0':
        return "valid mobile number"
    else:
        return "invalid mobile number"



def validate_mobile_number(mobile_number):
    # Mock validation logic
    validate_number = validate_mobile_number_api_call(mobile_number)

    # Check if the response indicates a valid or invalid mobile number
    if validate_number == "valid mobile number":
        return True
    elif validate_number == "invalid mobile number":
        return False
    else:
        return False