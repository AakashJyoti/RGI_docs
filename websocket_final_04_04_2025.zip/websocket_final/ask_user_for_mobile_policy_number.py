import re
import time

from .utils import text_to_speech_azure_streamlit, speech_to_text_azure_streamlit_chunks
from .handle_user_input_retries import handle_user_input
from .mobile_number_validation import validate_mobile_number

async def ask_mobile_or_policy_number(session, websocket_class):
    sample_rate, sampwidth, n_channels = websocket_class.extract_wav_params()
    try:
        while session.auth_attempts < 2:
            message = "can you please share your 16 or 18 digit policy number or 10 digit registered mobile number?"
            output_file = text_to_speech_azure_streamlit(message)
            await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

            user_input = await handle_user_input(websocket_class)
            if user_input is False:
                session.transfer_reason = "Exceed the input limit"
                websocket_class.close()

            cleaned_number = re.sub(r"[^\d]", "", user_input)  # Keep only digits, remove anything else

            if len(cleaned_number) == 10 and validate_mobile_number(cleaned_number):
                session.mobile_number = cleaned_number
                return True

            elif len(cleaned_number) in [16, 18]:
                session.policy_number = cleaned_number
                return True
            else:
                session.auth_attempts += 1
                if session.auth_attempts < 2:
                    message = "I'm sorry, the information you share does not match with our records. Let's try again"
                    output_file = text_to_speech_azure_streamlit(message)
                    await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)

        session.transfer_reason = "Maximum authentication attempts exceeded"
        message = "I'm sorry, we've exceeded the maximum authentication attempts. Goodbye!"
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        return False
    except Exception as e:
        session.transfer_reason = f"Ask for mobile or policy number error: {str(e)}"
        message = "I'm sorry, due to a system issue, I'm connecting you to an agent who can assist you further. Please wait."
        output_file = text_to_speech_azure_streamlit(message)
        await websocket_class.stream_audio_back(output_file, sample_rate, sampwidth, n_channels)
        await websocket_class.transfer_to_agent(reason=session.transfer_reason)
        time.sleep(2)
        return False