from api import *
from utils import speech_to_text, text_to_speech1, redirecting_to_agent, message_website, call_openai, \
    extract_and_convert_to_json
import re
from dataclasses import dataclass
from typing import Dict, Any
import sqlite3

# Connect to the SQLite database (replace 'db.sqlite3' with your database file)
db_path = 'db.sqlite3'  # Replace with the path to your SQLite database
conn = sqlite3.connect("../db.sqlite3")

cursor = conn.cursor()

@dataclass
class ClaimSession:
    """Central data storage for claim process"""
    auth_attempts: int = 0
    policy_number: str = None
    mobile_number: str = None
    policy_details: Dict[str, Any] = None
    caller_details: Dict[str, Any] = None
    claim_details: Dict[str, Any] = None
    garage_details: Dict[str, Any] = None
    transfer_reason: str = None


def validate_policy_and_mobile_number(policy):
    valid_policies = ["9874563210", "1234567890123456", "123456789012345678", "8697745125"]
    return policy in valid_policies


def ask_mobile_or_policy_number(session: ClaimSession):
    while session.auth_attempts < 2:
        text_to_speech1("Can you please share your 16 or 18 digit policy number or 10 digit registered mobile number?")
        user_input = str(speech_to_text()).strip().lower()
        cleaned_number = re.sub(r"[.-]", "", user_input)

        if validate_policy_and_mobile_number(cleaned_number):
            if len(cleaned_number) == 10:
                session.mobile_number = cleaned_number
            else:
                session.policy_number = cleaned_number
            return True
        else:
            session.auth_attempts += 1
            if session.auth_attempts < 2:
                text_to_speech1("The information does not match our records. Let's try again.")

    session.transfer_reason = "Maximum authentication attempts exceeded"
    text_to_speech1("I'm sorry, we've exceeded the maximum attempts. Goodbye!")
    return False


def get_policy_details(session: ClaimSession):
    identifier = session.mobile_number or session.policy_number
    session.policy_details = fetch_policy_details_via_phone_number(identifier)

    if not session.policy_details:
        session.transfer_reason = "Policy details not found"
        return False

    text_to_speech1(
        "I have identified your policy. I will now direct you to the appropriate team based on your policy type.")
    text_to_speech1("Could you kindly confirm your policy number?")

    confirm_policy_number = str(speech_to_text()).strip().lower()
    if confirm_policy_number.endswith('.'):
        confirm_policy_number = confirm_policy_number[:-1]

    if confirm_policy_number != session.policy_details['policyno']:
        session.transfer_reason = "Policy number mismatch"
        text_to_speech1("The policy number you provided does not match our records. Let me connect you with an agent.")
        return False

    text_to_speech1(
        f"""Please confirm the following policy details. Policy Number: {session.policy_details['policyno']}, Insured Name: {session.policy_details['insured_name']}""")
    return True


def insured_confirmation(session: ClaimSession):
    session.caller_details = {}
    message = f"Thank you. I've successfully validated your policy. The insured's name is {session.policy_details['insured_name']}. Could you please confirm if you are the insured?"
    text_to_speech1(message)

    confirm_insured_or_not = str(speech_to_text()).strip().lower()
    if 'yes' in confirm_insured_or_not:
        session.caller_details["is_insured"] = True
        text_to_speech1(
            f"Thank you for confirming, {session.policy_details['insured_name']}. Let's proceed with your claim.")
    else:
        session.caller_details["is_insured"] = False
        text_to_speech1("I understand that you're not the insured. I will need to collect some information from you.")

        text_to_speech1("Could you please confirm your relationship with the insured?")
        session.caller_details['relationship'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please help us with your full name.")
        session.caller_details['name'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please provide your mobile number.")
        session.caller_details['mobile'] = re.sub(r"[.-]", "", str(speech_to_text()).strip().lower())


def claim_type(session: ClaimSession):
    session.claim_details = {}
    text_to_speech1("Please confirm whether this claim is for an accident or theft.")

    claim_type_response = str(speech_to_text()).strip().lower()
    prompt = f"""Classify as accident or theft from: {claim_type_response}"""
    claim_type_detail = extract_and_convert_to_json(call_openai(prompt))

    if 'theft' in claim_type_detail.get('claim_type', ''):
        session.transfer_reason = "Theft claim requires specialist handling"
        text_to_speech1(
            "I understand this is a theft claim. I'll need to transfer you to a specialized agent for further assistance. Please hold.")
        session.claim_details['claim_type'] = 'theft'
        return False
    elif 'accident' in claim_type_detail.get('claim_type', ''):
        session.claim_details['claim_type'] = 'accident'
        text_to_speech1("I'm sorry to hear about the accident. Have you reported the vehicle to a garage?")

        response = str(speech_to_text()).strip().lower()
        if 'no' in response:
            session.transfer_reason = "Vehicle not reported to garage"
            text_to_speech1(
                "Since the vehicle hasn't been reported to a garage yet, I will transfer you to an agent for further guidance. Please hold.")
            return False

        # Collect accident details
        text_to_speech1("Please provide the date of the accident.")
        session.claim_details['accident_date'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please provide the time of the accident.")
        session.claim_details['accident_time'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please provide the location of the accident.")
        session.claim_details['accident_location'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please provide the driver information.")
        session.claim_details['driver_info'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please provide the garage information.")
        session.claim_details['garage_info'] = str(speech_to_text()).strip().lower()

        return True


# def garage_validation(session: ClaimSession):
#     text_to_speech1("Please provide the pincode of the garage.")
#     pincode = re.sub(r"[.-]", "", str(speech_to_text()).strip())
#
#     query = f"SELECT * FROM motor_claim_GarageMaster WHERE Pincode = '{pincode}';"
#     cursor.execute(query)
#     records = cursor.fetchall()
#
#     if not records:
#         session.transfer_reason = "No garages found in provided pincode"
#         text_to_speech1("No garages were found in that pincode. Transferring you to an agent.")
#         return False
#
#     # Rest of original garage validation logic remains unchanged
#     # ...
#     return True


def garage_validation(session: ClaimSession):
    session.garage_details = {}
    session.claim_details = session.claim_details or {}

    # Step 1: Ask for pincode
    text_to_speech1("Please provide the pincode of the garage.")
    pincode_input = str(speech_to_text()).strip().lower()
    pincode = re.sub(r"[.-]", "", pincode_input)

    # Step 2: Query database
    query = f"SELECT * FROM motor_claim_GarageMaster WHERE Pincode = '{pincode}';"
    cursor.execute(query)
    records = cursor.fetchall()

    text_to_speech1("Thank you for providing the pincode. I'm now checking our records for that pincode.")

    # Step 3: Handle no garages found
    if len(records) == 0:
        session.transfer_reason = "No garages found in pincode"
        text_to_speech1(
            "No garages were found in that pincode. I will now transfer you to an agent for further assistance. Please hold.")
        return False

    # Step 4: Single garage found
    elif len(records) == 1:
        garage = {
            'GarageID': records[0][1],
            'GarageName': records[0][5],
            'Address': records[0][6],
            'Pincode': records[0][7]
        }
        confirm_message = f"We found the garage {garage['GarageName']} located at {garage['Address']}. Is this correct?"
        text_to_speech1(confirm_message)
        confirmation = str(speech_to_text()).strip().lower()

        if 'yes' in confirmation:
            text_to_speech1("The garage has been verified in our system. Let's proceed with the claim.")
            session.garage_details = garage
            return True
        else:
            session.transfer_reason = "User rejected single garage match"
            text_to_speech1("Please hold while I transfer you to an agent for further assistance.")
            return False

    # Step 5: Multiple garages found
    else:
        text_to_speech1("We found multiple garages in that pincode. Please provide the name of the garage.")
        garage_name_input = str(speech_to_text()).strip().lower()
        garage_name = re.sub(r"[.-]", "", garage_name_input)

        # Filter by name
        matching_garages = []
        for record in records:
            if garage_name in record[5].lower():
                matching_garages.append({
                    'GarageID': record[1],
                    'GarageName': record[5],
                    'Address': record[6],
                    'Pincode': record[7]
                })

        # No name matches
        if len(matching_garages) == 0:
            text_to_speech1("No exact matches found. Let me list all garages in this pincode for confirmation:")
            selected_garage = None

            for record in records:
                garage = {
                    'GarageID': record[1],
                    'GarageName': record[5],
                    'Address': record[6],
                    'Pincode': record[7]
                }
                confirm_msg = f"Did you mean {garage['GarageName']} located at {garage['Address']}?"
                text_to_speech1(confirm_msg)
                response = str(speech_to_text()).strip().lower()

                if 'yes' in response:
                    selected_garage = garage
                    break

            if selected_garage:
                text_to_speech1(
                    f"Confirmed {selected_garage['GarageName']}. The garage has been verified. Let's proceed with the claim.")
                session.garage_details = selected_garage
                return True
            else:
                session.transfer_reason = "No garage selected from multiple options"
                text_to_speech1(
                    "None of the garages matched your request. Please hold while I transfer you to an agent.")
                return False

        # Single name match
        elif len(matching_garages) == 1:
            garage = matching_garages[0]
            confirm_message = f"We found {garage['GarageName']} located at {garage['Address']}. Is this correct?"
            text_to_speech1(confirm_message)
            confirmation = str(speech_to_text()).strip().lower()

            if 'yes' in confirmation:
                text_to_speech1("The garage has been verified in our system. Let's proceed with the claim.")
                session.garage_details = garage
                return True
            else:
                session.transfer_reason = "User rejected single name-matched garage"
                text_to_speech1("Please hold while I transfer you to an agent for further assistance.")
                return False

        # Multiple name matches
        else:
            text_to_speech1("There are multiple garages with that name. Let me confirm each one:")
            selected_garage = None

            for garage in matching_garages:
                confirm_msg = f"Is it {garage['GarageName']} located at {garage['Address']}?"
                text_to_speech1(confirm_msg)
                response = str(speech_to_text()).strip().lower()

                if 'yes' in response:
                    selected_garage = garage
                    break

            if selected_garage:
                text_to_speech1(
                    f"You have confirmed {selected_garage['GarageName']}. The garage has been verified. Let's proceed with the claim.")
                session.garage_details = selected_garage
                return True
            else:
                session.transfer_reason = "No garage selected from multiple name matches"
                text_to_speech1("None of the garages were selected. I will now transfer you to an agent. Please hold.")
                return False

def proceed_with_claim(session: ClaimSession):
    try:
        payload = {
            "PolicyNo": session.policy_details['policyno'],
            "InsuredName": session.policy_details['insured_name'],
            "GarageID": session.garage_details['GarageID'],
            # ... other fields from session data
        }

        # Simulated API call
        response = {"ClaimNo": "3125000024", "Status": "Success"}
        session.claim_details['claim_id'] = response['ClaimNo']

        confirm_message = f"Your claim {session.claim_details['claim_id']} details: ..."
        text_to_speech1(confirm_message)

        if 'no' in str(speech_to_text()).lower():
            session.transfer_reason = "User requested details correction"
            return False

        return True
    except Exception as e:
        session.transfer_reason = f"Claim processing error: {str(e)}"
        return False



def proceed_with_claim(session: ClaimSession):
    try:
        # Step 1: Generate claim intimation
        text_to_speech1("I'll now generate your claim intimation ID. Please wait a moment while I process this.")

        # Prepare API payload from session data
        payload = {
            "PolicyNo": session.policy_details.get('policyno', '160221923730000221'),
            "IntimaterName": session.caller_details.get('name', 'Unknown'),
            "MinOfLoss": "57",  # Default value
            "CreatedBy": "3539",  # System ID
            "IntimaterMobileNo": session.caller_details.get('mobile', '0000000000'),
            "InsuredName": session.policy_details.get('insured_name', 'Unknown'),
            "LOSSDATE": session.claim_details.get('accident_date', 'N/A'),
            "DescriptionOfLoss": "Automated claim intimation",
            "DriverName": session.claim_details.get('driver_info', 'Unknown'),
            "HourOfLoss": session.claim_details.get('accident_time', 'Unknown'),
            "RequestSource": "4708", Channel ID
            "InsuredMobileNumber": session.mobile_number,
            "ReasonForDelayInIntimation": "1",
            "InsuredWhatsappNumber": session.mobile_number,
            "InsuredEmailId": "unknown@example.com",
            "InsuredWhatsappConsent": "True",
            "EstimatedLoss": "1",  # Default value
            "GarageID": session.garage_details.get('GarageID', '0000')
        }

        # Simulate API call (replace with actual implementation)
        response = {
            "ServiceRequest": None,
            "Status": "Success",
            "StatusCode": 2000,
            "Result": [{
                "ClaimNo": "31250000" + str(random.randint(1000, 9999)),
                "Errorresponse": "",
                "Status": "Success"
            }],
            "RequestEndTime": datetime.now().strftime("%m/%d/%Y %I:%M:%S %p")
        }

        # Handle API failure
        if not response or response.get('Status') != 'Success':
            session.transfer_reason = "Claim API failure"
            text_to_speech1("System error generating claim ID. Transferring to agent.")
            return False

        # Store claim number in session
        session.claim_details['claim_no'] = response['Result'][0]['ClaimNo']

        # Step 2: Confirm details with user
        confirm_message = (
            f"Your claim {session.claim_details['claim_no']} details: "
            f"Policy: {payload['PolicyNo']}, "
            f"Insured: {payload['InsuredName']}, "
            f"Accident Date: {payload['LOSSDATE']}, "
            f"Time: {payload['HourOfLoss']}, "
            f"Location: {session.claim_details.get('accident_location', 'N/A')}, "
            f"Driver: {payload['DriverName']}, "
            f"Garage: {session.garage_details.get('GarageName', 'N/A')} "
            "Please confirm if all details are correct."
        )
        text_to_speech1(confirm_message)
        confirmation = speech_to_text().strip().lower()

        if 'no' in confirmation:
            session.transfer_reason = "User requested details correction"
            text_to_speech1("Transferring to agent for corrections.")
            return False

        # Final confirmation
        text_to_speech1("Claim successfully registered! Your claim number is " +
                        " ".join(session.claim_details['claim_no']) +
                        ". We'll send SMS confirmation shortly.")
        return True

    except Exception as e:
        session.transfer_reason = f"Claim processing error: {str(e)}"
        text_to_speech1("System error occurred. Transferring to agent.")
        return False



def claim_intimation_flow():
    session = ClaimSession()
    text_to_speech1("Namaste! Welcome to our claim helpline.")

    # Authentication flow
    if not ask_mobile_or_policy_number(session):
        return redirecting_to_agent(session.__dict__)

    # Policy validation
    if not get_policy_details(session):
        return redirecting_to_agent(session.__dict__)

    # Insured confirmation
    insured_confirmation(session)

    # Claim type handling
    if not claim_type(session):
        return redirecting_to_agent(session.__dict__)

    # Garage validation
    if not garage_validation(session):
        return redirecting_to_agent(session.__dict__)

    # Final claim processing
    if not proceed_with_claim(session):
        return redirecting_to_agent(session.__dict__)

    # Conclusion
    text_to_speech1("Thank you for using our claim service!")
    return session.__dict__


def redirecting_to_agent(session_data: dict):
    print(f"Transferring call with complete session data: {session_data}")
    # Implementation to transfer data to agent system
    message_website(session_data)
    # Actual transfer logic would go here


claim_intimation_flow()