from soap_api_number import *
import requests

def validate_policy(p_n):
    if not p_n:
        return "Bot: To proceed with your claim, can you please share your 16/18 digit policy number or 10 digit registered mobile number???"

    if len(p_n) == 1:
        print(f"Bot: I have found 1 policy with this registered mobile number and the policy number is {p_n[0]}.would you like to go with this policy?")
        customer_response = input("Customer: ").strip().lower()
        if customer_response == "yes":
            print("Bot: Thank you. I am now validating the information you provided. Please wait a moment.")
        return

    print(f"Bot: I have identified {len(p_n)} policy.")

    for policy in p_n:
        print(f"Bot: Policy number is {policy}, would you like to go with this policy?")
        customer_response = input("Customer: ").strip().lower()
        if customer_response == "yes":
            print("Bot: Thank you. I am now validating the information provided by you. Please wait a moment.")
            return policy

    print("Bot: Thank you. I am now validating the information provided by you. Please wait a moment.")



vp=validate_policy(emp)

print("VP: ",vp)


url = "https://avenue.brobotinsurance.com/yb/api/Users/GetMotordetailsforwebsite"

payload = f"""{{
    "Para1": "P",
    "Para2": "{vp}",
    "Para3": "C",
    "Para4": "9999",
    "Para5": "Y"
}}"""


headers = {
  'Ocp-Apim-Subscription-Key': 'b312b057aa5f4901ab70cde9e62020f9'
}

response = requests.request("POST", url, headers=headers, data=payload)

print(response.text)

