import sqlite3
from motor_api import *
from utils import speech_to_text,text_to_speech1, remove_fullstop_from_input,redirecting_to_agent, message_website,call_openai,extract_and_convert_to_json
import re

# Connect to the SQLite database (replace 'db.sqlite3' with your database file)
db_path = 'db.sqlite3'  # Replace with the path to your SQLite database
conn = sqlite3.connect("../db.sqlite3")

cursor = conn.cursor()


# # Function to fetch all records from the GarageMaster table
# def fetch_all_records():
#     # query = "SELECT * FROM motor_claim_GarageMaster"
#     query = "SELECT * FROM motor_claim_GarageMaster WHERE Pincode = '110042';"
#
#     # query = "SELECT * FROM motor_claim_GarageMaster WHERE REPLACE(Address, ' ', '') = REPLACE('D. K. Mohan Garden', ' ', '');"
#
#     cursor.execute(query)
#     records = cursor.fetchall()
#     print(len(records))
#     # Print the fetched records
#     for record in records:
#         print(record)




############
# Deepseek #
############

# def garage_validation_deepseek():
#     claim_details = {}
#
#     # Step 1: Ask for pincode
#     text_to_speech1("Please provide the pincode of the garage.")
#     pincode = remove_fullstop_from_input(str(speech_to_text()).strip())
#     # pincode = "110042"
#
#     # Query database for garages in the provided pincode
#     query = f"SELECT * FROM motor_claim_GarageMaster WHERE Pincode = '{pincode}';"
#     cursor.execute(query)
#     records = cursor.fetchall()
#
#     text_to_speech1("Thank you for providing the pincode. I'm now checking our records for that pincode.")
#
#     if len(records) == 0:
#         # No garages found in the pincode
#         text_to_speech1("No garages were found in that pincode. Would you like me to transfer you to an agent for further assistance?")
#         transfer_response = str(speech_to_text()).strip().lower()
#         if 'yes' in transfer_response:
#             text_to_speech1("Certainly. Please hold while I transfer you to an agent.")
#             claim_details['transfer_to_agent'] = True
#         else:
#             text_to_speech1("I understand. Is there anything else I can help you with today?")
#         return claim_details
#
#     elif len(records) == 1:
#         # Single garage found, confirm details
#         garage = {
#             'GarageID': records[0][1],
#             'GarageName': records[0][5],
#             'Address': records[0][6],
#             'Pincode': records[0][7]
#         }
#         confirm_message = f"We found the garage {garage['GarageName']} located at {garage['Address']}. Is this correct?"
#         text_to_speech1(confirm_message)
#         confirmation = str(speech_to_text()).strip().lower()
#         if 'yes' in confirmation:
#             text_to_speech1("The garage has been verified in our system. Let's proceed with the claim.")
#             claim_details['garage_details'] = garage
#         else:
#             # text_to_speech1("Would you like me to transfer you to an agent for further assistance?")
#             # transfer_response = str(speech_to_text()).strip().lower()
#             # if 'yes' in transfer_response:
#             #     text_to_speech1("Certainly. Please hold while I transfer you to an agent.")
#             #     claim_details['transfer_to_agent'] = True
#             # else:
#             #     text_to_speech1("I understand. Is there anything else I can help you with today?")
#             text_to_speech1("Please hold while I transfer you to an agent for further assistance.")
#             claim_details['transfer_to_agent'] = True
#
#         return claim_details
#     else:
#         # Multiple garages found, ask for garage name
#         text_to_speech1("We found multiple garages in that pincode. Please provide the name of the garage.")
#         garage_name_response = remove_fullstop_from_input(str(speech_to_text()).strip().lower())
#
#         # Filter records by garage name (case-insensitive partial match)
#         matching_garages = []
#         for record in records:
#             if garage_name_response in record[5].lower():
#                 matching_garages.append({
#                     'GarageID': record[1],
#                     'GarageName': record[5],
#                     'Address': record[6],
#                     'Pincode': record[7]
#                 })
#
#         if len(matching_garages) == 0:
#             text_to_speech1("No exact matches found. Let me list all garages in this pincode for confirmation:")
#             selected_garage = None
#
#             # List all garages in the pincode for confirmation
#             for record in records:
#                 garage = {
#                     'GarageID': record[1],
#                     'GarageName': record[5],
#                     'Address': record[6],
#                     'Pincode': record[7]
#                 }
#                 confirm_msg = f"Did you mean {garage['GarageName']} located at {garage['Address']}?"
#                 text_to_speech1(confirm_msg)
#                 response = remove_fullstop_from_input(str(speech_to_text()).strip().lower())
#
#                 if 'yes' in response:
#                     selected_garage = garage
#                     break
#
#             if selected_garage:
#                 text_to_speech1(
#                     f"Confirmed {selected_garage['GarageName']}. The garage has been verified. Let's proceed with the claim.")
#                 claim_details['garage_details'] = selected_garage
#             else:
#                 # text_to_speech1(
#                 #     "None of the garages matched your request. Would you like me to transfer you to an agent?")
#                 # transfer_response = remove_fullstop_from_input(str(speech_to_text()).strip().lower())
#                 # if 'yes' in transfer_response:
#                 #     text_to_speech1("Certainly. Please hold while I transfer you to an agent.")
#                 #     claim_details['transfer_to_agent'] = True
#                 # else:
#                 #     text_to_speech1("I understand. Is there anything else I can help you with today?")
#                 text_to_speech1(
#                     "None of the garages matched your request. Please hold while I transfer you to an agent for further assistance.")
#                 claim_details['transfer_to_agent'] = True
#             return claim_details
#
#         elif len(matching_garages) == 1:
#             # Single matching garage after name filter
#             garage = matching_garages[0]
#             confirm_message = f"We found {garage['GarageName']} located at {garage['Address']}. Is this correct?"
#             text_to_speech1(confirm_message)
#             confirmation = str(speech_to_text()).strip().lower()
#             if 'yes' in confirmation:
#                 text_to_speech1("The garage has been verified in our system. Let's proceed with the claim.")
#                 claim_details['garage_details'] = garage
#             else:
#                 # text_to_speech1("Would you like me to transfer you to an agent for further assistance?")
#                 # transfer_response = str(speech_to_text()).strip().lower()
#                 # if 'yes' in transfer_response:
#                 #     text_to_speech1("Certainly. Please hold while I transfer you to an agent.")
#                 #     claim_details['transfer_to_agent'] = True
#                 # else:
#                 #     text_to_speech1("I understand. Is there anything else I can help you with today?")
#                 text_to_speech1("Please hold while I transfer you to an agent for further assistance.")
#                 claim_details['transfer_to_agent'] = True
#             return claim_details
#
#         else:
#             # Multiple garages after name filter, confirm each one
#             text_to_speech1("There are multiple garages with that name. Let me confirm each one:")
#             selected_garage = None
#             for garage in matching_garages:
#                 confirm_msg = f"Is it {garage['GarageName']} located at {garage['Address']}?"
#                 text_to_speech1(confirm_msg)
#                 response = str(speech_to_text()).strip().lower()
#                 if 'yes' in response:
#                     selected_garage = garage
#                     break
#
#             if selected_garage:
#                 text_to_speech1(f"You have confirmed {selected_garage['GarageName']}. The garage has been verified. Let's proceed with the claim.")
#                 claim_details['garage_details'] = selected_garage
#             else:
#                 # text_to_speech1("None of the garages were selected. Would you like me to transfer you to an agent?")
#                 # transfer_response = str(speech_to_text()).strip().lower()
#                 # if 'yes' in transfer_response:
#                 #     text_to_speech1("Certainly. Please hold while I transfer you to an agent.")
#                 #     claim_details['transfer_to_agent'] = True
#                 # else:
#                 #     text_to_speech1("I understand. Is there anything else I can help you with today?")
#                 text_to_speech1("None of the garages were selected. I will now transfer you to an agent. Please hold.")
#                 claim_details['transfer_to_agent'] = True
#             return claim_details




def garage_validation():
    claim_details = {}

    # Step 1: Ask for pincode
    text_to_speech1("Please provide the pincode of the garage.")
    pincode = remove_fullstop_from_input(str(speech_to_text()).strip())
    # pincode = "110042"

    # Query database for garages in the provided pincode
    query = f"SELECT * FROM motor_claim_GarageMaster WHERE Pincode = '{pincode}';"
    cursor.execute(query)
    records = cursor.fetchall()

    text_to_speech1("Thank you for providing the pincode. I'm now checking our records for that pincode.")

    if len(records) == 0:
        text_to_speech1(
            "No garages were found in that pincode. I will now transfer you to an agent for further assistance. Please hold.")
        claim_details['transfer_to_agent'] = True

        return claim_details

    elif len(records) == 1:
        # Single garage found, confirm details
        garage = {
            'GarageID': records[0][1],
            'GarageName': records[0][5],
            'Address': records[0][6],
            'Pincode': records[0][7]
        }
        confirm_message = f"We found the garage {garage['GarageName']} located at {garage['Address']}. Is this correct?"
        text_to_speech1(confirm_message)
        confirmation = str(speech_to_text()).strip().lower()
        if 'yes' in confirmation:
            text_to_speech1("The garage has been verified in our system. Let's proceed with the claim.")
            claim_details['garage_details'] = garage
        else:
            text_to_speech1("Please hold while I transfer you to an agent for further assistance.")
            claim_details['transfer_to_agent'] = True

        return claim_details
    else:
        # Multiple garages found, ask for garage name
        text_to_speech1("We found multiple garages in that pincode. Please provide the name of the garage.")
        garage_name_response = remove_fullstop_from_input(str(speech_to_text()).strip().lower())

        # Filter records by garage name (case-insensitive partial match)
        matching_garages = []
        for record in records:
            if garage_name_response in record[5].lower():
                matching_garages.append({
                    'GarageID': record[1],
                    'GarageName': record[5],
                    'Address': record[6],
                    'Pincode': record[7]
                })

        if len(matching_garages) == 0:
            text_to_speech1("No exact matches found. Let me list all garages in this pincode for confirmation:")
            selected_garage = None

            # List all garages in the pincode for confirmation
            for record in records:
                garage = {
                    'GarageID': record[1],
                    'GarageName': record[5],
                    'Address': record[6],
                    'Pincode': record[7]
                }
                confirm_msg = f"Did you mean {garage['GarageName']} located at {garage['Address']}?"
                text_to_speech1(confirm_msg)
                response = remove_fullstop_from_input(str(speech_to_text()).strip().lower())

                if 'yes' in response:
                    selected_garage = garage
                    break

            if selected_garage:
                text_to_speech1(
                    f"Confirmed {selected_garage['GarageName']}. The garage has been verified. Let's proceed with the claim.")
                claim_details['garage_details'] = selected_garage
            else:
                text_to_speech1(
                    "None of the garages matched your request. Please hold while I transfer you to an agent for further assistance.")
                claim_details['transfer_to_agent'] = True
            return claim_details

        elif len(matching_garages) == 1:
            # Single matching garage after name filter
            garage = matching_garages[0]
            confirm_message = f"We found {garage['GarageName']} located at {garage['Address']}. Is this correct?"
            text_to_speech1(confirm_message)
            confirmation = str(speech_to_text()).strip().lower()
            if 'yes' in confirmation:
                text_to_speech1("The garage has been verified in our system. Let's proceed with the claim.")
                claim_details['garage_details'] = garage
            else:
                text_to_speech1("Please hold while I transfer you to an agent for further assistance.")
                claim_details['transfer_to_agent'] = True
            return claim_details

        else:
            # Multiple garages after name filter, confirm each one
            text_to_speech1("There are multiple garages with that name. Let me confirm each one:")
            selected_garage = None
            for garage in matching_garages:
                confirm_msg = f"Is it {garage['GarageName']} located at {garage['Address']}?"
                text_to_speech1(confirm_msg)
                response = str(speech_to_text()).strip().lower()
                if 'yes' in response:
                    selected_garage = garage
                    break

            if selected_garage:
                text_to_speech1(f"You have confirmed {selected_garage['GarageName']}. The garage has been verified. Let's proceed with the claim.")
                claim_details['garage_details'] = selected_garage
            else:
                text_to_speech1("None of the garages were selected. I will now transfer you to an agent. Please hold.")
                claim_details['transfer_to_agent'] = True
            return claim_details






def proceed_with_claim(claim_details):
    # Step 6: Proceeding with the Claim
    text_to_speech1("I'll now generate your claim intimation ID. Please wait a moment while I process this.")

    # Prepare API payload
    payload = {
        "PolicyNo": claim_details.get('PolicyNo', '160221923730000221'),
        "IntimaterName": "test",
        "MinOfLoss": "57",
        "CreatedBy": "3539",
        "IntimaterMobileNo": "1223456789",
        "InsuredName": claim_details.get('InsuredName', 'JALPAN R SHAH'),
        "LOSSDATE": "4/8/2023",
        "DescriptionOfLoss": "test",
        "DriverName": "test",
        "HourOfLoss": "12",
        "RequestSource": "4708",
        "InsuredMobileNumber": "1234567890",
        "ReasonForDelayInIntimation": "1",
        "InsuredWhatsappNumber": "1234567890",
        "InsuredEmailId": "a@b.com",
        "InsuredWhatsappConsent": "True",
        "EstimatedLoss": "1",
        "GarageID": claim_details['garage_details']['GarageID']
    }

    #Simulate API call (replace with actual API endpoint and headers)
    try:
        # response = requests.post("API_ENDPOINT", json=payload, headers=HEADERS)
        # Mock response for demonstration
        response = {
            "ServiceRequest": None,
            "Status": "Success",
            "StatusCode": 2000,
            "Result": [{
                "ClaimNo": "3125000024",
                "Errorresponse": "",
                "Status": "Success"
            }],
            "RequestEndTime": "1/30/2025 10:34:53 AM"
        }
    except Exception as e:
        response = None

    if not response or response.get('Status') != 'Success' or response.get('StatusCode') != 2000:
        text_to_speech1(
            "I'm sorry, I'm having trouble generating your claim intimation ID due to a system issue. I will transfer you to an agent who can help you further. Please hold.")
        claim_details['transfer_to_agent'] = True
        return claim_details

    # Extract ClaimNo from response
    claim_no = response['Result'][0]['ClaimNo']
    claim_details['ClaimNo'] = claim_no

    # Confirm details with user
    confirm_message = (
        "Your claim intimation ID has been successfully generated. Let me confirm all the details with you: "
        f"Policy Number: {claim_details.get('PolicyNo', 'N/A')}, "
        f"Insured's Name: {claim_details.get('InsuredName', 'N/A')}, "
        f"Accident Date: {payload['LOSSDATE']}, "
        f"Accident Time: {payload['HourOfLoss']}, "
        f"Accident Location: {claim_details.get('AccidentLocation', 'N/A')}, "
        f"Driver Name: {payload['DriverName']}, "
        f"Garage Name: {claim_details['garage_details']['GarageName']}, "
        f"Garage Location: {claim_details['garage_details']['Address']}. "
        "Please confirm if all details are correct."
    )
    text_to_speech1(confirm_message)
    confirmation = speech_to_text().strip().lower()

    if 'yes' in confirmation:
        text_to_speech1("Great! Your claim details are confirmed. Let's proceed to the final step.")
    else:
        text_to_speech1("I'll transfer you to an agent to correct the details. Please hold.")
        claim_details['transfer_to_agent'] = True

    return claim_details


def conclusion_step():
    # Step 7: Conclusion
    text_to_speech1("Is there anything else I can help you with today?")
    response = speech_to_text().strip().lower()

    if 'yes' in response:
        text_to_speech1("Please let me know how I can assist you further.")
        # Handle further assistance logic here
    else:
        text_to_speech1(
            "Thank you for contacting our claim intimation helpline. If you have any further questions or concerns, feel free to call us back or visit our website. Have a great day!")

    return

proceed_with_claim()
conclusion_step()