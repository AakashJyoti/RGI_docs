from api import *
from utils import speech_to_text,text_to_speech1, redirecting_to_agent, message_website,call_openai,extract_and_convert_to_json
import re
import sqlite3
from dataclasses import dataclass
from typing import Dict, Any
import requests

# Connect to the SQLite database (replace 'db.sqlite3' with your database file)
db_path = 'db.sqlite3'  # Replace with the path to your SQLite database
conn = sqlite3.connect("../db.sqlite3")
cursor = conn.cursor()

@dataclass
class ClaimSession:
    """Central data storage for claim process"""
    auth_attempts: int = 0
    policy_number: str = None
    mobile_number: str = None
    policy_details: Dict[str, Any] = None
    caller_details: Dict[str, Any] = None
    claim_details: Dict[str, Any] = None
    garage_details: Dict[str, Any] = None
    transfer_reason: str = None


def validate_mobile_number(mobile_number):
    # mobile_number = session.mobile_number
    # Mock validation logic
    valid_policies = ["9876543210","1234567890123456", "123456789012345678","8697745125"]
    return mobile_number in valid_policies


def ask_mobile_or_policy_number(session:ClaimSession):
    while session.auth_attempts < 2:
        text_to_speech1("Can you please share your 16 or 18 digit policy number or 10 digit registered mobile number?")
        user_input = str(speech_to_text()).strip().lower()
        cleaned_number = re.sub(r"[.-]", "", user_input)
        if validate_mobile_number(cleaned_number):
            if len(cleaned_number) == 10:
                session.mobile_number = cleaned_number
            else:
                session.policy_number = cleaned_number
            return True
        else:
            session.auth_attempts += 1
            if session.auth_attempts < 2:
                text_to_speech1("The information does not match our records. Let's try again.")
    session.transfer_reason = "Maximum authentication attempts exceeded"
    text_to_speech1("I'm sorry, we've exceeded the maximum attempts. Goodbye!")
    return False


def get_policy_details(session:ClaimSession):
    mobile_number = session.mobile_number
    session.policy_details = fetch_policy_details_via_phone_number(mobile_number)
    if session.policy_details:
        text_to_speech1("I have identified your policy. I will now direct you to the appropriate team based on your policy type.")
        text_to_speech1("Could you kindly confirm your policy number?")

        confirm_policy_number = str(speech_to_text()).strip().lower()
        confirm_policy_number = remove_fullstop_from_input(confirm_policy_number)
        confirm_policy_number = "160221923730000221"
        # confirm_policy_number="110322423110146463"
        if confirm_policy_number == session.policy_details['policyno']:
            text_to_speech1(f"""Please confirm the following policy details. Policy Number: {session.policy_details['policyno']}, Insured Name: {session.policy_details['insured_name']}""")
            return True
        else:
            session.transfer_reason = "Policy number mismatch"
            text_to_speech1("The policy number you provided does not match our records. Let me connect you with an agent.")
            return False
    else:
        session.transfer_reason = "Policy details not found"
        return False


def insured_confirmation(session: ClaimSession):
    session.caller_details = {}
    # if policy_details:
    message = f"Thank you. I've successfully validated your policy. The insured's name is {session.policy_details['insured_name']}. could you please confirm if you are the insured?"
    text_to_speech1(message)

    confirm_insured_or_not = str(speech_to_text()).strip().lower()

    if 'yes' in confirm_insured_or_not :
        session.caller_details["is_insured"] = True
        text_to_speech1(f"Thank you for confirming, {session.policy_details['insured_name']}. Let's proceed with your claim.")
    else:
        session.caller_details["is_insured"] = False
        text_to_speech1("I understand that you're not the insured. I will need to collect some information from you.")

        text_to_speech1("Could you please confirm your relationship with the insured?")
        session.caller_details['relationship'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please help us with your full name.")
        session.caller_details['name'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please provide your mobile number.")
        session.caller_details['mobile'] = str(speech_to_text()).strip().lower()


def claim_type(session:ClaimSession):
    session.claim_details = {}

    text_to_speech1("Please confirm whether this claim is for an accident or theft.")
    claim_type_response = str(speech_to_text()).strip().lower()

    prompt = f"""
    You are a claim type classifier. Your task is to strictly identify whether the given details represent an accident or theft. 

    IMPORTANT RULES:
    - You MUST return ONLY ONE claim type: either "accident" or "theft".
    - If the details do NOT clearly indicate either accident or theft, respond with None.
    - Return the result in strict JSON format.
    - Do NOT provide multiple claim types or any additional explanations.

    Input Details: {claim_type_response}

    Expected Output Format:
    {{
        "claim_type": "accident" OR "claim_type": "theft"
    }}
    """

    claim_type_detail = extract_and_convert_to_json(call_openai(prompt))

    if 'theft' in claim_type_detail.get('claim_type'):
        session.transfer_reason = "Theft claim requires specialist handling"
        text_to_speech1("I understand this is a theft claim. I'll need to transfer you to a specialized agent for further assistance. Please hold.")

        session.claim_details['claim_type'] = 'theft'
        return False
    elif 'accident' in claim_type_detail.get('claim_type'):
        session.claim_details['claim_type'] = 'accident'
        text_to_speech1("I'm sorry to hear about the accident. Have you reported the vehicle to a garage?")
        response = str(speech_to_text()).strip().lower()

        if 'no' in response:
            session.transfer_reason = "Vehicle not reported to garage"
            text_to_speech1("Since the vehicle hasn't been reported to a garage yet, I will transfer you to an agent for further guidance on the next steps. Please hold.")
            return False

        text_to_speech1("Thank you for reporting the vehicle. I will need some details about the accident. Let's go through them one by one.")

        # Collect Accident Details
        text_to_speech1("Please provide the date of the accident.")
        session.claim_details['accident_date'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please provide the time of the accident.")
        session.claim_details['accident_time'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please provide the location of the accident.")
        session.claim_details['accident_location'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please provide the driver information.")
        session.claim_details['driver_info'] = str(speech_to_text()).strip().lower()

        text_to_speech1("Please provide the garage information.")
        session.claim_details['garage_info'] = str(speech_to_text()).strip().lower()

        return True

def garage_validation(session:ClaimSession):
    session.garage_details = {}

    # Step 1: Ask for pincode
    text_to_speech1("Please provide the pincode of the garage.")
    pincode_input = str(speech_to_text()).strip().lower()
    pincode = re.sub(r"[.-]", "", pincode_input)
    # pincode = "110042" T

    #pincode="110059" VD auto wheels

    # Step 2: Query database
    query = f"SELECT * FROM motor_claim_GarageMaster WHERE Pincode = '{pincode}';"
    cursor.execute(query)
    records = cursor.fetchall()

    text_to_speech1("Thank you for providing the pincode. I'm now checking our records for that pincode.")

    # Step 3: Handle no garages found
    if len(records) == 0:
        session.transfer_reason = "No garages found in pincode"
        text_to_speech1(
            "No garages were found in that pincode. I will now transfer you to an agent for further assistance. Please hold.")
        return False

    # Step 4: Single garage found
    elif len(records) == 1:
        garage = {
            'GarageID': records[0][1],
            'GarageName': records[0][5],
            'Address': records[0][6],
            'Pincode': records[0][7]
        }
        confirm_message = f"We found the garage {garage['GarageName']} located at {garage['Address']}. Is this correct?"
        text_to_speech1(confirm_message)
        confirmation = str(speech_to_text()).strip().lower()

        if 'yes' in confirmation:
            text_to_speech1("The garage has been verified in our system. Let's proceed with the claim.")
            session.garage_details = garage
            return True
        else:
            session.transfer_reason = "User rejected single garage match"
            text_to_speech1("Please hold while I transfer you to an agent for further assistance.")
            return False

    # Step 5: Multiple garages found
    else:
        # Multiple garages found, ask for garage name
        text_to_speech1("We found multiple garages in that pincode. Please provide the name of the garage.")
        garage_name_input = str(speech_to_text()).strip().lower()
        garage_name = re.sub(r"[.-]", "", garage_name_input)

        # Filter records by garage name (case-insensitive partial match)
        matching_garages = []
        for record in records:
            if garage_name in record[5].lower():
                matching_garages.append({
                    'GarageID': record[1],
                    'GarageName': record[5],
                    'Address': record[6],
                    'Pincode': record[7]
                })
        # No name matches
        if len(matching_garages) == 0:
            text_to_speech1("No exact matches found. Let me list all garages in this pincode for confirmation:")
            selected_garage = None

            # List all garages in the pincode for confirmation
            for record in records:
                garage = {
                    'GarageID': record[1],
                    'GarageName': record[5],
                    'Address': record[6],
                    'Pincode': record[7]
                }
                confirm_msg = f"Did you mean {garage['GarageName']} located at {garage['Address']}?"
                text_to_speech1(confirm_msg)
                response = str(speech_to_text()).strip().lower()

                if 'yes' in response:
                    selected_garage = garage
                    break

            if selected_garage:
                text_to_speech1(
                    f"Confirmed {selected_garage['GarageName']}. The garage has been verified. Let's proceed with the claim.")
                session.garage_details = selected_garage
                return True
            else:
                session.transfer_reason = "No garage selected from multiple options"
                text_to_speech1(
                    "None of the garages matched your request. Please hold while I transfer you to an agent for further assistance.")
                return False

        # Single name match
        elif len(matching_garages) == 1:
            garage = matching_garages[0]
            confirm_message = f"We found {garage['GarageName']} located at {garage['Address']}. Is this correct?"
            text_to_speech1(confirm_message)
            confirmation = str(speech_to_text()).strip().lower()

            if 'yes' in confirmation:
                text_to_speech1("The garage has been verified in our system. Let's proceed with the claim.")
                session.garage_details = garage
                return True
            else:
                session.transfer_reason = "User rejected single name-matched garage"
                text_to_speech1("Please hold while I transfer you to an agent for further assistance.")
                return False

        # Multiple name matches
        else:
            text_to_speech1("There are multiple garages with that name. Let me confirm each one:")
            selected_garage = None

            for garage in matching_garages:
                confirm_msg = f"Is it {garage['GarageName']} located at {garage['Address']}?"
                text_to_speech1(confirm_msg)
                response = str(speech_to_text()).strip().lower()

                if 'yes' in response:
                    selected_garage = garage
                    break

            if selected_garage:
                text_to_speech1(f"You have confirmed {selected_garage['GarageName']}. The garage has been verified. Let's proceed with the claim.")
                session.garage_details = selected_garage
                return True
            else:
                session.transfer_reason = "No garage selected from multiple name matches"
                text_to_speech1("None of the garages were selected. I will now transfer you to an agent. Please hold.")
                return False


def proceed_with_claim(session):
    try:
        # Step 1: Generate claim intimation
        text_to_speech1("I'll now generate your claim intimation ID. Please wait a moment while I process this.")

        # Prepare API payload
        payload = {
            "PolicyNo": session.policy_details.get('policyno', '920222523110081801'),
            "IntimaterName": session.caller_details.get('name', 'Unknown'),
            "MinOfLoss": "57",
            "CreatedBy": "3539",
            "IntimaterMobileNo": session.caller_details.get('mobile', '0000000000'),
            "InsuredName": session.policy_details.get('insured_name', 'JALPAN R SHAH'),
            "LOSSDATE": session.claim_details.get('accident_date', 'N/A'),
            "DescriptionOfLoss": "Automated claim intimation",
            "DriverName": session.claim_details.get('driver_info', 'Unknown'),
            "HourOfLoss": "12",
            "RequestSource": "4708",
            "InsuredMobileNumber": session.mobile_number,
            "ReasonForDelayInIntimation": "1",
            "InsuredWhatsappNumber": session.mobile_number,
            "InsuredEmailId": session.policy_details.get('EmailID', "a@b.com"),
            "InsuredWhatsappConsent": "True",
            "EstimatedLoss": "1",
            "GarageID": session.garage_details.get('GarageID', '0000')
        }
        print("1")
        #Simulate API call (replace with actual API endpoint and headers)
        response = requests.post("http://mplusuat.reliancegeneral.co.in:9443/VAPTMobile/claims.svc/GETCLAIMNO_GARAGEAPP", json=payload)
        print("2")
        # Handle API failure
        if not response or response.status_code != 200:
            session.transfer_reason = "Claim API failure"
            text_to_speech1(
                "I'm sorry, I'm having trouble generating your claim intimation ID due to a system issue. I will transfer you to an agent who can help you further. Please hold.")
            return False
        print("3")
        # Parse the JSON response
        response_data = response.json()
        print(response_data)
        print("4")
        if response_data.get("Result") and len(response_data["Result"]) > 0:
            session.claim_details['claim_no'] = response_data['Result'][0].get('ClaimNo', 'Unknown')

        # Store claim number in session
        # session.claim_details['claim_no'] = response['Result'][0]['ClaimNo']
        print("5")
        # Confirm details with user
        confirm_message = (
            f"Your claim {session.claim_details['claim_no']} details: "
            f"Policy: {payload['PolicyNo']}, "
            f"Insured: {payload['InsuredName']}, "
            f"Accident Date: {payload['LOSSDATE']}, "
            f"Time: {payload['HourOfLoss']}, "
            f"Location: {session.claim_details.get('accident_location', 'N/A')}, "
            f"Driver: {payload['DriverName']}, "
            f"Garage: {session.garage_details.get('GarageName', 'N/A')} "
            "Please confirm if all details are correct."
        )
        print("6")
        text_to_speech1(confirm_message)
        confirmation = speech_to_text().strip().lower()

        if 'yes' in confirmation:
            # Final confirmation
            text_to_speech1("Claim successfully registered! Your claim number is " +
                            " ".join(session.claim_details['claim_no']) +
                            ". We'll send SMS confirmation shortly.")
            return True
        else:
            session.transfer_reason = "User requested details correction"
            text_to_speech1("I'll transfer you to an agent to correct the details. Please hold.")
            return False
    except Exception as e:
        session.transfer_reason = f"Claim processing error: {str(e)}"
        text_to_speech1("System error occurred. Transferring to agent.")
        return False


def conclusion_step():
    text_to_speech1(
            "Thank you for contacting our claim intimation helpline. If you have any further questions or concerns, feel free to call us back or visit our website. Have a great day!")


# 110322423110146463
# 8697745125

# 160221923730000221
# 9331580407
def claim_intimation_flow(mobile_number="9876543210"):
    session = ClaimSession()

    # Initial Greetings
    text_to_speech1(text="Namaste! Welcome to our claim helpline.")

    if validate_mobile_number(mobile_number):
        session.mobile_number = mobile_number
        if not get_policy_details(session):
            print(session.__dict__)
            return redirecting_to_agent(session.transfer_reason)
    else:
        if not ask_mobile_or_policy_number(session):
            print(session.__dict__)
            return redirecting_to_agent(session.transfer_reason)
        if session.mobile_number:
            if not get_policy_details(session):
                print(session.__dict__)
                return redirecting_to_agent(session.transfer_reason)

    insured_confirmation(session)

    if not claim_type(session):
        print(session.__dict__)
        return redirecting_to_agent(session.transfer_reason)

    if not garage_validation(session):
        print(session.__dict__)
        return redirecting_to_agent(session.transfer_reason)

    if not proceed_with_claim(session):
        print(session.__dict__)
        return redirecting_to_agent(session.transfer_reason)

    conclusion_step()

    print(session.__dict__)


claim_intimation_flow()

