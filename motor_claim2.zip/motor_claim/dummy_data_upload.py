# insert_garage_data.py

import django
import os

# # Set up Django settings for the script
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'claim_agent.settings')  # replace 'your_project' with your actual project name
django.setup()

# Import your model
from motor_claim.models import GarageMaster  # replace 'yourapp' with the actual name of your app

# List of data to insert into the database
# data = [
#     (100336337, 336596, None, 30, "RAMANI MOTORS", "AMMAPALAYAM", "641652"),
#     (100336336, 539201, None, 40, "VAISHNAVI HONDA", "Kondapur", "500084"),
#     (100336335, 129571, None, 15, "JH auto mobile", "Koulpur", "184120"),
#     (100336334, 49558, None, 5, "shree bajaj", "C M College", "846004"),
#     (100336333, 539026, None, 10, "TRUMP MOTOR", "Badli (North West Delhi)", "110042"),
#     (100336332, 191638, None, 20, "Maa Reva Self & Services LLP", "Mandla", "481661"),
#     (100336331, 540578, None, 21, "mg service center", "Hadpsar I.E.", "411013"),
#     (100336330, 545964, None, 32, "motor craft", "site 4 greater noida GAUTAM BUDDHA NAGAR | BISRAKH | Bisrakh", "201306"),
#     (100336329, 238881, None, 21, "sagar auto mech", "Dahisar", "400068"),
#     (100336328, 539825, None, 10, "VD AUTO WHEELS", "D. K. Mohan Garden", "110059"),
# ]
data = [
    (100336333, 539026, None, 10, "TRUMP MOTOR", "Badli (North East Delhi)", "110042"),
    (100336332, 191638, None, 20, "Maa Reva Self & Services LLP", "Mandla East", "481661"),
    (100336332, 191638, None, 20, "Maa Reva Self & Services LLP", "Mandla north", "481661"),
]

# Loop through the data and create GarageMaster instances
for entry in data:
    GarageMaster.objects.create(
        GarageID=entry[0],
        City_or_Village_ID_PK=entry[1],
        DIstrictID=entry[2],
        State_ID_PK=entry[3],
        GarageName=entry[4],
        Address=entry[5],
        PinCode=entry[6]
    )

print("Data inserted successfully!")
