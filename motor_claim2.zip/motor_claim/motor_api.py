import requests
from utils import *

def register_claim(payload):
    print("Calling Register Claim API.......")
    """
    {
        "PolicyNo": "160221923730000221",
        "IntimaterName": "test",
        "MinOfLoss": "57",
        "CreatedBy": "3539",
        "IntimaterMobileNo": "1223456789"",
        "InsuredName": "JALPAN R SHAH",
        "LOSSDATE": "4/8/2023",
        "DescriptionOfLoss": "test",
        "DriverName": "test",
        "HourOfLoss": "12",
        "RequestSource": "4708",
        "InsuredMobileNumber": "1234567890",
        "ReasonForDelayInIntimation": "1",
        "InsuredWhatsappNumber": "1234567890",
        "InsuredEmailId": "a@b.com",
        "InsuredWhatsappConsent": "True",
        "EstimatedLoss": "1",
        "GarageID": "21692025"
    }
    """

    url = "http://mplusuat.reliancegeneral.co.in:9443/VAPTMobile/claims.svc/GETCLAIMNO_GARAGEAPP"

    try:
        response = requests.post(url, json=payload)

    except requests.exceptions.RequestException as e:
        redirecting_to_agent("""I'm sorry, I'm having trouble generating your claim intimation ID due to a system issue. I will transfer you to an agent who can help you further. Please hold""")
        return None

    return response.json()


def check_duplicate_claim(payload):
    print("Calling Check Duplicate Claim API.......")
    """
    data = {
    "PrimaryTypeofLoss": 65,
    "dateOfLoss": "/Date(5-3-2024)/",
    "coverNoteNo": "",
    "policyNo": "9202742311007142",
    "insuredName": ""
    }
    """

    url = "http://mplusuat.reliancegeneral.co.in:9443/VAPTMobile/Claims.svc/GetDuplicateClaim"

    headers = {"Authorization": "Basic cmdpbW9iaWxlfnI4IWMxTTA2ITFl",
              "IMEI": "123",
              "Content-Type": "application/json"}

    try:
        response = requests.post(url, json=payload, headers=headers)

        # Check if the request was successful
        api_status = True if response.status_code == 200 else False
        if api_status:
            return response.json(), api_status  # Return the response data as a JSON object
        else:
            response.raise_for_status()  # Raise an HTTPError for bad responses
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return None


def fetch_policy_details_via_phone_number(phone_number):
    print("calling fetch_policy_details_via_phone_number API.......")
    policy_details = {
        "policyno": "110322423110146463",
        "covernote_number": "R16102457625",
        "insured_name": "Suman Jena",
        "policy_start_date": "21-10-2024",
        "policy_end_date": "20-10-2025",
        "EngineNo": "L15A72239611",
        "ChassisNo": "MAKGM252JBN213414",
        "VehiclNo": "MH-43-AJ-4484",
        "Endt_Type": "Fresh Policy",
        "SYSTEM_Posting_Date": "2024-10-16T14:16:00",
        "CONTACTNO_MOBILE": "8697745125",
        "EmailID": "suman.jena@gmail.com",
        "FirstName": "Suman",
        "LastName": "Jena",
        "Address": "PLOT NO 88 BHUBANESWAR GAUTAM NAGARPS BARAGADA BJB NAGAR S OKHORDHA KHORDHA ORISSA INDIA 751014",
        "CityName": "BHUBANESWAR",
        "DistrictName": "KHORDHA",
        "StateName": "ODISHA",
        "Pinno": "751014",
        "DOB": None,
        "Gender": None,
        "StateID": 25,
        "DistrictID": 383,
        "CityID": 261273,
        "Endt_no": "0",
        "PRODUCT_CODE": "2311",
    }
    return policy_details


def garage_details_api(garage_name):
    print("calling garage_details API.......")
    return

# {
# "PolicyNo": "160221923730000221",
# "IntimaterName": "test",
# "MinOfLoss": "57",
# "CreatedBy": "3539",
# "IntimaterMobileNo": "1223456789",
# "InsuredName": "JALPAN R SHAH",
# "LOSSDATE": "4/8/2023",
# "DescriptionOfLoss": "test",
# "DriverName": "test",
# "HourOfLoss": "12",
# "RequestSource": "4708",
# "InsuredMobileNumber": "1234567890",
# "ReasonForDelayInIntimation": "1",
# "InsuredWhatsappNumber": "1234567890",
# "InsuredEmailId": "a@b.com",
# "InsuredWhatsappConsent": "True",
# "EstimatedLoss": "1",
# "GarageID": "21692025"
# }