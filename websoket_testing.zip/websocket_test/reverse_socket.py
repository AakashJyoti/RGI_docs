import asyncio
import websockets
import json
import base64
import wave

async def receive_audio():
    uri = "ws://localhost:8003/ws/audio/594528/"  # Update with WebSocket URL

    async with websockets.connect(uri) as websocket:
        # Send a request to start receiving audio
        request_audio_event = {
            "event": "request_audio",
            "sequence_number": 1,
            "stream_sid": "594528"
        }
        await websocket.send(json.dumps(request_audio_event))
        print(f"Sent audio request: {request_audio_event}")

        audio_chunks = []
        sample_rate = 16000  # Default, will update if provided
        sampwidth = 2        # Default for 16-bit PCM
        n_channels = 1       # Default, update if needed

        while True:
            response = await websocket.recv()
            data = json.loads(response)

            if data.get("event") == "media":
                media_data = data.get("media", {})
                chunk = media_data.get("chunk")
                payload = media_data.get("payload")

                if payload:
                    decoded_chunk = base64.b64decode(payload)
                    audio_chunks.append(decoded_chunk)
                    print(f"Received chunk {chunk}")

            elif data.get("event") == "stop":
                print(f"Received stop event: {data}")
                break

        # Save received audio to a WAV file
        output_filename = "received_audio.wav"
        try:
            with wave.open(output_filename, "wb") as wf:
                wf.setnchannels(n_channels)
                wf.setsampwidth(sampwidth)
                wf.setframerate(sample_rate)
                wf.writeframes(b"".join(audio_chunks))
            print(f"Saved audio as {output_filename}")
        except Exception as e:
            print(f"Error saving WAV file: {e}")

# Run the client
asyncio.run(receive_audio())