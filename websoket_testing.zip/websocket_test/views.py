from django.shortcuts import render
from django.http import JsonResponse
from django.views import View
from rest_framework.views import APIView
from django.conf import settings
import json
from django.views.decorators.csrf import csrf_exempt


class InitialCallView(APIView):
    def get(self, request):
        call_sid = request.GET.get("CallSid")
        from_number = request.GET.get("From")
        to_number = request.GET.get("To")

        # Perform any necessary validations and logging
        if not all([call_sid, from_number, to_number]):
            return JsonResponse({"error": "Missing parameters"}, status=400)

        # Generate or retrieve the websocket_test endpoint for this call.
        # In a real scenario you might generate a unique path per call, e.g., including call_sid.
        websocket_endpoint = f"wss://{request.get_host()}/ws/audio/{call_sid}/"
        print(websocket_endpoint)
        return JsonResponse({"websocket_url": websocket_endpoint})