import re
import os
import sqlite3
import time
import json
from dataclasses import dataclass
from typing import Dict, Any
from api import *
from utils import speech_to_text, text_to_speech1_english, redirecting_to_agent, message_website, call_openai, \
    extract_and_convert_to_json
from soap_api_number import extract_motor_policy_numbers
from dateutil import parser
import re
import streamlit as st
import wave
from deep_update import handle_recording, play_audio

from utils import text_to_speech_azure_streamlit, speech_to_text_azure_streamlit
from RGI_Motor_Hindi_1 import hindi_claim_intimation_flow





# Connect to the SQLite database (replace 'db.sqlite3' with your database file)

def convert_to_dd_mm_yyyy(date_str):
    # Regular expression to match month and year formats (e.g., "February 2025")
    if re.match(r"^[A-Za-z]+ \d{4}$", date_str) or re.match(r"^\d{1,2}[a-z]{2} [A-Za-z]+$", date_str):
        return "date format is not correct"
    try:
        # Parse the input date string
        parsed_date = parser.parse(date_str)
        # Convert the parsed date to DD/MM/YYYY format
        formatted_date = parsed_date.strftime('%d/%m/%Y')
        return formatted_date

    except (ValueError, OverflowError):
        return "Invalid date format"


def remove_special_characters_except_comma(input_string):
    try:
        return re.sub(r'[^A-Za-z0-9,/ ]', ' ', input_string)
    except:
        return input_string

# # audio file time duration calculation
def calculate_length_of_audio():
    base_path = os.path.dirname(os.path.abspath(__file__))  # Get the current script's directory
    parent_directory = os.path.dirname(base_path)  # Go up one directory
    audio_path = os.path.join(parent_directory, "audio", "Bot", "bot_response.wav")


    with wave.open(audio_path, 'rb') as audio_file:
        frames = audio_file.getnframes()
        rate = audio_file.getframerate()
        duration = frames / float(rate)
        return duration + 0.5

# def text_to_speech_func_english(message):
#     text_to_speech_azure_streamlit(input_text=message)
#
#     with st.chat_message("assistant"):
#         st.write(message)
#     play_audio()
#     time.sleep(calculate_length_of_audio())  # handle time dynamically
def text_to_speech_func_english(message):
    text_to_speech_azure_streamlit(input_text=message)







def handle_user_input(duration):
    handle_recording(duration=duration)  # Assuming handle_recording is your recording function
    user_input = speech_to_text_azure_streamlit()
    print(user_input)
    return user_input









def claim_intimation_flow(mobile_number="8697745125"):
    session = ClaimSession()

    welcome_message = "Namaste! Welcome to our claim helpline. Would you prefer to continue in Hindi or English?"
    text_to_speech_func_english(welcome_message)

    language_confirmation = handle_user_input(duration=5)

    if language_confirmation:
        welcome_message = "Namaste! Welcome to our claim helpline. Would you prefer to continue in Hindi or English?"
        text_to_speech_func_english(welcome_message)
