import streamlit as st
import sounddevice as sd
from pygments.util import duplicates_removed
from scipy.io.wavfile import write
import os
import base64

# Create a "recordings" folder if it doesn't exist
# if not os.path.exists("recordings"):
#     os.makedirs("recordings")


def handle_recording(duration):
    # filepath = os.path.join("recordings", "recording.wav")
    filepath = "D:/reliance/claim_agent/audio/User/example.wav"
    # duration = 10
    sample_rate = 44100
    input_channel = 1

    recording = sd.rec(
        int(duration * sample_rate),
        samplerate=sample_rate,
        channels=input_channel,
        dtype="int16",
    )
    sd.wait()
    write(filepath, sample_rate, recording)


def play_audio():
    # audio_path = os.path.join("response", "../audio/User/example.wav")
    audio_path =  "D:/reliance/claim_agent/audio/Bot/bot_response.wav"

    with open(audio_path, "rb") as audio_file:
        audio_bytes = audio_file.read()

    audio_base64 = base64.b64encode(audio_bytes).decode("utf-8")

    # Inject JavaScript to auto-play the audio
    st.markdown(
        f"""
        <audio autoplay>
            <source src="data:audio/wav;base64,{audio_base64}" type="audio/wav">
            Your browser does not support the audio element.
        </audio>
        """,
        unsafe_allow_html=True,
    )

