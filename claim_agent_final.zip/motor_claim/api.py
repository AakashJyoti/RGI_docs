import requests
from utils import *

def register_claim(payload):
    print("Calling Register Claim API.......")
    """
    {
        "PolicyNo": "160221923730000221",
        "IntimaterName": "test",
        "MinOfLoss": "57",
        "CreatedBy": "3539",
        "IntimaterMobileNo": "1223456789"",
        "InsuredName": "JALPAN R SHAH",
        "LOSSDATE": "4/8/2023",
        "DescriptionOfLoss": "test",
        "DriverName": "test",
        "HourOfLoss": "12",
        "RequestSource": "4708",
        "InsuredMobileNumber": "1234567890",
        "ReasonForDelayInIntimation": "1",
        "InsuredWhatsappNumber": "1234567890",
        "InsuredEmailId": "a@b.com",
        "InsuredWhatsappConsent": "True",
        "EstimatedLoss": "1",
        "GarageID": "21692025"
    }
    """

    url = "http://mplusuat.reliancegeneral.co.in:9443/VAPTMobile/claims.svc/GETCLAIMNO_GARAGEAPP"

    try:
        response = requests.post(url, json=payload)

    except requests.exceptions.RequestException as e:
        redirecting_to_agent("""I'm sorry, I'm having trouble generating your claim intimation ID due to a system issue. I will transfer you to an agent who can help you further. Please hold""")
        return None

    return response.json()


def fetch_policy_details_via_phone_number(policy_number):
    print("calling fetch_policy_details_via_phone_number API.......")
    policy_details = {
        "policyno": policy_number,
        "covernote_number": "R16102457625",
        "insured_name": "Suman Jena",
        "policy_start_date": "21-10-2024",
        "policy_end_date": "20-01-2025",
        "EngineNo": "L15A72239611",
        "ChassisNo": "MAKGM252JBN213414",
        "VehiclNo": "MH-43-AJ-4484",
        "Endt_Type": "Fresh Policy",
        "SYSTEM_Posting_Date": "2024-10-16T14:16:00",
        "CONTACTNO_MOBILE": "9876543210",
        "EmailID": "suman.jena@gmail.com",
        "FirstName": "Suman",
        "LastName": "Jena",
        "Address": "PLOT NO 88 BHUBANESWAR GAUTAM NAGARPS BARAGADA BJB NAGAR S OKHORDHA KHORDHA ORISSA INDIA 751014",
        "CityName": "BHUBANESWAR",
        "DistrictName": "KHORDHA",
        "StateName": "ODISHA",
        "Pinno": "751014",
        "DOB": None,
        "Gender": None,
        "StateID": 25,
        "DistrictID": 383,
        "CityID": 261273,
        "Endt_no": "0",
        "PRODUCT_CODE": "2311",
    }
    return policy_details


def validate_mobile_number_api_call(mobile_no):
    # Define the URL of the SOAP service
    url = "https://leadservices.brobotinsurance.com/rgiChatbot/ChatbotIntegrationWrapper.asmx"

    # Craft the XML request body with the passed mobile number
    soap_body = f'''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
       <soapenv:Header/>
       <soapenv:Body>
          <tem:ChatbotGetPolDataOnMobileNoWrap>
             <tem:XML><![CDATA[<CHATBOT><UserID>CHATBOT</UserID><Password>CHATBOT@123</Password><CallerAppID>16</CallerAppID><MobileNo>{mobile_no}</MobileNo></CHATBOT>]]></tem:XML>
          </tem:ChatbotGetPolDataOnMobileNoWrap>
       </soapenv:Body>
    </soapenv:Envelope>'''

    # Set the necessary headers
    headers = {
        "Content-Type": "text/xml; charset=utf-8",
        "SOAPAction": "http://tempuri.org/ChatbotGetPolDataOnMobileNoWrap"  # Action header from the API specification
    }

    # Make the POST request
    response = requests.post(url, data=soap_body, headers=headers)

    # Parse the response text
    raw_xml = response.text

    # Check if the mobile number is valid or not
    match_code = re.findall(r'ResponseCode&gt;([01])&lt;/ResponseCode&gt;', raw_xml)
    matches = re.findall(r'&lt;ResponseMessage&gt;(.*?)&lt;/ResponseMessage&gt;', raw_xml)

    if matches[0] == "No Record Found" or match_code[0] == '1':
        return "invalid mobile number"
    elif match_code[0] == '0':
        return "valid mobile number"
    else:
        return "invalid mobile number"


def check_duplicate_claim(payload):
    print("Calling Check Duplicate Claim API.......")
    """
    data = {
    "PrimaryTypeofLoss": 65,
    "dateOfLoss": "",
    "coverNoteNo": "",
    "policyNo": "160221923730000221",
    "insuredName": ""
    }
    """

    url = "http://mplusuat.reliancegeneral.co.in:9443/VAPTMobile/Claims.svc/GetDuplicateClaim"

    headers = {"Authorization": "Basic cmdpbW9iaWxlfnI4IWMxTTA2ITFl",
              "IMEI": "123",
              "Content-Type": "application/json"}

    try:
        response = requests.post(url, json=payload, headers=headers)
        print(response)
        # Check if the request was successful
        api_status = True if response.status_code == 200 else False
        if api_status:
            return response.json(), api_status  # Return the response data as a JSON object
        else:
            response.raise_for_status()  # Raise an HTTPError for bad responses
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return None


# data = {
#     "PrimaryTypeofLoss": 65,
#     "dateOfLoss": "",
#     "coverNoteNo": "",
#     "policyNo": "160221923730000221",
#     "insuredName": ""
#     }
#
# print(check_duplicate_claim(data))