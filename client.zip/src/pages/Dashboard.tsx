import { useEffect, useState } from "react";
import { LoadingIcon, SearchIcon, TranscriptIcon } from "../assets/svg";
import TranscriptModal from "../components/TranscriptModal";
import axios from "axios";

import { API_URL } from "../constant";
import { calculateDuration, formatDate } from "../utils";
import ReportDownload from "../components/ReportDownload";

type TDetails = {
  callerNo: string;
  conId: string;
  date: string;
  CIVRcallStartTime: string;
  CIVRcallEndTime: string;
  CIVRcallDuration: string;
  CallTransferStartTime: string;
  CallTransferEndTime: string;
  CallTransferDuration: string;
  callStatus: string;
  language: string;
  sessionId: string;
};

type Tp = TDetails & {
  sno: number;
};

const Dashboard = () => {
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [selecedCall, setSelecedCall] = useState<Tp>();
  const [dashboardDetials, setDashboardDetials] = useState<Tp[]>([]);
  const [pageDetails, setPageDetails] = useState<Pagination>({
    currentPage: 0,
    limit: 20,
    total: 0,
    totalPages: 0,
    hasNextPage: false,
    hasPreviousPage: false,
  });
  const [debounceTerm, setDebounceTerm] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortFor] = useState("");

  useEffect(() => {
    const handler = setTimeout(() => {
      setSearchTerm(debounceTerm);
    }, 200);

    // Cleanup if user types again before 200ms
    return () => {
      clearTimeout(handler);
    };
  }, [debounceTerm]);

  useEffect(() => {
    const getData = async () => {
      setLoading(true);
      try {
        const { data } = await axios.get<PageinationApiResponse>(
          `${API_URL}/getRecords?page=${pageDetails.currentPage}&limit=${pageDetails.limit}&status=${sortFor}&search=${searchTerm}`
        );
        setPageDetails(data.pagination);
        const formattedData: Tp[] = data.data.map((item, index) => ({
          sno: index + 1,
          callerNo: item.mobile_number,
          conId: item.call_sid,
          date: formatDate(item.created_at),
          CIVRcallStartTime: item.call_start_time.split("T")[1].split(".")[0],
          CIVRcallEndTime: item.call_end_time.split("T")[1].split(".")[0],
          CIVRcallDuration: calculateDuration({
            startTime: item.call_start_time,
            endTime: item.call_end_time,
          }),
          CallTransferStartTime: "",
          CallTransferEndTime: "",
          CallTransferDuration: "",
          callStatus: item.status,
          language: item.selected_language,
          sessionId: `${item.session_id}`,
        }));
        setDashboardDetials(formattedData);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };

    getData();
  }, [pageDetails.currentPage, pageDetails.limit, searchTerm, sortFor]);

  const toggleTransModal = () => {
    setShowModal((prev) => !prev);
  };

  const handleTranscript = (val: Tp) => {
    setSelecedCall(val);
    toggleTransModal();
  };

  return (
    <>
      <div className="mx-auto p-9 h-screen overflow-hidden flex flex-col">
        <div className="grid grid-cols-3 gap-4 justify-between mb-4">
          <div className="flex gap-4 items-center">
            <p className="text-balance font-semibold mb-1">Filters:</p>
            <div className="pl-2 pr-1 py-1 flex gap-2 items-center border border-gray-400 rounded min-w-64 text-sm">
              <p>Status</p>
              <select
                name=""
                id=""
                className="flex-1 border border-gray-300 rounded px-4 py-1"
              >
                <option value="">Select</option>
              </select>
            </div>
          </div>

          <div className="border border-gray-300 flex items-center px-4 gap-2 rounded-full">
            <SearchIcon />
            <input
              type="text"
              placeholder="Search"
              className="grow text-sm"
              value={debounceTerm}
              onChange={(e) => setDebounceTerm(e.target.value)}
            />
          </div>

          <ReportDownload />
        </div>

        <div className="h-full flex flex-col border border-gray-300">
          <table className="min-w-[1200px] bg-white text-xs">
            <thead>
              <tr className="border-b border-white text-white bg-blue-500">
                <th className="py-2 px-4 border-r" colSpan={1}>
                  S.No.
                </th>
                <th className="py-2 px-2 border-r" colSpan={1}>
                  Caller No.
                </th>
                <th className="py-2 px-2 border-r" colSpan={1}>
                  Con Id
                </th>
                <th className="py-2 px-2 border-r" colSpan={1}>
                  Date
                  <br />
                  <span className="text-xs">(DD-MM-YYYY)</span>
                </th>
                <th className="py-2 px-2 border-r" colSpan={1}>
                  Language
                </th>
                <th className="border-r" colSpan={3}>
                  <div className="flex flex-col">
                    <p className="py-2 px-2 text-center">CIVR Call Time</p>
                    <div className="grid grid-cols-3 border-white border-t py-2">
                      <p className="border-r px-1">Start Time</p>
                      <p className="border-r px-1">End Time</p>
                      <p className="px-1">Duration</p>
                    </div>
                  </div>
                </th>
                <th className="border-r" colSpan={3}>
                  <div className="flex flex-col">
                    <p className="py-2 px-2 text-center">Call Transfer</p>
                    <div className="grid grid-cols-3 border-white border-t py-2">
                      <p className="border-r px-1">Start Time</p>
                      <p className="border-r px-1">End Time</p>
                      <p className="px-1">Duration</p>
                    </div>
                  </div>
                </th>

                <th className="py-2 px-4 border-r">Call Status</th>
                <th className="py-2 px-4">Call Transcription</th>
              </tr>
            </thead>

            <tbody className="h-full overflow-auto relative">
              {loading ? (
                <tr>
                  <td colSpan={13} className="h-64">
                    <div className="absolute inset-0 flex justify-center items-center h-full w-full">
                      <LoadingIcon />
                    </div>
                  </td>
                </tr>
              ) : (
                dashboardDetials.map((ele) => (
                  <tr className="border-b-gray-300 border-b" key={ele.conId}>
                    <td className="py-2 px-4 text-center">{ele.sno}</td>
                    <td className="py-2 px-4 text-center">{ele.callerNo}</td>
                    <td className="py-2 px-4 text-center">{ele.conId}</td>
                    <td className="py-2 px-4 text-center">{ele.date}</td>
                    <td className="py-2 px-4 text-center">{ele.language}</td>
                    <td className="py-2 px-4 text-center">
                      {ele.CIVRcallStartTime}
                    </td>
                    <td className="py-2 px-4 text-center">
                      {ele.CIVRcallEndTime}
                    </td>
                    <td className="py-2 px-4 text-center">
                      {ele.CIVRcallDuration}
                    </td>
                    <td className="py-2 px-4 text-center">
                      {ele.CallTransferStartTime}
                    </td>
                    <td className="py-2 px-4 text-center">
                      {ele.CallTransferEndTime}
                    </td>
                    <td className="py-2 px-4 text-center">
                      {ele.CallTransferDuration}
                    </td>
                    <td className="py-2 px-4 text-center">{ele.callStatus}</td>
                    <td className="py-2 px-4 text-center">
                      <div className="flex justify-center items-center">
                        <button
                          type="button"
                          onClick={() => handleTranscript(ele)}
                        >
                          <TranscriptIcon />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        <div className="flex justify-between mt-4 items-center text-sm">
          <div className="flex gap-4 items-center">
            <label htmlFor="limit">Page size:</label>
            <select
              name="limit"
              id="limit"
              className="border border-gray-300 rounded px-4 py-1"
              value={pageDetails.limit}
              onChange={(e) =>
                setPageDetails((prev) => ({
                  ...prev,
                  limit: Number(e.target.value),
                }))
              }
            >
              <option value="20">20</option>
              <option value="30">30</option>
              <option value="40">40</option>
              <option value="50">50</option>
            </select>
          </div>

          <span>
            Page {pageDetails.currentPage} of{" "}
            {Math.ceil(pageDetails.total / pageDetails.limit)}
          </span>

          <div className="flex gap-2">
            <button
              className="px-4 py-2 w-24 bg-blue-500 text-white rounded disabled:bg-gray-300"
              disabled={!pageDetails.hasPreviousPage}
            >
              Previous
            </button>
            <button
              className="px-4 py-2 w-24 bg-blue-500 text-white rounded disabled:bg-gray-300"
              disabled={!pageDetails.hasNextPage}
            >
              Next
            </button>
          </div>
        </div>
      </div>
      {showModal && selecedCall?.sessionId && (
        <TranscriptModal
          sessionId={selecedCall?.sessionId}
          toggleTransModal={toggleTransModal}
        />
      )}
    </>
  );
};
export default Dashboard;
