type TAuthCred = { name: string; password: string };

interface ClaimData {
  id: number;
  session_id: number;
  selected_language: string;
  policy_number: string;
  mobile_number: string;
  covernote_number: string;
  insured_name: string;
  policy_start_date: string;
  policy_end_date: string;
  engine_number: string;
  chassis_number: string;
  vehicle_number: string;
  contact_number: string;
  email_id: string;
  first_name: string;
  last_name: string;
  address: string;
  city_name: string;
  state_name: string;
  pinno: string;
  date_of_birth: string;
  gender: string;
  state_id: string;
  district_id: string;
  city_id: string;
  endt_no: string;
  product_code: string;
  is_insured: string;
  relationship_with_insured: string;
  caller_name: string;
  caller_mobile: string;
  claim_type: string;
  accident_date: string;
  hour_of_loss: string;
  min_of_loss: string;
  accident_location: string;
  driver_info: string;
  accident_info: string;
  garage_id: string;
  garage_name: string;
  garage_address: string;
  garage_pincode: string;
  claim_number: string;
  transfer_reason: string;
  call_sid: string;
  created_at: string;
  call_start_time: string;
  call_end_time: string;
  status: string;
}

interface Pagination {
  total: number;
  totalPages: number;
  currentPage: number;
  limit: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

interface Filters {
  search: string;
  status: string;
}

interface PageinationApiResponse {
  success: boolean;
  data: ClaimData[];
  pagination: Pagination;
  filters: Filters;
}
