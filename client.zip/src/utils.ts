const key = "auth_rgi";

export const saveAuthToLocalStorage = (value: TAuthCred) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error("Error saving to localStorage:", error);
  }
};

export const removeAuthFromLocalStorage = () => {
  try {
    localStorage.removeItem(key);
  } catch (error) {
    console.error("Error removing from localStorage:", error);
  }
};

export const getAuthFromLocalStorage = () => {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : null;
  } catch (error) {
    console.error("Error reading from localStorage:", error);
    return null;
  }
};

export const calculateDuration = ({
  startTime,
  endTime,
}: {
  startTime: string;
  endTime: string;
}) => {
  const startDate = new Date(startTime);
  const endDate = new Date(endTime);

  const durationMs = endDate.getTime() - startDate.getTime();
  const diffInMinutes = Math.round(durationMs / (1000 * 60));
  return `${diffInMinutes}`;
};

export const formatDate = (isoDate: string): string => {
  const date = new Date(isoDate);
  const day = String(date.getDate()).padStart(2, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
};
