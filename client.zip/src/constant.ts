export const API_URL = "/api/v1/records/";
// export const API_URL = "http://localhost:4200/api/v1/records/";
